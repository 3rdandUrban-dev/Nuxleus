/* ****************************************************************************
 *
 * Copyright (c) Microsoft Corporation. 
 *
 * This source code is subject to terms and conditions of the Microsoft Permissive License. A 
 * copy of the license can be found in the License.html file at the root of this distribution. If 
 * you cannot locate the  Microsoft Permissive License, please send an email to 
 * ironruby@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
 * by the terms of the Microsoft Permissive License.
 *
 * You must not remove this notice, or any other, from this software.
 *
 *
 * ***************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Remoting;
using System.IO;
using System.Diagnostics;
using System.Collections;

using Microsoft.Scripting;
using Microsoft.Scripting.Shell;
using Microsoft.Scripting.Hosting;
using Microsoft.Scripting.Generation;

using MSA = Microsoft.Scripting.Ast;
using Ast = Microsoft.Scripting.Ast.Ast;

using RBC = Ruby.Compiler;
using Ruby.Hosting;
using Ruby.Compiler.Ast;
using Ruby.Compiler;
using Ruby.Runtime;
using System.Reflection;
using Ruby.Builtins;
using System.Windows.Forms;
using Microsoft.Scripting.Utils;

namespace TestHost {

    public class Program {
        private const string TestCode = @"
";

        // "file.rb", "content"
        private static string[] RequiredFiles = new string[] {   
        };
        
        private static TestCase[] Cases = new TestCase[] {
            Scenario_RubyTokenizer1,
            // TODO: fix positions Scenario_RubyCategorizer1,
            Scenario_RubyNameMangling1,
            Scenario_RubyNameMangling2,
            Scenario_RubySimpleCall1,
            Scenario_RubySimpleCall2, 
            Scenario_RubySimpleCall3, 
            Scenario_RubyMethodMissing1, 
            Scenario_RubyMethodMissing2, 
            Scenario_RubySingletons1,
            Scenario_RubyMath1,
            Scenario_RubyDefinedOperator1,
            Scenario_RubyScopeParsing,
            Scenario_RubyScopes1,
            Scenario_RubyScopes2,
            // TODO: DLR AST missing feature (scoped variables), Scenario_RubyScopes3,
            // TODO: DLR AST missing feature (scoped variables), Scenario_RubyScopes4,
            Scenario_RubyNumericLiterals1,
            Scenario_RubyStrings1,
            Scenario_RubyStrings2,
            Scenario_RubyStrings3,
            Scenario_RubyDeclarations1,
            Scenario_RubyDeclarations1A,
            Scenario_RubyDeclarations1B,
            Scenario_RubyDeclarations1C,
            Scenario_RubyDeclarations2,
            Scenario_RubyInclusions1,
            Scenario_RubyClassVersions1,
            Scenario_RubyClassVersions2,
            Scenario_RubyBlockExpressions1,
            Scenario_RubyGlobals1,
            Scenario_RubyConstants1,
            Scenario_RubyConstants2,
            Scenario_RubyConstants3,
            Scenario_RubyLocals1,
            Scenario_Assignment1,
            Scenario_ParallelAssignment1,
            Scenario_ParallelAssignment2,
            Scenario_ParallelAssignment4,
            Scenario_ParallelAssignment5,
            Scenario_ParallelAssignment6,
            Scenario_ParallelAssignment7,
            Scenario_ParallelAssignment8,
            Scenario_ParallelAssignment9,
            Scenario_ParallelAssignment10,

            Scenario_RubyBlocks0,
            Scenario_RubyBlocks1,
            Scenario_RubyBlocks2,
            // TODO: DLR AST bug (271799) Scenario_RubyBlocks3,
            Scenario_RubyBlocks4,
            Scenario_RubyBlocks5,
            Scenario_RubyBlocks6,
            Scenario_RubyBlocks7,
            Scenario_RubyBlocks8,
            Scenario_RubyBlocks9,
            Scenario_RubyBlocks10,
            // sov: Scenario_RubyBlocks11,
            Scenario_RubyBlocks12,
            Scenario_RubyBlocks13,

            Scenario_RubyBlockArgs1,
            Scenario_RubyBlockArgs2,
            Scenario_RubyBlockArgs3,
            Scenario_RubyBlockArgs4,

            Scenario_RubyProcs1,

            Scenario_RubyForLoop1,
            // TODO: Python interop: Scenario_RubyForLoop2,
            Scenario_RubyWhileLoop1,
            Scenario_RubyWhileLoop2,
            Scenario_RubyWhileLoop3,
            Scenario_RubyWhileLoop4,
            Scenario_RubyWhileLoop5,
            Scenario_RubyWhileLoop6,
            Scenario_RubyUntilLoop1,
            
            Scenario_RubyClosures1,
            Scenario_RubyParams1,
            Scenario_RubyParams2,
            Scenario_RubyReturn1,
            Scenario_RubyArrays1,
            Scenario_RubyArrays2,
            Scenario_RubyArrays3,
            Scenario_RubyArrays4,
            Scenario_RubyArrays5,
            Scenario_RubyArrays6,
            Scenario_RubyHashes1A,
            Scenario_RubyHashes1B,
            Scenario_RubyHashes1C,
            Scenario_RubyHashes2,
            Scenario_RubyHashes3,
            Scenario_RubyHashes4,
            Scenario_RubyArgSplatting1,
            Scenario_RubyArgSplatting2,
            Scenario_RubyArgSplatting3,
            Scenario_RubyBoolExpressions1,
            Scenario_RubyBoolExpressions2,
            Scenario_RubyBoolExpressions3,
            Scenario_RubyBoolExpressions4,
            Scenario_RubyIfExpression1,
            Scenario_RubyIfExpression2,
            Scenario_RubyUnlessExpression1,
            Scenario_RubyConditionalExpression1,

            // TODO: interop: Scenario_RubyInterop1, 
            // TODO: interop: Scenario_RubyInterop1A, 
            // TODO: interop: Scenario_RubyInterop2, 
            // TODO: interop (IEnumerable): Scenario_RubyInterop3, 
            // TODO: interop: Scenario_RubyInterop4,

            Scenario_RubySilverlight1,
            Scenario_RubySilverlight2,
            Scenario_RubyConsole1,
            // TODO: interop, hosting: Scenario_RubyConsole2,
            Scenario_RubyConsole3,
            Scenario_RubyRequire1,
            // TODO: Ctlr+F5 doesn't work: Scenario_RubyRequire2,
            // TODO: interop, file loading: Scenario_RubyRequire3,
            //Scenario_ClrInteropEvents1,
            Scenario_ClrInterop2,
            Scenario_RubyEvents1,
            Scenario_RubyEngine1,
            Scenario_RubyInteractive,
            // TODO: eval: Scenario_RubyEval1,

            Scenario_RubyReturnValues1,
            Scenario_RubyReturnValues2,
            Scenario_RubyReturnValues3,
            Scenario_RubyReturnValues4,
            Scenario_RubyReturnValues5,
            Scenario_RubyReturnValues6,

            Scenario_RubyExceptions1,
            Scenario_RubyExceptions1A,
            Scenario_RubyExceptions2A,
            Scenario_RubyExceptions2B,
            Scenario_RubyExceptions2C,
            Scenario_RubyExceptions2D,
            Scenario_RubyExceptions3,
            Scenario_RubyExceptions4,
            Scenario_RubyExceptions5,
            Scenario_RubyExceptions6,
            Scenario_RubyExceptions7,
            Scenario_RubyExceptions8,
            Scenario_RubyExceptions9,
            Scenario_RubyExceptions10,
            Scenario_RubyExceptions11,
            Scenario_RubyExceptions12,
            // TODO: (needs alias) Scenario_RubyExceptions12A
            Scenario_RubyExceptions13,
            Scenario_RubyExceptions14,
            Scenario_RubyExceptions15,
            Scenario_RubyExceptions16,

            Scenario_RubyThreads1,
            // TODO: DLR AST bug (271799) Scenario_DLRAST_Comma1
        };

        #region Driver

        private delegate void TestCase();

        private static string _currentTestName = null;

        [AttributeUsage(AttributeTargets.Method)]
        private sealed class RunAttribute : Attribute {
        }

        static int Main(string[] args) {
            bool isDebug = false;
            
            List<string> largs = new List<string>(args);
            if (largs.Contains("/help") || largs.Contains("-?") || largs.Contains("/?") || largs.Contains("-help")) {
                Console.WriteLine("Run All Tests      : testhost [-X:Interpret]");
                Console.WriteLine("Run Specific Tests : TestHost [/debug] [/exclude] [test_to_run ...]");
                Console.WriteLine("List Tests         : TestHost /list");
            }
            if (largs.Contains("/list")) {
                for (int i = 0; i < Cases.Length; i++) {
                    Console.WriteLine(Cases[i].Method.Name);
                }
                return 1;
            }

            if (largs.Contains("/debug")) {
                Array.ForEach(Directory.GetFiles(Environment.CurrentDirectory, "rubytest_*"), delegate(string file) {
                    try { File.Delete(file); } catch { /* nop */ }
                });

                ScriptDomainManager.Options.AssemblyGenAttributes =
                   AssemblyGenAttributes.GenerateStaticMethods | AssemblyGenAttributes.ILDebug |
                   AssemblyGenAttributes.SaveAndReloadAssemblies | AssemblyGenAttributes.EmitDebugInfo | AssemblyGenAttributes.GenerateDebugAssemblies;

                largs.Remove("/debug");

                isDebug = true;
            }

            bool excludeSelectedCases = false;
            if (largs.Contains("/exclude")) {
                excludeSelectedCases = true;
                largs.Remove("/exclude");
            }

            ScriptEnvironmentSetup ses = new ScriptEnvironmentSetup(true);
            ses.HostType = typeof(TestHost);

            _env = ScriptEnvironment.Create(ses);

            // Configure the EngineOptions
            ILanguageProvider rubyProvider = _env.GetLanguageProvider("rb");
            EngineOptions engineOptions = rubyProvider.GetOptionsParser().GetDefaultEngineOptions();
            if (largs.Contains("-X:Interpret")) {
                engineOptions.InterpretedMode = true;
                largs.Remove("-X:Interpret");
            }
            rubyProvider.GetEngine(engineOptions);

            int failedCount = 0;

            // Run attribute overrides args:
            if (TestCode.Trim().Length == 0) {
                // check whether there is a preselected case:
                IList<TestCase> selectedCases = new List<TestCase>();

                for (int i = 0; i < Cases.Length; i++) {
                    if (Cases[i].Method.IsDefined(typeof(RunAttribute), false)) {

                        //if (!isDebug) {
                        //    Console.Error.WriteLine("[Run] attribute should be applied only while debugging.");
                        //    return -1;
                        //}

                        selectedCases.Add(Cases[i]);
                    }
                }

                if (selectedCases.Count == 0 && largs.Count > 0) {
                    for (int i = 0; i < Cases.Length; i++) {
                        bool caseIsSpecified = largs.Contains(Cases[i].Method.Name);
                        if ((caseIsSpecified && !excludeSelectedCases) || (!caseIsSpecified && excludeSelectedCases)) {
                            selectedCases.Add(Cases[i]);
                        }
                    }
                } else if (selectedCases.Count > 0 && largs.Count > 0) {
                    Console.WriteLine("Arguments overrided by Run attribute.");
                } else if (selectedCases.Count == 0 && largs.Count == 0) {
                    selectedCases = Cases;
                }
            
                foreach (TestCase testCase in selectedCases) {
                    RunTestCase(testCase, ref failedCount);
                }
            
            } else {
                if (!isDebug) {
                    Console.Error.WriteLine("hardcoded test should be applied only while debugging.");
                    return -2;
                }

                Console.WriteLine("Running hardcoded test case");

                try {

                    for (int i = 0; i < RequiredFiles.Length; i += 2) {
                        File.CreateText(RequiredFiles[i]).WriteLine(RequiredFiles[i + 1]);
                    }

                    RunTestCase(Test, ref failedCount);

                } finally {
                    for (int i = 0; i < RequiredFiles.Length; i += 2) {
                        try {
                            File.Delete(RequiredFiles[i]);
                        } catch {
                            // nop
                        }
                    }
                }
            }

            // return failure on bad filter (any real failures throw)
            return failedCount;
        }

        private static void Test() {
            CompilerTest(TestCode);
        }

        private static void RunTestCase(TestCase/*!*/ testCase, ref int failedCount) {
            _currentTestName = testCase.Method.Name;

            Console.WriteLine("Executing {0}", _currentTestName);

            RubyOps.ClearGlobalSpace();

            try {
                testCase();
            } catch (Exception e) {
                Console.Error.WriteLine(e);
                failedCount++;
            } finally {
                ScriptDomainManager.CurrentManager.Snippets.Dump("rubytest_" + _currentTestName + ".snippets.dll");
            }
        }

        private static int _uniqueId = 0;

        private static ScriptModule CompilerTest(string/*!*/ code) {
            return CompilerTest(code, null);
        }

        private static ScriptModule CompilerTest(string/*!*/ code, ErrorSink sink) {
            SourceUnit unit;

            if (sink == null) {
                sink = new ErrorSink();
            }

            string name = "rubytest_" + _currentTestName + "_" + (_uniqueId++);
            unit = SourceUnit.CreateFileUnit(RB, name + ".rb", code);

            ScriptModule m = ScriptDomainManager.CurrentManager.CompileModule(name, unit);

            m.Execute();

            return m;
        }

        private class ErrorInfo {
            public string Message;
            public SourceSpan Span;
            public int Code;
            public Severity Severity;
        }

        private class LoggingErrorSink : ErrorSink {

            public List<ErrorInfo> Errors = new List<ErrorInfo>();
            private bool _suppressOutput;

            public LoggingErrorSink() {
                _suppressOutput = true;
            }

            public LoggingErrorSink(bool suppressOutput) {
                _suppressOutput = suppressOutput;
            }
            
            public override void Add(SourceUnit sourceUnit, string message, SourceSpan span, int errorCode, Severity severity) {
                base.Add(sourceUnit, message, span, errorCode, severity);

                if (_suppressOutput) {
                    Console.Error.WriteLine("{0}({1}:{2}): {3}: RB{4}: {5}", sourceUnit.Id, span.Start.Line, span.Start.Column,
                        severity, errorCode, message);
                }

                ErrorInfo info = new ErrorInfo();
                info.Message = message;
                info.Span = span;
                info.Code = errorCode;
                info.Severity = severity;
                Errors.Add(info);
            }
        }

        #endregion

        #region Ruby Language Tests

        private static void Scenario_RubyTokenizer1() {
            LoggingErrorSink log = new LoggingErrorSink();
            RBC.Tokenizer tokenizer = new RBC.Tokenizer(log, false);

            List<RBC.Tokens> tokens;

            tokens = GetRubyTokens(tokenizer, "print 'foo'");

            Assert(tokens.Count == 4 &&
                tokens[0] == RBC.Tokens.tIDENTIFIER &&
                tokens[1] == RBC.Tokens.tSTRING_BEG &&
                tokens[2] == RBC.Tokens.tSTRING_CONTENT &&
                tokens[3] == RBC.Tokens.tSTRING_END);

            log.Errors.Clear();

            tokens = GetRubyTokens(tokenizer, "print '");

            Assert(log.Errors.Count == 1 &&
                log.Errors[0].Severity == Severity.Error
            );

            Assert(tokens.Count == 3 &&
                tokens[0] == RBC.Tokens.tIDENTIFIER &&
                tokens[1] == RBC.Tokens.tSTRING_BEG &&
                tokens[2] == RBC.Tokens.tSTRING_END);
        }

        private static List<RBC.Tokens> GetRubyTokens(RBC.Tokenizer tokenizer, string source) {
            tokenizer.Initialize(SourceUnit.CreateSnippet(RB, source));
            List<RBC.Tokens> tokens = new List<RBC.Tokens>();
            RBC.Tokens token;
            while ((token = tokenizer.GetNextToken()) != RBC.Tokens.EOF) {
                tokens.Add(token);
            }

            return tokens;
        }

        private static void Scenario_RubyCategorizer1() {
            TestCategorizer(RB, "print 'foo' #bar", -1, new TokenInfo[] {
                new TokenInfo(new SourceSpan(new SourceLocation(0, 1, 1), new SourceLocation(5, 1, 6)), TokenCategory.Identifier, TokenTriggers.None),
                new TokenInfo(new SourceSpan(new SourceLocation(6, 1, 7), new SourceLocation(7, 1, 8)), TokenCategory.StringLiteral, TokenTriggers.None),
                new TokenInfo(new SourceSpan(new SourceLocation(7, 1, 8), new SourceLocation(10, 1, 11)), TokenCategory.StringLiteral, TokenTriggers.None),
                new TokenInfo(new SourceSpan(new SourceLocation(10, 1, 11), new SourceLocation(11, 1, 12)), TokenCategory.StringLiteral, TokenTriggers.None),
                new TokenInfo(new SourceSpan(new SourceLocation(12, 1, 13), new SourceLocation(16, 1, 17)), TokenCategory.LineComment, TokenTriggers.None),
            });

            TestCategorizer(RB, "a\r\nb", -1, new TokenInfo[] { 
                new TokenInfo(new SourceSpan(new SourceLocation(0, 1, 1), new SourceLocation(1, 1, 2)), TokenCategory.Identifier, TokenTriggers.None),   // a
                new TokenInfo(new SourceSpan(new SourceLocation(1, 1, 2), new SourceLocation(3, 1, 4)), TokenCategory.WhiteSpace, TokenTriggers.None),   // \r\n
                new TokenInfo(new SourceSpan(new SourceLocation(3, 2, 1), new SourceLocation(4, 2, 2)), TokenCategory.Identifier, TokenTriggers.None),   // b
            });

            //                             11111111 11222222222233 333
            //                   012345678901234567 89012345678901 234
            TestCategorizer(RB, "canvas.Event { |x|\nputs 'string'\n}", -1, new TokenInfo[] {
            //                   1234567890123456789 12345678901234 12
            //                            1111111111          11111   
                // line 1                    
                new TokenInfo(new SourceSpan(new SourceLocation(0, 1, 1), new SourceLocation(6, 1, 7)), TokenCategory.Identifier, TokenTriggers.None),          // canvas
                new TokenInfo(new SourceSpan(new SourceLocation(6, 1, 7), new SourceLocation(7, 1, 8)), TokenCategory.Delimiter, TokenTriggers.MemberSelect),   // .
                new TokenInfo(new SourceSpan(new SourceLocation(7, 1, 8), new SourceLocation(12, 1, 13)), TokenCategory.Identifier, TokenTriggers.None),        // Event
                new TokenInfo(new SourceSpan(new SourceLocation(13, 1, 14), new SourceLocation(14, 1, 15)), TokenCategory.Grouping, TokenTriggers.MatchBraces), // {
                new TokenInfo(new SourceSpan(new SourceLocation(15, 1, 16), new SourceLocation(16, 1, 17)), TokenCategory.Grouping, TokenTriggers.MatchBraces), // |
                new TokenInfo(new SourceSpan(new SourceLocation(16, 1, 17), new SourceLocation(17, 1, 18)), TokenCategory.Identifier, TokenTriggers.None),      // x
                new TokenInfo(new SourceSpan(new SourceLocation(17, 1, 18), new SourceLocation(18, 1, 19)), TokenCategory.Grouping, TokenTriggers.MatchBraces), // |
                // line 2
                new TokenInfo(new SourceSpan(new SourceLocation(19, 2, 1), new SourceLocation(23, 2, 5)), TokenCategory.Identifier, TokenTriggers.None),        // puts
                new TokenInfo(new SourceSpan(new SourceLocation(24, 2, 6), new SourceLocation(25, 2, 7)), TokenCategory.StringLiteral, TokenTriggers.None),     // '
                new TokenInfo(new SourceSpan(new SourceLocation(25, 2, 7), new SourceLocation(31, 2, 13)), TokenCategory.StringLiteral, TokenTriggers.None),    // string
                new TokenInfo(new SourceSpan(new SourceLocation(31, 2, 13), new SourceLocation(32, 2, 14)), TokenCategory.StringLiteral, TokenTriggers.None),   // '
                new TokenInfo(new SourceSpan(new SourceLocation(32, 2, 14), new SourceLocation(33, 2, 15)), TokenCategory.WhiteSpace, TokenTriggers.None),      // \n (significant)
                // line 3
                new TokenInfo(new SourceSpan(new SourceLocation(33, 3, 1), new SourceLocation(34, 3, 2)), TokenCategory.Grouping, TokenTriggers.MatchBraces),   // }
            });
        }

        private static void TestCategorizer(IScriptEngine engine, string src, int charCount, params TokenInfo[] expected) {
            if (charCount == -1) charCount = src.Length;

            ITokenCategorizer categorizer = engine.LanguageProvider.GetTokenCategorizer();

            categorizer.Initialize(null, SourceUnit.CreateSnippet(engine, src).GetReader(), SourceLocation.MinValue);
            IEnumerable<TokenInfo> actual = categorizer.ReadTokens(charCount);

            int i = 0;
            foreach (TokenInfo info in actual) {
                Assert(i < expected.Length);
                if (!info.Equals(expected[i])) {
#if DEBUG
                    Console.WriteLine(info.ToDebugString());
#endif
                    Assert(false);
                }
                i++;
            }
            Assert(i == expected.Length);
        }

        private static void Scenario_RubyNameMangling1() {
            Assert(RubyOps.UnmangleName("ip_stack") == "IpStack");  // TODO
            Assert(RubyOps.UnmangleName("stack") == "Stack");
            Assert(RubyOps.UnmangleName("this_is_my_long_name") == "ThisIsMyLongName");
            Assert(RubyOps.UnmangleName("") == "");
            Assert(RubyOps.UnmangleName("f") == "F");
            Assert(RubyOps.UnmangleName("fo") == "Fo");
            Assert(RubyOps.UnmangleName("foo") == "Foo");
            Assert(RubyOps.UnmangleName("foo_bar") == "FooBar");
            Assert(RubyOps.UnmangleName("ma_m") == "MaM");
        }

        private static void Scenario_RubyNameMangling2() {
            Assert(RubyOps.MangleName("IPStack") == "ip_stack"); // TODO
            Assert(RubyOps.MangleName("Stack") == "stack");
            Assert(RubyOps.MangleName("ThisIsMyLongName") == "this_is_my_long_name");
            Assert(RubyOps.MangleName("") == "");
            Assert(RubyOps.MangleName("F") == "f");
            Assert(RubyOps.MangleName("FO") == "fo");
            Assert(RubyOps.MangleName("FOO") == "foo");
            Assert(RubyOps.MangleName("FOOBar") == "foo_bar");
            Assert(RubyOps.MangleName("MaM") == "ma_m");
        }

        private static void Scenario_RubySimpleCall1() {
            AssertExceptionThrown<ArgumentException>(delegate {
                CompilerTest(@"
def foo a,c=1,*e
end

foo

");
            });
    
        }

        private static void Scenario_RubySimpleCall2() {
            AssertOutput(delegate {
                CompilerTest(@"
puts nil
");
            }, "nil");

        }

        private static void Scenario_RubySimpleCall3() {
            AssertOutput(delegate {
                CompilerTest(@"
y = nil
puts y

x = 'Foo'
puts x
");
            }, @"
nil
Foo");

        }

        private static void Scenario_RubyMethodMissing1() {
            AssertOutput(delegate {
                CompilerTest(@"
class C
  def method_missing(name, *a)
    puts name, a
  end
end

C.new.foo 1,2,3
");
            }, @"
foo
1
2
3
");

        }

        private static void Scenario_RubyMethodMissing2() {
            AssertExceptionThrown<MissingMethodException>(delegate {
                CompilerTest(@"unknown_method");
            }, delegate(MissingMethodException e) {
                return e.Message.StartsWith("undefined local variable or method");
            });
        }

        private static void Scenario_RubySingletons1() {
            AssertOutput(delegate {
                CompilerTest(@"
puts nil.to_s
puts true.to_s
puts false.to_s

puts nil | false
puts true & []
puts false ^ []
puts nil.nil?
puts nil.to_i
puts nil.to_f
");
            }, @"

true
false
false
true
true
true
0
0.0
");

        }

        private static void Scenario_RubyMath1() {
            AssertOutput(delegate {
                CompilerTest(@"
puts Math.acos(1.0)
puts Math.acos(1)
");
            }, @"
0.0
0.0");

        }

        private static void Scenario_RubyDefinedOperator1() {
            // TODO:
            AssertOutput(delegate() {
                CompilerTest(@"
puts(
defined? 1,

# TODO: undef var: defined? dummy,
nil,

defined? puts,
defined? String,
defined? $:,
#defined? Math::PI,
defined? a = 1,

# TODO: undef var! bug in Ruby?: defined? a,
nil,

defined? 42.times,

# TODO: undef var: defined? 1 + foo
nil

)
"
                    ); }, @"
expression
nil
method
constant
global-variable
assignment
nil
method
nil
");
        }

        private static void Scenario_RubyScopeParsing() {
            LoggingErrorSink log = new LoggingErrorSink();

            SourceUnitTree p;
            SourceUnit unit;

            unit = SourceUnit.CreateSnippet(RB, @"
                class c << G
                end
            ");

            p = new Parser().Parse(new CompilerContext(unit, new RubyCompilerOptions(), log));
            Assert(p == null && log.FatalErrorCount == 1);
            log.ClearCounters();

            unit = SourceUnit.CreateSnippet(RB, @"
                def goo(&b)
                    end

                    class C
                        def foo()
                           x.goo() { 
                                goo() {
                                    class << M
                                        def bar()
                                            goo() {
                                            }
                                        end
                                    end
                                }
                           } 
                        end
                    end

                BEGIN { goo1() { } }
                END { goo2() { } } 
            ");

            p = new Parser().Parse(new CompilerContext(unit));
            Assert(p != null && !log.AnyError);
            log.ClearCounters();

            unit = SourceUnit.CreateSnippet(RB, @"
                for x in array do
                    goo()
                end
            ");

            p = new Parser().Parse(new CompilerContext(unit));
            Assert(p != null && !log.AnyError);
            log.ClearCounters();
        }

        /// <summary>
        /// Tests that class lexical scopes are applied to method definitions.
        /// </summary>
        private static void Scenario_RubyScopes1() {
            AssertOutput(delegate() {
                CompilerTest(@"
class A; def foo; print 'A'; end; end
class B; def foo; print 'B'; end; end
A.new.foo
B.new.foo
");
            }, @"AB");
        }

        private static void Scenario_RubyScopes2() {
            CompilerTest(@"
def foo
    while (true) do
        class A
            foo do
                begin
                    puts
                rescue
                    foo do
                        class B
                            while (true) do
                                class C
                                    puts
                                rescue
                                    puts
                                end    
                            end
                        end    
                    end 
                end
            end
        end    
    end
end
");
        }
        
        /// <summary>
        /// Tests that variables defined in module/class locals scope are not visible outside.
        /// </summary>
        private static void Scenario_RubyScopes3() {
            AssertOutput(delegate() {
                CompilerTest(@"
y = 'var'
class C
    x = 'var'
end

def x; puts 'method'; end
def y; puts 'method'; end

puts x
puts y
");
            }, @"
method
var");
        }

        private static void Scenario_RubyNumericLiterals1() {
            AssertOutput(delegate() {
                CompilerTest(@"
puts(1)
puts(-1)
puts(+1)
puts(1.1)
puts(-1.1)
puts(+1.1)

x = 2.0
puts x
puts 2.0
puts 2.1560
");
            }, @"
1
-1
1
1.1
-1.1
1.1
2.0
2.0
2.156
");
        }

        private static void Scenario_RubyStrings1() {
            AssertOutput(delegate() {
                CompilerTest(@"
puts ""foo""
puts ""foo"" 'bar' ""baz""
puts ""foo#{""bar""}baz""
puts ""foo#{1+1;2+2;3+3}baz""
");
            }, @"
foo
foobarbaz
foobarbaz
foo6baz
");
        }

        private static void Scenario_RubyStrings2() {
            AssertOutput(delegate() {
                CompilerTest(@"
puts 'foobarbaz'[3,3]
");
            }, "bar");
        }

        private static void Scenario_RubyStrings3() {
            AssertOutput(delegate() {
                CompilerTest(@"
puts ""foo  bar"".split
");
            }, @"
foo
bar
");
        }

        private static void Scenario_RubyDeclarations1() {
            AssertOutput(delegate() {
                CompilerTest(@"
class C
  puts 'C'
end
");
            }, "C");
        }

        private static void Scenario_RubyDeclarations1A() {
            AssertOutput(delegate() {
                CompilerTest(@"
class C
  def foo
    print 'F'
  end
end

C.new.foo
");
            }, "F");
        }

        private static void Scenario_RubyDeclarations1B() {
            AssertOutput(delegate() {
                CompilerTest(@"
class C
  def f
    print 'F'
  end
end

class C
  def g
    print 'G'
  end
end

C.new.f
C.new.g
");
            }, "FG");
        }

        private static void Scenario_RubyDeclarations1C() {
            AssertOutput(delegate() {
                CompilerTest(@"
class C
  X = 1
end

class D < C
  Y = 2
end

print D::X, D::Y
");
            }, "12");
        }

        private static void Scenario_RubyDeclarations2() {
            AssertOutput(delegate() {
                CompilerTest(@"
class C
    def foo()
        puts ""This is foo in C.""
    end
    def C.sfoo()
        puts ""This is static foo in C.""
    end
end

class D < C
    def bar()
        puts ""This is bar in D""
        foo
    end
    def D.sbar()
        puts ""This is static bar in D.""
        sfoo
    end
end

def baz()
  puts 'This is baz, a global function'
end

D.sbar()

print 'Hello'
Kernel.print "" world""
puts '!'

D.new.bar
baz()
");
            },
@"This is static bar in D.
This is static foo in C.
Hello world!
This is bar in D
This is foo in C.
This is baz, a global function
");
        }

        private static void Scenario_RubyInclusions1() {
            AssertOutput(delegate() {
                CompilerTest(@"
module M
  def foo
    puts 'foo'
  end
end

class C
  include M
end

C.new.foo
");
            }, "foo");
        }

        private static void Scenario_RubyClassVersions1() {
            AssertOutput(delegate() {
                CompilerTest(@"
class C
  def m
    puts 'v1'
  end
end

C.new.m

class C
  def m
    puts 'v2'
  end
end

C.new.m
");
            },
@"
v1
v2
");
        }

        private static void Scenario_RubyClassVersions2() {
            AssertOutput(delegate() {
                CompilerTest(@"
module M
  def m; puts 'v1'; end
end

module N
  def m; puts 'v2'; end
end

class C
  include M
end

class D < C 
end

D.new.m

class D
  include N
end

D.new.m
");
            },
@"
v1
v2
");
        }

        private static void Scenario_RubyBlockExpressions1() {
            AssertOutput(delegate() {
                CompilerTest(@"
puts class Foo
  'A'
end

puts def bar
  'B'
end

puts module M
  'C'
end

puts begin
  'D'
end

x = ('E'; 'F')
puts x
");
            }, @"
A
nil
C
D
F");
        }

        private static void Scenario_RubyConstants1() {
            AssertOutput(delegate() {
                CompilerTest(@"
OUTER_CONST = 99
class Const
  def get_const
    CONST
  end
  
  puts CONST = OUTER_CONST + 1
end

class Const2 < Const
end

puts Const.new.get_const
puts Const::CONST
puts ::OUTER_CONST
puts Const::NEW_CONST = 123
puts Const2::CONST
");
            }, @"
100
100
100
99
123
100");
        }

        private static void Scenario_RubyConstants2() {
            AssertOutput(delegate() {
                CompilerTest(@"
class X
  class ::Y
    class X::W
    end
  end

  class Z
  end
end

puts X
puts Y
puts X::Z
puts X::W
");
            }, @"
X
Y
Z
W"); // TODO: should in fact print X::Z and X::W
        }

        private static void Scenario_RubyConstants3() {
            AssertOutput(delegate() {
                CompilerTest(@"
module M
  C = 1
  
  class D 
  end
end

M.constants.each { |x| puts x }
");
            }, @"
C
D");
        }

        private static void Scenario_RubyLocals1() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo()
  x = 1
  y = 2
  puts x + y
end

foo
");
            }, "3");
        }

        private static void Scenario_Assignment1() {
            AssertOutput(delegate() {
                CompilerTest(@"
a = 1
a += 2
puts a");
            }, @"3");
        }

        /// <summary>
        /// Order of evaluation.
        /// </summary>
        private static void Scenario_ParallelAssignment1() {
            AssertOutput(delegate() {
                CompilerTest(@"
def one; puts 'one'; 1; end
def two; puts 'two'; 2; end
def three; puts 'three'; 3; end

a,b = one,two,three
puts a.inspect,b.inspect
");
            }, @"
one
two
three
1
2
");
        }

        private static void Scenario_ParallelAssignment2() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo()
  x, y = 3, 4
  puts x, y
  x, y = y, x
  puts x, y
  x, y = 1
  puts x, y
  x, y = 5, 6, 7
  puts x, y
  z = (x, y = 5, 6, 7)
  puts z
end

foo
");
            }, @"
3
4
4
3
1
nil
5
6
5
6
7");
        }

        private static void Scenario_ParallelAssignment4() {
            AssertOutput(delegate() {
                CompilerTest(@"
ra = (a = *4)
rb = (b = *[4])
rc = (c = *[*4])
rd = (d = 1,*4)
re = (e = 1,*[4])
rf = (f = 1,*[*4])
puts a.inspect,b.inspect,c.inspect,d.inspect,e.inspect,f.inspect
puts ra.inspect,rb.inspect,rc.inspect,rd.inspect,re.inspect,rf.inspect
");
            }, @"
4
4
4
[1, 4]
[1, 4]
[1, 4]
4
4
4
[1, 4]
[1, 4]
[1, 4]
");
        }

        private static void Scenario_ParallelAssignment5() {
            AssertOutput(delegate() {
                CompilerTest(@"
r = (x,(y,(z1,z2)),(*u),v,w = 1,[*[1,2]],3,*4)

puts 'r = ' + r.inspect,
  'x = ' + x.inspect,
  'y = ' + y.inspect,
  'z1 = ' + z1.inspect,
  'z2 = ' + z2.inspect,
  'u = ' + u.inspect,
  'v = ' + v.inspect,
  'w = ' + w.inspect
");
            }, @"
r = [1, [1, 2], 3, 4]
x = 1
y = 1
z1 = 2
z2 = nil
u = [3]
v = 4
w = nil
");
        }

        /// <summary>
        /// Non-simple LHS, simple RHS. Difference between |LHS| > 0 (r0 and r3) and |LHS| == 0 (r1).
        /// </summary>
        private static void Scenario_ParallelAssignment6() {
            AssertOutput(delegate() {
                CompilerTest(@"
r0 = (x,y = [1,2])
r1 = (*v = [1,2])
r2 = (*w = *[1,2])
r3 = (p,*q = [1,2])
puts r0.inspect, r1.inspect, r2.inspect, r3.inspect, '*'
puts x.inspect, y.inspect, '*', v.inspect, '*', w.inspect, '*', p.inspect, q.inspect
");
            }, @"
[1, 2]
[[1, 2]]
[1, 2]
[1, 2]
*
1
2
*
[[1, 2]]
*
[1, 2]
*
1
[2]
");
        }

        /// <summary>
        /// Simple LHS and splat only RHS.
        /// </summary>
        private static void Scenario_ParallelAssignment7() {
            AssertOutput(delegate() {
                CompilerTest(@"
a = (ax = *1)
b = (bx = *[])
c = (cx = *[1])
d = (dx = *[1,2])

puts a.inspect, ax.inspect, b.inspect, bx.inspect, c.inspect, cx.inspect, d.inspect, dx.inspect
");
            }, @"
1
1
nil
nil
1
1
[1, 2]
[1, 2]
");
        }

        /// <summary>
        /// Simple RHS.
        /// </summary>
        private static void Scenario_ParallelAssignment8() {
            AssertOutput(delegate() {
                CompilerTest(@"
r1 = (a = [1,2])
r2 = (b,c = [1,2])
r3 = (d,e = *[1,2])
r4 = (f,g = 1)

puts r1.inspect, r2.inspect, r3.inspect, r4.inspect
puts b.inspect, c.inspect, d.inspect, e.inspect, f.inspect, g.inspect
");
            }, @"
[1, 2]
[1, 2]
[1, 2]
[1]
1
2
1
2
1
nil
");
        }

        /// <summary>
        /// Inner splat-only LHS.
        /// </summary>
        private static void Scenario_ParallelAssignment9() {
            AssertOutput(delegate() {
                CompilerTest(@"
c = ((*a),(*b) = [1,2],[3,4])
puts a.inspect, b.inspect, c.inspect
");
            }, @"
[[1, 2]]
[[3, 4]]
[[1, 2], [3, 4]]
");
        }

        /// <summary>
        /// Recursion in L(1,-).
        /// </summary>
        private static void Scenario_ParallelAssignment10() {
            AssertOutput(delegate() {
                CompilerTest(@"
ra = ((a,) = *[])
rb = ((b,) = 1,*[])
puts a.inspect, ra.inspect
puts b.inspect, rb.inspect
");
            }, @"
nil
[]
1
[1]
");
        }

        private static void Scenario_RubyBlockArgs1() {
            AssertOutput(delegate() {
                CompilerTest(@"
def a; yield; end 
def b; yield 1; end 
def c; yield 1,2; end 
def d; yield []; end 
def e; yield [1]; end 
def f; yield [1,2]; end 
def g; yield *[]; end;

a { |x| puts x.inspect }
b { |x| puts x.inspect }
c { |x| puts x.inspect }
d { |x| puts x.inspect }
e { |x| puts x.inspect }
f { |x| puts x.inspect }
g { |(x,)| puts x.inspect }
");
            }, @"
nil
1
[1, 2]
[]
[1]
[1, 2]
nil
");
            Debug.Assert(RB.ExecutionContext.RuntimeErrorSink.WarningCount == 2);
        }

        private static void Scenario_RubyBlockArgs2() {
            AssertOutput(delegate() {
                CompilerTest(@"
def a; yield; end 
def b; yield 1; end 
def c; yield 1,2; end 
def d; yield []; end 
def e; yield [1]; end 
def f; yield [1,2]; end 

a { |x,y| puts x.inspect, y.inspect }
b { |x,y| puts x.inspect, y.inspect }
c { |x,y| puts x.inspect, y.inspect }
d { |x,y| puts x.inspect, y.inspect }
e { |x,y| puts x.inspect, y.inspect }
f { |x,y| puts x.inspect, y.inspect }
");
            }, @"
nil
nil
1
nil
1
2
nil
nil
1
nil
1
2
");
        }

        /// <summary>
        /// RHS is list, LHS is not simple, but contains splatting.
        /// </summary>
        private static void Scenario_RubyBlockArgs3() {
            AssertOutput(delegate() {
                CompilerTest(@"
def baz
   yield [1,2,3]
end
baz { |*a| puts a.inspect }
");
            }, @"[[1, 2, 3]]");
        }

        /// <summary>
        /// !L(1,-) && R(0,*), empty array to splat.
        /// </summary>
        private static void Scenario_RubyBlockArgs4() {
            AssertOutput(delegate() {
                CompilerTest(@"
def y
   yield *[]
end

y { |*a| puts a.inspect }
");
            }, @"[]");
        }

        private static void Scenario_RubyParams1() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo(a,b)
    puts a + b
end

puts foo(1,2)
");
            },
            @"
3
nil");
        }

        private static void Scenario_RubyParams2() {
// TODO: missing DLR support
//            AssertOutput(delegate() {
//                CompilerTest(@"
//def foo(a, b, c = a + b, d = c + 1)
//  puts a,b,c,d
//end
//
//foo(1,2) 
//");
//            },
//            @"
//1
//2
//3
//4
//");
        }
        
        private static void Scenario_RubyBlocks0() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo 
  yield
end

foo { print 'A' }
foo { print 'B' }
foo { print 'C' }
");
            }, "ABC");
        }

        private static void Scenario_RubyBlocks1() {
            AssertOutput(delegate() {
                CompilerTest(@"
3.times { |x| print x }
");
            }, "012");
        }

        private static void Scenario_RubyBlocks2() {
            AssertExceptionThrown<MissingMethodException>(delegate() {
                CompilerTest(@"
3.times { |x| z = 1 }
puts z # undef z
");
            });
        }

        private static void Scenario_RubyBlocks3() {
            AssertOutput(delegate() {
                CompilerTest(@"
class C
  def foo 
    puts yield(1,2,3)
  end
end

C.new.foo { |a,b,c| puts a,b,c; 'foo' }
");
            }, @"
1
2
3
foo
");
        }

        // TODO:
        public static void Scenario_DLRAST_Comma1() {
            MSA.CodeBlock cb = Ast.CodeBlock("foo");
            
            MethodInfo m = typeof(System.Console).GetMethod("WriteLine", new Type[] { typeof(string), typeof(object) });

            cb.Body = Ast.Return(Ast.Call(null, m, 
                Ast.Constant("A"), // problem: value on stack while entering try-catch
                Ast.Comma(1, 
                    Ast.Void(Ast.Try().Catch(typeof(Exception))),
                    Ast.Constant("B")
                )
            ));

            TestDlrAst(cb);
        }

        private static object TestDlrAst(MSA.CodeBlock block) {
            block.BindClosures();
            // TODO:
            //return block.CreateDelegate<Function<object>>(new CompilerContext(new SourceCodeUnit(RubyEngine.CurrentEngine, "foo")))();
            return null;
        }

        private static void Scenario_RubyBlocks4() {
            // TODO: parser bug - no block passed to the function
            //            AssertOutput(delegate() {
            //                CompilerTest(@"
            //def foo 
            //    puts yield(1,2,3)
            //end
            //
            //foo { |a,b,c| puts a,b,c; 'foo' }
            //");
            //                        }, @"
            //1
            //2
            //3
            //foo
            //");
        }

        private static void Scenario_RubyBlocks5() {
            // TODO: block_given?
            //            AssertOutput(delegate() {
            //                CompilerTest(@"
            //class C
            //  def foo 
            //    puts block_given?
            //  end
            //end
            //
            //C.new.foo { puts 'goo' }
            //C.new.foo
            //");
            //            }, @"
            //1
            //2
            //3
            //foo
            //");
        }

        /// <summary>
        /// Return, yield and retry in a method.
        /// </summary>
        private static void Scenario_RubyBlocks6() {
            AssertOutput(delegate() {
                CompilerTest(@"
def do_until(cond)
  if cond then return end
  yield
  retry
end

i = 0
do_until(i > 4) do
  puts i
  i = i + 1
end
");
            }, @"
0
1
2
3
4
");
        }

        /// <summary>
        /// Break in a block.
        /// </summary>
        private static void Scenario_RubyBlocks7() {
            AssertOutput(delegate() {
                CompilerTest(@"
x = 4.times { |x|
  puts x
  break 'foo'
}
puts x
");
            }, @"
0
foo
");
        }

        /// <summary>
        /// Redo in a block.
        /// </summary>
        private static void Scenario_RubyBlocks8() {
            AssertOutput(delegate() {
                CompilerTest(@"
i = 0
x = 2.times { |x|
  puts x
  i = i + 1
  if i < 3 then redo end
}
puts x
");
            }, @"
0
0
0
1
2
");
        }

        /// <summary>
        /// Next in a block.
        /// </summary>
        private static void Scenario_RubyBlocks9() {
            AssertOutput(delegate() {
                CompilerTest(@"
i = 0
x = 5.times { |x|
  puts x
  i = i + 1  
  if i < 3 then next end
  puts 'bar'
}
");
            }, @"
0
1
2
bar
3
bar
4
bar
");
        }

        /// <summary>
        /// Retry in a block.
        /// </summary>
        private static void Scenario_RubyBlocks10() {
            AssertOutput(delegate() {
                CompilerTest(@"
i = 0
3.times { |x| 
  puts x
  i = i + 1
  if i == 2 then retry end
}
");
            }, @"
0
1
0
1
2
");
        }

        /// <summary>
        /// Return with stack unwinding.
        /// </summary>
        private static void Scenario_RubyBlocks11() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo(a)
    puts ""begin #{a}""
    if a == 4 then
        1.times { |x|
            begin
                puts 'in block 1'
                1.times { |y| 
                    begin
                        puts 'in block 2'
                        return
                    ensure
                        puts ""ensure 2""
                    end
                }
            ensure
                puts ""ensure 1""
            end
        }
    end
  
    foo(a - 1)
    puts ""end #{a}""
ensure
    puts ""ensure foo #{a}""
end

puts 'before'
foo 6
puts 'after'
");
            }, @"
before
begin 6
begin 5
begin 4
in block 1
in block 2
ensure 2
ensure 1
ensure foo 4
end 5
ensure foo 5
end 6
ensure foo 6
after
");
        }

        private static void Scenario_RubyBlocks12() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo
  yield 1,2,3
end

foo { |a,*b| puts a,'-',b }
");
            }, @"
1
-
2
3
");
        }

        private static void Scenario_RubyBlocks13() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo
  yield 1,2,3
end

foo { |a,b| puts a,b }
");
            }, @"
1
2");
        }

        private static void Scenario_RubyProcs1() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo x,y,&f
  yield x,y
  f[3,4]
end

foo(1,2) do |a,b|
  puts a,b
end
");
            }, @"
1
2
3
4
");
        }

        private static void Scenario_RubyForLoop1() {
            AssertOutput(delegate() {
                CompilerTest(@"
for a in [1,2,3]
    x = 'ok'
    print a
end

print x         # x visible here, for-loop doesn't define a scope
");
            }, "123ok");
        }

        private static void Scenario_RubyForLoop2() {
            ScriptModule module = ScriptDomainManager.CurrentManager.CreateModule("x");
            module.SetVariable("list", Script.Evaluate("py", "[1,2,3]"));

            AssertOutput(delegate() {
                RB.Execute(@"
for a in list
    print a
end
", module);
            }, "123");
        }

        private static void Scenario_RubyWhileLoop1() {
            AssertOutput(delegate() {
                CompilerTest(@"
i = 0
x = while i < 4 do 
  puts i
  i = i + 1
end
puts x
");
            }, @"
0
1
2
3
nil
");
        }

        private static void Scenario_RubyWhileLoop2() {
            AssertOutput(delegate() {
                CompilerTest(@"
i = 3
x = while i > 0 do 
  puts i
  if i == 2 then
    break
  end
  i = i - 1
end
puts x
");
            }, @"
3
2
nil
");
        }

        /// <summary>
        /// Break in a while loop.
        /// </summary>
        private static void Scenario_RubyWhileLoop3() {
            AssertOutput(delegate() {
                CompilerTest(@"
i = 3
x = while i > 0 do 
  puts i
  if i == 2 then
    break 'foo'
  end
  i = i - 1
end
puts x
");
            }, @"
3
2
foo
");
        }

        /// <summary>
        /// Redo in a while loop.
        /// </summary>
        private static void Scenario_RubyWhileLoop4() {
            AssertOutput(delegate() {
                CompilerTest(@"
i = 3
j = 2
x = while i > 0 do 
  puts i
  if i == 2 and j > 0 then
    j = j - 1
    redo
  end
  i = i - 1
end
puts x
");
            }, @"
3
2
2
2
1
nil
");
        }

        /// <summary>
        /// Next in a while loop.
        /// </summary>
        private static void Scenario_RubyWhileLoop5() {
           AssertOutput(delegate() {
                CompilerTest(@"
i = 3
j = 2
x = while i > 0 do 
  puts i
  if i == 2 and j > 0 then
    j = j - 1
    next 'foo'
  end
  i = i - 1
end
puts x
");
            }, @"
3
2
2
2
1
nil
");
        }

        /// <summary>
        /// Loop break from within class declaration.
        /// </summary>
        private static void Scenario_RubyWhileLoop6() {
            AssertOutput(delegate() {
                CompilerTest(@"
i = 0
while i < 5 do
  puts i

  class C
    puts 'in C'
    break
  end
  
  i = i + 1
end
");
            }, @"
0
in C
");
        }

        private static void Scenario_RubyUntilLoop1() {
            AssertOutput(delegate() {
                CompilerTest(@"
i = 1
until i > 3 do
  puts i
  i = i + 1
end
");
            }, @"
1
2
3");
        }

        private static void Scenario_RubyReturnValues1() {
            AssertOutput(delegate() {
                CompilerTest(@"
x = while true do
  break 1,2,3
end
puts x
");
            }, @"
1
2
3
");
        }

        private static void Scenario_RubyReturnValues2() {
            AssertOutput(delegate() {
                CompilerTest(@"
x = while true do
  break 1 => 2, 3 => 4
end
puts x
");
            }, @"1234");
        }

        private static void Scenario_RubyReturnValues3() {
            AssertOutput(delegate() {
                CompilerTest(@"
x = while true do
  break 'a', 'b', 1 => 2, 3 => 4
end
puts x
");
            }, @"
a
b
1234");
        }

        private static void Scenario_RubyReturnValues4() {
            AssertOutput(delegate() {
                CompilerTest(@"
x = while true do
  break 'a', 'b', 1 => 2, 3 => 4, *['A', 'B']
end
puts x
");
            }, @"
a
b
1234
A
B");
        }

        private static void Scenario_RubyReturnValues5() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo
  return 1,2,3, 4 => 5, *[6,7]
end
puts foo
");
            }, @"
1
2
3
45
6
7
");
        }

        private static void Scenario_RubyReturnValues6() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo
  return *$x = [1,2]
end
$y = foo

puts $x.object_id == $y.object_id
puts $x.inspect
");
            }, @"
true
[1, 2]");
        }        
        
        private static void Scenario_RubyClosures1() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo
    y = 10
    3.times { |x| puts x + y }
end

foo
");
            }, @"
10
11
12");
        }

        private static void Scenario_RubyGlobals1() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo()
    $x = 1
    $y = 2
end

foo

puts $x + $y
");
            }, "3");
        }

        private static void Scenario_RubyReturn1() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo()
    'foo' # TODO: return 'foo'
end

puts foo
");
            },
            "foo");
        }

        private static void Scenario_RubyEval1() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo()
    a = 2
    eval('puts 2') # TODO a
end

foo
");
            }, "2");
        }

        public class TextBox {
            private string _text;

            public string Text {
                get { return _text; }
                set { _text = value; }
            }

            public TextBox(string text) {
                _text = text;
            }
        }

    
        private static void Scenario_RubySilverlight1() {

            //            SourceFileUnit unit = new SourceFileUnit(RB, "codebehind.rb", "codebehind", @"
            //def on_click(sender, args)
            //    text1.Text = 'Hello from Ruby'
            //end
            //");
            //            ScriptModule module = ScriptDomainManager.CurrentManager.CompileModule("XamlScriptModule", null, null, null, unit);
            //            module.Execute();

            //            module.FileName = "MyPage.xaml";

            //            TextBox text1 = new TextBox("foo");
            //            module.SetVariable("text1", text1);

            //            module.Execute();

            //            object mo;
            //            module.TryGetVariable("on_click", out mo);
            //            EventHandler handler = (EventHandler)Ops.GetDelegate(mo, typeof(EventHandler));
            //            handler(new object(), new EventArgs());

            //            Assert(text1.Text == "Hello from Ruby");
        }

        private static void Scenario_RubySilverlight2() {

            //    IScriptModule module = ScriptEnvironment.GetEnvironment().CreateModule("XamlScriptModule", new MyDictionary(),
            //        new SourceCodeUnit(RB, "puts 'hello'").Compile(),
            //        new SourceCodeUnit(RB, "puts 'world'").Compile()
            //    );

            //    module.Execute();
        }

        private class MyDictionary : CustomSymbolDictionary {

            private SymbolId _domainSymbol = SymbolTable.StringToId("Domain");

            public override SymbolId[] GetExtraKeys() {
                return new SymbolId[] { _domainSymbol };
            }

            protected override bool TrySetExtraValue(SymbolId key, object value) {
                if (key == _domainSymbol) {
                    throw new MemberAccessException("Domain variable is readonly");
                }
                return false;
            }

            protected override bool TryGetExtraValue(SymbolId key, out object value) {
                if (key == _domainSymbol) {
                    value = AppDomain.CurrentDomain;
                    return true;
                }

                value = null;
                return false;
            }
        }

        private static void Scenario_RubyConsole1() {
            
            AssertOutput(delegate() {
                RB.ExecuteInteractiveCode("class C; def foo() puts 'foo'; end end");
                RB.ExecuteInteractiveCode("C.new.foo");
            }, @"
=> nil
foo
=> nil");      
        }

        private static void Scenario_RubyConsole2() {
            // TODO: interop
            ScriptModule module = ScriptDomainManager.CurrentManager.CreateModule("Scenario_RubyConsole2");
            module.SetVariable("a", 0);
            RB.Execute("10.times { |x| a = a + x + 1}", module);
            object a = module.LookupVariable("a");
            Assert((int)a == 55);

            module.SetVariable("b", 1);
            RB.Execute("10.times { |x| b = b + x + 1}", module);
            object b = module.LookupVariable("b");
            Assert((int)b == 56);
        }

        private static void Scenario_RubyConsole3() {
            // TODO: bug in top-level scope

            //            ScriptModule module = ScriptDomainManager.CurrentManager.CreateModule("Scenario_RubyConsole3");
            //            RB.Execute(@"
            //for i in [11] do
            //    j = 1
            //end", module);
            //            object a = module.LookupVariable("j");
            //            Assert((int)a == 1);
        }

        public class MyFoo {
            private int _var = 999;

            public int Var {
                get { return _var; }
                set { _var = value; }
            }

            public MyFoo() {
                Console.WriteLine("Constructed");
            }

            public void Dump() {
                Console.WriteLine(_var);
            }

            public static void SayHello() {
                Console.WriteLine("Hello");
            }
        }

        public interface IFoo {
            int Goo();
        }

        public class MyBar : MyFoo, IFoo {
            public int Goo() {
                return 1234;
            }
        }

        public class MyEnumerableBar : MyFoo, IEnumerable {
            public IEnumerator GetEnumerator() {
                yield return 1;
                yield return 2;
                yield return 3;
            }
        }

        private static void Scenario_RubyInterop1() {
// TODO:
//            RubyOps.SetConstant(RubyEngine.CurrentEngine.DefaultContext, TypeCache.Object, SymbolTable.StringToId("MyFoo"),
//                DynamicHelpers.GetDynamicTypeFromType(typeof(MyFoo)));

//            AssertOutput(delegate() {
//                CompilerTest(@"
//C = MyFoo.new
//C.Var = 1
//C.Dump
//MyFoo.SayHello
//");
//            }, @"
//Constructed
//1
//Hello");
        }

        private static void Scenario_RubyInterop1A() {
// TODO:
//            RubyOps.SetConstant(RubyEngine.CurrentEngine.DefaultContext, TypeCache.Object, SymbolTable.StringToId("MyFoo"),
//                DynamicHelpers.GetDynamicTypeFromType(typeof(MyFoo)));

//            AssertOutput(delegate() {
//                CompilerTest(@"
//MyFoo.say_hello
//");
//            }, @"Hello");

        }

        private static void Scenario_RubyInterop2() {
// TODO:
//            DynamicType dt = DynamicHelpers.GetDynamicTypeFromType(typeof(MyBar));
//            RubyOps.SetConstant(RubyEngine.CurrentEngine.DefaultContext, TypeCache.Object, SymbolTable.StringToId("MyBar"), dt);
//            ScriptModule m = null;
//            AssertOutput(delegate() {
//                m = CompilerTest(@"
//c = MyBar.new
//puts c.Goo
//puts c.Var
//");
//            }, @"
//Constructed
//1234
//999
//");
//            object c = m.LookupVariable("c");
//            object v;
//            RB.TryGetObjectMemberValue(c, "Var", out v);
//            AssertEquals(v, 999);
        }

        private static void Scenario_RubyInterop3() {
// TODO:
//            DynamicType dt = DynamicHelpers.GetDynamicTypeFromType(typeof(MyEnumerableBar));
//            RubyOps.SetConstant(RubyEngine.CurrentEngine.DefaultContext, TypeCache.Object, SymbolTable.StringToId("MyEnumerableBar"), dt);

//            AssertOutput(delegate() {
//                CompilerTest(@"
//MyEnumerableBar.new.each { |x| puts x }
//");
//            }, @"
//Constructed
//1
//2
//3
//");
        }

        private static void Scenario_RubyInterop4() {
            ScriptModule module = ScriptDomainManager.CurrentManager.CreateModule("Scenario_RubyConsole1");
            module.SetVariable("canvas", "<Canvas>");

            AssertOutput(delegate() {
                RB.Execute("puts canvas", module);
            }, "<Canvas>");
        }

        private static void Scenario_RubyArrays1() {
            AssertOutput(delegate() {
                CompilerTest(@"
puts Array.[]('a','b','c')
puts Array[1,2,3]
puts ['e','f','g']
");
            }, String.Format("a{0}b{0}c{0}1{0}2{0}3{0}e{0}f{0}g{0}", Environment.NewLine));
        }

        private static void Scenario_RubyArrays2() {
            AssertOutput(delegate() {
                CompilerTest(@"
a = ['e',['f'],'g']
a[2] = a[0]
print a[2]
print a[1][0]
");
            }, "ef");
        }

        private static void Scenario_RubyArrays3() {
            AssertOutput(delegate() {
                CompilerTest(@"
puts %w{hello world}
puts %w<cup<T> cup<co-phi>>
puts %w{hello w#{0}r#{1}d}
puts %W{hello w#{0}r#{1}d}
");
           }, @"
hello
world
cup<T>
cup<co-phi>
hello
w#{0}r#{1}d
hello
w0r1d
");
        }

        private static void Scenario_RubyArrays4() {
            AssertOutput(delegate() {
                CompilerTest(@"
a = [*x = [1,2]]
puts a.object_id == x.object_id
puts a.inspect
");
            }, @"
true
[1, 2]");
        }

        private static void Scenario_RubyArrays5() {
            AssertOutput(delegate() {
                CompilerTest(@"
a = [*4]
b = [*[4]]
c = [*[*4]]
d = [*[*[4]]]
puts a.inspect,b.inspect,c.inspect,d.inspect
");
            }, @"
[4]
[4]
[4]
[4]
");
        }
        
        private static void Scenario_RubyArrays6() {
            AssertOutput(delegate() {
                CompilerTest(@"
a = [1,*[[],[*4], *[*[]]]]
puts a.inspect
");
            }, @"[1, [], [4]]");
        }

        private static void Scenario_RubyHashes1A() {
            AssertOutput(delegate() {
                CompilerTest(@"
puts Hash.[](1,'a',2,'b')
");
            }, "1a2b");
        }

        private static void Scenario_RubyHashes1B() {
            AssertOutput(delegate() {
                CompilerTest(@"
puts Hash.[]()
");
            }, "");
        }

        private static void Scenario_RubyHashes1C() {
            AssertExceptionThrown<ArgumentException>(delegate() {
                CompilerTest(@"
puts Hash.[](1)
");
            });
        }

        private static void Scenario_RubyHashes2() {
            AssertOutput(delegate() {
                CompilerTest(@"
x = { 1 => 'a', 2 => 'b', 3 => 'c' }
puts x
");
            }, "1a2b3c");
        }

        private static void Scenario_RubyHashes3() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo(a,b,c)
  puts a,b,c
end

foo Hash.[](1 => 'a', 2 => 'b', 3 => 'c'), { 1 => 'a', 2 => 'b', 3 => 'c' }, 'Q' => 'W', 'E' => 'R', 'T' => 'Y'
");
            }, @"
1a2b3c
1a2b3c
QWERTY
");
        }

        private static void Scenario_RubyHashes4() {
            AssertOutput(delegate() {
                CompilerTest(@"
class C
    def []=(a,b)
      print a,b
    end
end

C.new[1 => 2, 3 => 4] = 5
");
            }, @"12345");
        }

        private static void Scenario_RubyArgSplatting1() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo(a,b,c)
  print a,b,c
end

foo(*[1,2,3])
");
            }, @"123");
        }

        private static void Scenario_RubyArgSplatting2() {
            AssertOutput(delegate() {
                CompilerTest(@"
class C
    def []=(a,b,c)
      print a,b,c
    end
end

x = [1,2]
C.new[*x] = 3
C.new[1, *[2]] = 3
");
            }, @"123123");
        }

        private static void Scenario_RubyArgSplatting3() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo(a,b,c)
  print a,b,c
  puts
end

foo(1,2,*3)
foo(1,2,*nil)
");
            }, @"
123
12nil");
        }

        private static void Scenario_RubyBoolExpressions1() {
            AssertOutput(delegate() {
                CompilerTest(@"
puts '!'
puts !false
puts !true
puts !nil
puts !0
puts !'foo'
puts '!!'
puts !!false
puts !!true
puts !!nil
puts !!0
puts !!'foo'
puts '!!!'
puts !!!false
puts !!!true
puts !!!nil
puts !!!0
puts !!!'foo'
");
            }, @"
!
true
false
true
false
false
!!
false
true
false
true
true
!!!
true
false
true
false
false");
        }

        private static void Scenario_RubyBoolExpressions2() {
            AssertOutput(delegate() {
                CompilerTest(@"
def t; print 'T '; true; end
def f; print 'F '; false; end

puts(t && t)
puts(f && t)
puts(t && f)
puts(f && f)

puts(t || t)
puts(f || t)
puts(t || f)
puts(f || f)

puts(f || f && t && t)
");
            }, @"
T T true
F false
T F false
F false
T true
F T true
T true
F F false
F F false
");
        }

        private static void Scenario_RubyBoolExpressions3() {
            AssertOutput(delegate() {
                CompilerTest(@"
def t; print 'T '; true; end
def f; print 'F '; false; end

puts(x = (t and t))
puts(x = (f and t))
puts(x = (t and f))
puts(x = (f and f))

puts(x = (t or t))
puts(x = (f or t))
puts(x = (t or f))
puts(x = (f or f))

puts(x = (f or f and t and t))
");
            }, @"
T T true
F false
T F false
F false
T true
F T true
T true
F F false
F F false
");
        }

        private static void Scenario_RubyBoolExpressions4() {
            AssertOutput(delegate() {
                CompilerTest(@"
x = 'x'
y = 'y'
z = 'z'

a = ((x = 2.0) and (y = nil) and (z = true))
puts a,x,y,z
");
            } , @"
nil
2.0
nil
z
");
        }

        /// <summary>
        /// Else-if clauses.
        /// </summary>
        private static void Scenario_RubyIfExpression1() {
            AssertOutput(delegate() {
                CompilerTest(@"
puts(if nil then 1 end)
puts(if 1 then 1 end)
puts(if nil then 1 else 2 end)
puts(if 1 then 1 else 2 end)
puts(if nil then 1 elsif nil then 2 end)
puts(if nil then 1 elsif 1 then 2 end)
puts(if nil then 1 elsif nil then 2 else 3 end)
puts(if nil then 1 elsif 1 then 2 else 3 end)
");
            }, @"
nil
1
2
1
nil
2
3
2
");
        }

        /// <summary>
        /// Bodies.
        /// </summary>
        private static void Scenario_RubyIfExpression2() {
            AssertOutput(delegate() {
                CompilerTest(@"
puts(if nil then end)
puts(if 1 then end)
puts(if 1 then 1;11;111 end)
puts(if nil then 1 else 2;22 end)
");
            }, @"
nil
nil
111
22
");
        }

        private static void Scenario_RubyUnlessExpression1() {
            AssertOutput(delegate() {
                CompilerTest(@"
puts(unless nil then 1 end)
puts(unless 1 then 1 end)
");
            }, @"
1
nil
");
        }

        private static void Scenario_RubyConditionalExpression1() {
            AssertOutput(delegate() {
                CompilerTest(@"
x = true ? 1 : 'foo'
y = nil ? 2.0 : 'foo'
z = 'foo' || 2
u = 3 && nil

puts x,y,z,u
");
            }, @"
1
foo
foo
nil
");
        }

        private static void Scenario_RubyRequire1() {
            try {
                File.WriteAllText("a.rb", @"
C = 123
");
                AssertOutput(delegate() {
                    CompilerTest(@"
puts(require('a'))
puts C
");
                }, @"
true
123
");
            } finally {
                File.Delete("a.rb");
            }
        }

        private static void Scenario_RubyRequire2() {
            try {
                File.WriteAllText("a.rb", @"
C = 123
");
                AssertExceptionThrown<MissingMemberException>(delegate() {
                    CompilerTest(@"
puts(load('a',true))
puts C
");
                });
            } finally {
                File.Delete("a.rb");
            }
        }

        private static void Scenario_RubyRequire3() {
            try {
                File.WriteAllText("b.py", @"
def format(format, *args):
  return format % (args)

x = 'Python'
");
                AssertOutput(delegate() {
                    CompilerTest(@"
#TODO: maybe we don't need to return a module, we can mix it in instead (load 'foo', true will do)
a = require('b')
puts a
puts a.x
puts a.format('Hello from %s on %s!', 'Ruby', 'Silverlight')
");
                }, @"
Microsoft.Scripting.ScriptModule
Python
Hello from Ruby on Silverlight!");

            } finally {
                File.Delete("b.py");
            }
        }

        public class C {
        }

        public static void OnEvent(C proc, BlockReturnReasonHolder returnReason, Form sender, object e) {
            Console.WriteLine("fired!");
            sender.Close();
        }

        private static void Scenario_ClrInteropEvents1() {
            //Form form = new Form();
            //EventInfo e = typeof(Form).GetEvent("Shown");

            //MSA.CodeBlock block = Ast.EventHandlerBlock("#handler", e);

            //C proc = new C();

            //MSA.Expression[] args = new MSA.Expression[block.Parameters.Count + 2];
            //args[0] = Ast.RuntimeConstant(proc);
            //args[1] = Ast.New(BlockReturnReasonHolder.Constructor);
            //Ast.ReadAll(block.Parameters, args, 2);

            //block.Body = Ast.Return(Ast.Call(null, new Action<C, BlockReturnReasonHolder, Form, EventArgs>(OnEvent).Method, args));

            //EventHandler d = (EventHandler)block.CreateDelegate(typeof(EventHandler), RubyEngine.CurrentEngine.DefaultBinder);

            //form.Shown += new EventHandler(d);

            //AssertOutput(delegate() {
            //    Application.Run(form);
            //}, "fired!");

            // TODO: block referencing
            //MSA.CodeBlock block = Ast.CodeBlock("shared"); //Ast.EventHandlerBlock("#handler", e);
            //MSA.Variable v = block.CreateLocalVariable(SymbolTable.StringToId("foo"), typeof(object));
            //block.Body = Ast.Return(Ast.Assign(v, Ast.Call(null, new Function(OnEvent).Method)));

            //MSA.CodeBlock main = Ast.CodeBlock("main");
            //main.Body = Ast.Block(
            //    Ast.Statement(Ast.CodeBlockExpression(block, false)),
            //    Ast.Statement(Ast.CodeBlockReference(SourceSpan.None, block, false, false)),
            //    Ast.Return(Ast.Null())
            //);

            //main.BindClosures();
        }

        private static void Scenario_ClrInterop2() {
            AssertOutput(delegate() {
                CompilerTest(@"
require 'mscorlib'
b = System::Text::StringBuilder.new
b.Append 1
b.Append '-'
b.Append true
puts b.to_string
puts b.length
");
            }, @"
1-True
6
");
        }

        private static void Scenario_RubyEvents1() {
            AssertOutput(delegate() {
                CompilerTest(@"
require 'System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
require 'System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a'


Form = System::Windows::Forms::Form

f = Form.new

x = 'outer var'

f.shown do |sender, args|
    puts x
    sender.close
end

f.Text = 'hello'
f.BackColor = System::Drawing::Color.Green

System::Windows::Forms::Application.run f
");
            }, "outer var");
        }

        private static void Scenario_RubyEngine1() {
            object x = RB.Evaluate("1 + 1");
            AssertEquals(x, 2);
        }

        private static void Scenario_RubyInteractive() {
            AssertOutput(delegate() {
                RB.ExecuteInteractiveCode("1+1");
            }, "=> 2");
        }

        private static void Scenario_RubyExceptions1() {
            AssertExceptionThrown<RuntimeError>(delegate() {
                CompilerTest(@"raise");
            });
        }

        private static void Scenario_RubyExceptions1A() {
            AssertExceptionThrown<RuntimeError>(delegate() {
                CompilerTest(@"raise 'foo'");
            });
        }
        
        private static void Scenario_RubyExceptions2A() {
            AssertExceptionThrown<NotImplementedError>(delegate() {
                CompilerTest(@"
$! = NotImplementedError.new
raise");
            });
        }

        private static void Scenario_RubyExceptions2B() {
            AssertExceptionThrown<InvalidOperationException>(delegate() {
                CompilerTest("$! = NotImplementedError");
            });
        }

        private static void Scenario_RubyExceptions2C() {
            AssertOutput(delegate() {
                CompilerTest(@"
x = NotImplementedError.new 'hello'
puts x.message

x.message[0] = ?H
puts x.message

x.initialize                    # TODO: when visibility checks are on, this will fail; need send here
puts x.message

x.initialize 'Bye'              # TODO: when visibility checks are on, this will fail; need send here
puts x.message
");
            }, @"
hello
Hello
NotImplementedError
Bye
");
        }

        private static void Scenario_RubyExceptions2D() {
            AssertOutput(delegate() {
                CompilerTest(@"
x = IOError.new 'hello'
puts x.message

x.message[0] = ?H
puts x.message

x.initialize                    # TODO: when visibility checks are on, this will fail; need send here
puts x.message

x.initialize 'Bye'              # TODO: when visibility checks are on, this will fail; need send here
puts x.message
");
            }, @"
hello
Hello
IOError
Bye
");
        }

        private static void Scenario_RubyExceptions3() {
            AssertOutput(delegate() {
                CompilerTest(@"
begin
  raise
  print 'U'
rescue
  print 'X'
end
");
            }, "X");
        }

        private static void Scenario_RubyExceptions4() {
            AssertOutput(delegate() {
                CompilerTest(@"
begin
  raise
  print 'U'
rescue IOError
  print 'U'
rescue StandardError
  print 'X'
end
");
            }, "X");
        }

        private static void Scenario_RubyExceptions5() {
            AssertOutput(delegate() {
                CompilerTest(@"
begin
  raise
rescue StandardError => $x
  puts 'Caught'
  puts ""$! = '#{$!.class.name}'""
  puts ""$x = '#{$x.class.name}'""
end
");
            }, @"
Caught
$! = 'RuntimeError'
$x = 'RuntimeError'
");
        }

        private static void Scenario_RubyExceptions6() {
            AssertOutput(delegate() {
                CompilerTest(@"
x = StandardError
begin
  raise
rescue x => x
  puts 'Caught'
  puts ""$! = '#{$!.class.name}'""
  puts ""x = '#{x.class.name}'""
end
");
            }, @"
Caught
$! = 'RuntimeError'
x = 'RuntimeError'
");
        }

        private static void Scenario_RubyExceptions7() {
            AssertOutput(delegate() {
                CompilerTest(@"
def foo
  raise
end

begin
  foo
rescue Exception => e
  $found = false
  e.backtrace.each { |frame| if frame.index('foo') != nil then $found = true end } 
  puts $found
end");
            }, @"true");
        }

        private static void Scenario_RubyExceptions8() {
            AssertOutput(delegate() {
                CompilerTest(@"
puts 'Begin'
x = begin
  puts 'Raise'
  1
  raise
  puts 'Unreachable'
  2
rescue IOError
  puts 'Rescue1'
  3
rescue
  puts 'Rescue2'
  4
else
  puts 'Else'
  5
ensure
  puts 'Ensure'
  6 
end
puts x
puts 'End'
");
            }, @"
Begin
Raise
Rescue2
Ensure
4
End
");
        }

        private static void Scenario_RubyExceptions9() {
            AssertOutput(delegate() {
                CompilerTest(@"
puts 'Begin'
x = class C
  puts 'Raise'
  1
rescue IOError
  puts 'Rescue1'
  3
else
  puts 'Else'
  5
ensure
  puts 'Ensure'
  6 
end
puts x
puts 'End'
");
            }, @"
Begin
Raise
Else
Ensure
5
End
");
        }

        private static void Scenario_RubyExceptions10() {
            AssertOutput(delegate() {
                CompilerTest(@"
puts 'Begin'
begin
  puts 'Class'
  class C
    puts 'NoRaise'
  rescue
    puts 'Rescue'
  else
    puts 'Else'
  ensure
    puts 'Ensure'
  end
  puts 'ClassEnd'
rescue
  puts 'OuterRescue'
end
puts 'End'
");
            }, @"
Begin
Class
NoRaise
Else
Ensure
ClassEnd
End
");
        }

        private static void Scenario_RubyExceptions11() {
            AssertOutput(delegate() {
                CompilerTest(@"
puts 'Begin'
begin
  puts 'Class'
  class C
    puts 'NoRaise'
  rescue
    puts 'Rescue'
  else
    puts 'Else'
  ensure
    puts 'Ensure'
  end
  puts 'ClassEnd'
rescue
  puts 'OutterRescue'
end
puts 'End'
");
            }, @"
Begin
Class
NoRaise
Else
Ensure
ClassEnd
End
");
        }

        private static void Scenario_RubyExceptions12() {
            AssertOutput(delegate() {
                CompilerTest(@"
class A < Exception; end
class B < Exception; end
class C < Exception; end

begin
  raise B
rescue A,B,C => e
  puts e.class
end
");
            }, @"B");
        }

        /// <summary>
        /// Order of evaluation inside rescue clauses.
        /// </summary>
        private static void Scenario_RubyExceptions12A() {
            // TODO: needs alias
            XAssertOutput(delegate() {
                CompilerTest(@"
class Module
  alias old ===

  def ===(other)
    puts ""cmp(#{self}, #{other})""
    
    old other
  end
end

class A < Exception; end
class B < Exception; end
class C < Exception; end
class D < Exception; end
class E < Exception; end
class F < Exception; end
class G < Exception; end

def id(t)
  puts ""r(#{t})""
  t
end

def foo
  raise F
rescue id(A),id(B),id(C)
  puts 'rescued 1'  # unreachable
rescue id(E),id(F),id(G)
  puts 'rescued 2'
end

foo
");
            }, @"
r(A)
r(B)
r(C)
cmp(A, F)
cmp(B, F)
cmp(C, F)
r(E)
r(F)
r(G)
cmp(E, F)
cmp(F, F)
rescued 2
");
        }

        /// <summary>
        /// Retry try-catch block.
        /// </summary>
        private static void Scenario_RubyExceptions13() {
            AssertOutput(delegate() {
                CompilerTest(@"
i = 0
begin
  puts i
  i = i + 1
  if i < 3 then raise end
rescue
  puts 'retrying'
  retry
else
  puts 'no exception'
ensure
  puts 'giving up'
end
");
            }, @"
0
retrying
1
retrying
2
no exception
giving up
");
        }

        private static void Scenario_RubyExceptions14() {
            AssertOutput(delegate() {
                CompilerTest(@"
begin
  raise IOError
rescue IOError
  puts 'rescued'
end
");
            }, "rescued");
        }

        private static void Scenario_RubyExceptions15() {
            AssertOutput(delegate() {
                CompilerTest(@"
class C
  def exception
    IOError.new
  end
end

begin
  raise C.new
rescue IOError
  puts 'rescued'
end
");
            }, @"rescued");
        }

        private static void Scenario_RubyExceptions16() {
            AssertOutput(delegate() {
                CompilerTest(@"
begin
  raise Exception.new('foo')
rescue Exception => e
  puts e.message
end
");
            }, @"foo");
        }

        private static void Scenario_RubyThreads1() { 
            AssertOutput(delegate() {
                CompilerTest(@"
t = Thread.new 1,2,3 do |a,b,c| 
    puts a,b,c 
end
t.join
puts 4
");
            }, @"
1
2
3
4
");
        }

        #endregion

        #region Helper Code

        private static IScriptEnvironment _env;

        private static RubyEngine RB { get { return (RubyEngine)GetEngine("rb"); } }

        private static ScriptEngine GetEngine(string id) {
            return ScriptDomainManager.CurrentManager.GetLanguageProvider(id).GetEngine();
        }

#if !SILVERLIGHT
        private static int domainId = 0;

        private static AppDomain CreateDomain() {
            return AppDomain.CreateDomain("RemoteScripts" + domainId++);
        }
#endif

        [Flags]
        enum OutputFlags {
            None = 0,
            Raw = 1
        }

        private static void AssertEquals<T>(object actual, T expected)
            where T : IEquatable<T> {
            Assert(actual is T && ((T)actual).Equals(expected));
        }

        private static void XAssertOutput(Function f, string expectedOutput) {
            Console.WriteLine("Assertion check skipped.");
            // just run the code
            f();
        }

        private static void AssertOutput(Function f, string expectedOutput) {
            AssertOutput(f, expectedOutput, OutputFlags.None);
        }

        private static void AssertOutput(Function f, string expectedOutput, OutputFlags flags) {
#if !SILVERLIGHT
            StringBuilder builder = new StringBuilder();

            using (StringWriter output = new StringWriter(builder)) {
                RedirectOutput(output, TextWriter.Null, f);
            }

            string actualOutput = builder.ToString();

            if ((flags & OutputFlags.Raw) == 0) {
                actualOutput = actualOutput.Trim().Replace("\r", "");
                expectedOutput = expectedOutput.Trim().Replace("\r", "");
            }

            int i = 0;
            while (i < actualOutput.Length && i < expectedOutput.Length && actualOutput[i] == expectedOutput[i]) i++;

            if (actualOutput != expectedOutput) {
                Assert(false, String.Format("Unexpected output: \n\n'{0}'.\n\nFirst difference ({1}):\nactual = '{2}'\nexpected = '{3}'\n",
                Escape(builder), i,
                (i < actualOutput.Length ? Escape(actualOutput[i]) : "<end>"),
                (i < expectedOutput.Length ? Escape(expectedOutput[i]) : "<end>")
                ));
            }
#endif
        }

        private static string Escape(char ch) {
            return ch.ToString().Replace("\r", "\\r").Replace("\n", "\\n").Replace("\t", "\\t");
        }

        private static string Escape(string str) {
            return str.Replace("\r", "\\r").Replace("\n", "\\n").Replace("\t", "\\t");
        }

        private static string Escape(StringBuilder str) {
            return str.Replace("\r", "\\r").Replace("\n", "\\n").Replace("\t", "\\t").ToString();
        }

#if !SILVERLIGHT
        private static void RedirectOutput(TextWriter output, Function f) {
            RedirectOutput(output, output, f);
        }

        private static void RedirectOutput(TextWriter output, TextWriter errors, Function f) {
            TextWriter console_out = Console.Out;
            TextWriter console_err = Console.Error;

            ScriptEnvironment.GetEnvironment().RedirectIO(null, output, errors);
            try {
                f();
            } finally {
                ScriptEnvironment.GetEnvironment().RedirectIO(null, console_out, console_err);
            }
        }
#endif

        private static void AssertExceptionThrown<T>(Function f) where T : Exception {
            AssertExceptionThrown<T>(f, null);
        }

        private static void AssertExceptionThrown<T>(Function f, Predicate<T> condition) where T : Exception {
            try {
                RedirectOutput(TextWriter.Null, f);
            } catch (T e) {
                if (condition != null) {
                    Assert(condition(e), "Exception has been thrown but the condition doesn't hold");
                }
                return;
            } catch (Exception e) {
                Assert(false, "Expecting exception '" + typeof(T) + "', got '" + e.GetType() + "'.");
            }

            Assert(false, "Expecting exception '" + typeof(T) + "'.");
        }

        /// <summary>
        /// Asserts two values are equal
        /// </summary>
        private static void AreEqual(object x, object y) {
            if (x == null && y == null) return;

            Assert(x != null && x.Equals(y), String.Format("values aren't equal: {0} and {1}", x, y));
        }

        /// <summary>
        /// Asserts an condition it true
        /// </summary>
        private static void Assert(bool condition, string msg) {
            if (!condition) throw new Exception(String.Format("Assertion failed: {0}", msg));
        }

        private static void Assert(bool condition) {
            if (!condition) throw new Exception("Assertion failed");
        }

        #endregion
    }
}

