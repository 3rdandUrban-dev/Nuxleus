// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using Ruby;
using System.IO;
using System.CodeDom.Compiler;
using Ruby.Builtins;
using Microsoft.Scripting;
using Ruby.Hosting;
using Ruby.Runtime;
using System.Diagnostics;
using Microsoft.Scripting.Utils;

internal class Generator {

    private readonly string/*!*/ TypeAction0 = GenericTypeName(typeof(Function<>));
    private readonly string/*!*/ TypeAction1 = GenericTypeName(typeof(Action<>));
    private readonly string/*!*/ TypeActionN = GenericTypeName(typeof(Action<,>));
    private readonly string/*!*/ TypeFunction = GenericTypeName(typeof(Function<>));
    private readonly string/*!*/ TypeDelegate = TypeName(typeof(Delegate));
    private readonly string/*!*/ TypeRubyModule = TypeName(typeof(RubyModule));
    private readonly string/*!*/ TypeRubyClass = TypeName(typeof(RubyClass));
    private readonly string/*!*/ TypeActionOfRubyModule = TypeName(typeof(Action<RubyModule>));
    private readonly string/*!*/ TypeRubyMethodVisibility = TypeName(typeof(RubyMethodVisibility));
    private readonly string/*!*/ TypeRubyExecutionContext = TypeName(typeof(RubyExecutionContext));
    private readonly string/*!*/ TypeLibraryInitializer = TypeName(typeof(LibraryInitializer));
    private readonly string/*!*/ TypeMethodKind = TypeName(typeof(MethodKind));
    private readonly string/*!*/ TypeRubyLibraryAttribute = TypeName(typeof(RubyLibraryAttribute));
    
    private IndentedTextWriter _output;
    private IDictionary<Type, ModuleDef> _moduleDefs = new SortedDictionary<Type, ModuleDef>(new TypeComparer());
    private Dictionary<Type, string> _moduleRefs = new Dictionary<Type, string>();
    private Dictionary<Type, string> _classRefs = new Dictionary<Type, string>();
    private Assembly _assembly;

    public bool GeneratingBuiltins {
        get { return _assembly == typeof(Kernel).Assembly; }
    }
	

    #region Definitions

    private class ModuleDef {
        public Type/*!*/ Trait;
        public string/*!*/ Name;
        public Type/*!*/ Extends;
        public List<MethodInfo>/*!*/ Factories = new List<MethodInfo>();
        
        public List<Type>/*!*/ Mixins = new List<Type>();
        public List<ModuleDef>/*!*/ MixinDefs = new List<ModuleDef>();
        public List<string>/*!*/ MixinRefs = new List<string>();

        public bool IsClass;

        public Type Super; // non-null for classes except for object
        public ModuleDef SuperDef;
        public string SuperRef;

        public List<ModuleDef> SubDefs = new List<ModuleDef>();
        public string DefVariable;

        public string DeclaringTypeRef;

        public IDictionary<string, MethodDef>/*!*/ InstanceMethods = new SortedDictionary<string, MethodDef>();
        public IDictionary<string, MethodDef>/*!*/ ClassMethods = new SortedDictionary<string, MethodDef>();

        public bool Enqueued = false;

        public override string/*!*/ ToString() {
            return Name;
        }

        internal string GetReference(ref int defVariableId) {
            if (DefVariable == null) {
                // Object and Kernel are hardcoded:
                if (Extends == typeof(object)) {
                    DefVariable = "Context.ObjectClass";
                } else if (Extends == typeof(Kernel)) {
                    DefVariable = "Context.KernelModule";
                } else {
                    DefVariable = "def" + defVariableId++;
                }
            }

            return DefVariable;
        }
    }

    private class MethodDef {
        public string/*!*/ Name;
        public List<MethodInfo>/*!*/ Overloads = new List<MethodInfo>();
        public RubyMethodVisibility/*!*/ Visibility;
        public MethodKind Kind;

        public override string/*!*/ ToString() {
            return Name;
        }
    }

    #endregion

    public Generator(TextWriter/*!*/ output) {
        _output = new IndentedTextWriter(output);
    }
    
    public void Generate(Assembly/*!*/ assembly) {
        _assembly = assembly;

        ReflectTypes();

        GenerateCode(_namespace, _initializerTypeName, "public");
    }
    
    #region Reflection

    private void ReflectTypes() {
        foreach (Type trait in _assembly.GetTypes()) {
            foreach (RubyModuleAttribute module in trait.GetCustomAttributes(typeof(RubyModuleAttribute), false)) {
                ModuleDef def = new ModuleDef();

                RubyClassAttribute cls = module as RubyClassAttribute;
                RubyExtensionClassAttribute extension = module as RubyExtensionClassAttribute;

                def.Trait = trait;
                def.IsClass = cls != null;
                def.Name = module.Name ?? trait.Name;
                def.Extends = (extension != null) ? extension.Extends : trait;
                
                def.Super = null;
                if (cls != null && def.Extends != typeof(object)) {
                    def.Super = (cls != null && cls.Inherits != null) ? cls.Inherits : trait.BaseType;
                }

                foreach (IncludesAttribute includes in trait.GetCustomAttributes(typeof(IncludesAttribute), false)) {
                    def.Mixins.Add(includes.Type);
                }

                _moduleDefs.Add(def.Extends, def);

                ReflectMethods(def);
            }
        }

        int defVariableId = 1;

        foreach (ModuleDef def in _moduleDefs.Values) {
            // def is a nested class:
            ModuleDef declaringModuleDef;
            if (def.Trait.DeclaringType != null && _moduleDefs.TryGetValue(def.Trait.DeclaringType, out declaringModuleDef)) {
                def.DeclaringTypeRef = declaringModuleDef.GetReference(ref defVariableId);
                
                // ensure we have DefVariable set:
                def.GetReference(ref defVariableId);
            }
        }
                
        // wire-up supers and mixins:
        List<ModuleDef> errors = new List<ModuleDef>();
        foreach (ModuleDef def in _moduleDefs.Values) { 
            if (def.Super != null) {
                ModuleDef superDef;
                if (_moduleDefs.TryGetValue(def.Super, out superDef)) {
                    
                    // define inheritance relationship:
                    def.SuperDef = superDef;
                    def.SuperRef = superDef.GetReference(ref defVariableId);
                    superDef.SubDefs.Add(def);

                } else if (!GeneratingBuiltins) {

                    // define a class ref-variable for the type of the super class:
                    def.SuperRef = MakeClassReference(def.Super);

                } else {
                    Console.Error.WriteLine("Unknown super type for type '{0}'", def.Name);
                    Environment.ExitCode = 1;
                    errors.Add(def);
                }
            } else if (def.IsClass && def.Extends != typeof(object)) {
                Console.Error.WriteLine("Missing super type for type '{0}'", def.Name);
                Environment.ExitCode = 1;
                errors.Add(def);
            }

            // wire-up mixins:
            foreach (Type mixinType in def.Mixins) {
                ModuleDef mixinDef;
                if (_moduleDefs.TryGetValue(mixinType, out mixinDef)) {
                    
                    // define mixin relationship:
                    def.MixinDefs.Add(mixinDef);
                    def.MixinRefs.Add(mixinDef.GetReference(ref defVariableId));
                    mixinDef.SubDefs.Add(def);

                } else if (!GeneratingBuiltins) {

                    // define a module ref-variable for the type of the mixin:
                    def.MixinRefs.Add(MakeModuleReference(mixinType));

                } else {
                    Console.Error.WriteLine("Unknown mixin '{1}' for type '{0}'", def.Name, TypeName(mixinType));
                    Environment.ExitCode = 1;
                    errors.Add(def);
                }
            }
        }
        
        // remove erroneous defs:
        foreach (ModuleDef def in errors) {
            _moduleDefs.Remove(def.Trait);
        }
    }

    private string/*!*/ MakeModuleReference(Type/*!*/ typeRef) {
        string refVariable;

        if (!_moduleRefs.TryGetValue(typeRef, out refVariable)) {
            refVariable = "moduleRef" + _moduleRefs.Count;
            _moduleRefs.Add(typeRef, refVariable);
        }

        return refVariable;
    }

    private string/*!*/ MakeClassReference(Type/*!*/ typeRef) {
        string refVariable;

        if (!_classRefs.TryGetValue(typeRef, out refVariable)) {
            refVariable = "classRef" + _classRefs.Count;
            _classRefs.Add(typeRef, refVariable);
        }

        return refVariable;
    }

    private void ReflectMethods(ModuleDef/*!*/ moduleDef) {
        BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
        foreach (MethodInfo method in moduleDef.Trait.GetMethods(flags)) {
            object[] attrs = method.GetCustomAttributes(typeof(RubyMethodAttribute), false);
            if (attrs.Length > 0) {
                if (!RequirePublicStatic(method)) continue;
                foreach (RubyMethodAttribute attr in attrs) {
                    MethodDef def;

                    IDictionary<string, MethodDef> methods =
                        ((attr.MethodAttributes & RubyMethodAttributes.Instance) != 0) ? moduleDef.InstanceMethods : moduleDef.ClassMethods;

                    if (!methods.TryGetValue(attr.Name, out def)) {
                        def = new MethodDef();
                        def.Name = attr.Name;

                        // TODO:
                        switch (attr.MethodAttributes & RubyMethodAttributes.VisibilityMask) {
                            case RubyMethodAttributes.Private:
                                def.Visibility = RubyMethodVisibility.Private;
                                break;

                            case RubyMethodAttributes.Public:
                                def.Visibility = RubyMethodVisibility.Public;
                                break;

                            case RubyMethodAttributes.Protected:
                                def.Visibility = RubyMethodVisibility.Protected;
                                break;
                        }

                        switch (attr.MethodAttributes & RubyMethodAttributes.KindsMask) {
                            case RubyMethodAttributes.IsInstanceAllocator:
                                def.Kind = MethodKind.InstanceAllocator;
                                break;

                            case RubyMethodAttributes.IsInstanceConstructor:
                                def.Kind = MethodKind.InstanceConstructor;
                                break;
                        }

                        methods.Add(attr.Name, def);
                    }
                    def.Overloads.Add(method);
                }
            } else if (method.IsDefined(typeof(RubyConstructorAttribute), false)) {
                if (!RequirePublicStatic(method)) continue;
                moduleDef.Factories.Add(method);
            }
        }
    }

    private bool RequirePublicStatic(MethodBase/*!*/ method) {
        if (!method.IsStatic) {
            Console.Error.WriteLine("Instance methods not supported (method '{0}.{1}')", TypeName(method.DeclaringType), method.Name);
            Environment.ExitCode = 1;
            return false;
        }
        return true;
    }

    #endregion

    #region Code Generation

    private void GenerateCode(string/*!*/ @namespace, string/*!*/ typeName, string/*!*/ typeVisibility) {
        _output.WriteLine("[assembly: {2}(typeof({0}.{1}))]", @namespace, typeName, TypeRubyLibraryAttribute);
        _output.WriteLine("namespace {0} {{", @namespace); 
        _output.Indent++;

        _output.WriteLine("{0} sealed partial class {1} : {2} {{", typeVisibility, typeName, TypeLibraryInitializer);
        _output.Indent++;

        _output.WriteLine("protected override void LoadModules() {");
        _output.Indent++;
        
        GenerateModuleRegistrations();

        _output.Indent--;
        _output.WriteLine("}");
        _output.WriteLine();

        GenerateModuleInitializations();

        _output.Indent--;
        _output.WriteLine("}");

        _output.Indent--;
        _output.WriteLine("}");
    }

    private void GenerateModuleRegistrations() {

        // builtins:
        if (GeneratingBuiltins) {
            _output.WriteLine("Context.RegisterObjectAndKernel(new {0}(LoadObject), new {0}(LoadKernel));", TypeActionOfRubyModule);
        }

        // generate references:
        foreach (KeyValuePair<Type, string> moduleRef in _moduleRefs) {
            _output.WriteLine("{0} {1} = GetModule(typeof({2}));", TypeRubyModule, moduleRef.Value, moduleRef.Key);
        }

        foreach (KeyValuePair<Type, string> classRef in _classRefs) {
            _output.WriteLine("{0} {1} = GetClass(typeof({2}));", TypeRubyClass, classRef.Value, classRef.Key);
        }

        _output.WriteLine();

        // BFS, start with modules, enqueue root classes:
        Queue<ModuleDef> worklist = new Queue<ModuleDef>();
        foreach (ModuleDef def in _moduleDefs.Values) {
            if (def.MixinDefs.Count == 0 && def.SuperDef == null) {
                worklist.Enqueue(def);
                def.Enqueued = true;
            }
        }

        _output.WriteLine();

        // classes:
        while (worklist.Count > 0) {
            ModuleDef def = worklist.Dequeue();

            GenerateModuleRegistration(def);

            // enqueue subclasses and mixins:
            foreach (ModuleDef subdef in def.SubDefs) {
                if (!subdef.Enqueued) {
                    worklist.Enqueue(subdef);
                    subdef.Enqueued = true;
                }
            }
        }

        // add constants for nested classes:
        foreach (ModuleDef def in _moduleDefs.Values) {
            if (def.DeclaringTypeRef != null) {
                _output.WriteLine("{0}.SetConstant(\"{1}\", {2});", def.DeclaringTypeRef, def.Name, def.DefVariable);
            }
        }
    }

    private void GenerateModuleRegistration(ModuleDef/*!*/ def) {

        if (def.IsClass) {
            // Object is hardcoded
            if (def.Extends != typeof(object)) {
                Debug.Assert(def.SuperRef != null);

                if (def.DefVariable != null) {
                    _output.Write("{0} {1} = ", def.IsClass ? TypeRubyClass : TypeRubyModule, def.DefVariable);
                }

                if (def.Trait == typeof(RubyClass)) {
                    _output.Write("Context.ClassClass = ");
                } else if (def.Trait == typeof(NilClassOps)) {
                    _output.Write("Context.NilClass = ");
                } else if (def.Trait == typeof(TrueClass)) {
                    _output.Write("Context.TrueClass = ");
                } else if (def.Trait == typeof(FalseClass)) {
                    _output.Write("Context.FalseClass = ");
                } else if (def.Trait == typeof(ExceptionOps)) {
                    _output.Write("Context.ExceptionClass = ");
                } else if (def.Trait == typeof(RuntimeError)) {
                    _output.Write("Context.RuntimeErrorClass = ");
                } else if (def.Trait == typeof(SystemExceptionOps)) {
                    _output.Write("Context.StandardErrorClass = ");
                }

                _output.Write("RegisterClass(\"{0}\", typeof({1}), new {2}(Load{0}), {3}, ",
                    def.Name, TypeName(def.Extends), TypeActionOfRubyModule, def.SuperRef
                );

                GenerateInclusions(def);

                _output.Write(", ");

                if (def.Factories.Count > 0) {
                    GenerateDelegatesArrayCreation(def.Factories);
                } else {
                    _output.Write("null");
                }

                _output.WriteLine(");");
            } 
        } else {
            // Kernel is hardcoded:
            if (def.Extends != typeof(Kernel)) {

                if (def.DefVariable != null) {
                    _output.Write("{0} {1} = ", TypeRubyModule, def.DefVariable);
                }

                _output.Write("RegisterModule(\"{0}\", typeof({1}), new {2}(Load{0}), ",
                    def.Name, TypeName(def.Trait), TypeActionOfRubyModule
                );

                GenerateInclusions(def);

                _output.WriteLine(");");
            }
        }
    }

    private void GenerateInclusions(ModuleDef/*!*/ def) {
        if (def.MixinRefs.Count > 0) {
            _output.Write("new {0}[] {{", TypeRubyModule);
            foreach (string mixinRef in def.MixinRefs) {
                _output.Write("{0}, ", mixinRef);
            }
            _output.Write("}");
        } else {
            _output.Write("{0}.EmptyArray", TypeRubyModule);
        }
    }

    private void GenerateModuleInitializations() {
        foreach (ModuleDef moduleDef in _moduleDefs.Values) {
            GenerateModuleInitialization(moduleDef);
        }
    }

    private void GenerateModuleInitialization(ModuleDef/*!*/ moduleDef) {
        _output.WriteLine("private void Load{0}({1}/*!*/ module) {{", moduleDef.Name, TypeRubyModule);
        _output.Indent++;

        GenerateMethods(moduleDef.Trait, moduleDef.InstanceMethods, true);
        GenerateMethods(moduleDef.Trait, moduleDef.ClassMethods, false);

        _output.Indent--;
        _output.WriteLine("}");
        _output.WriteLine();
    }

    private void GenerateMethods(Type/*!*/ type, IDictionary<string, MethodDef>/*!*/ methods, bool isInstance) {
        foreach (MethodDef def in methods.Values) {
            _output.Write("module.Define{0}Method(\"{1}\", {2}.{3}",
                isInstance ? "Instance" : "Class", def.Name, TypeRubyMethodVisibility, def.Visibility);

            if (def.Kind != MethodKind.Regular) {
                _output.Write(", {0}.{1}", TypeMethodKind, def.Kind.ToString());
            }

            _output.Write(", ");

            GenerateDelegatesArrayCreation(def.Overloads);

            _output.WriteLine(");");
            _output.WriteLine();
        }
    }

    private void GenerateDelegatesArrayCreation(IEnumerable<MethodInfo>/*!*/ methods) {
        _output.WriteLine("new {0}[] {{", TypeDelegate);
        _output.Indent++;

        foreach (MethodInfo method in methods) {
            GenerateDelegateCreation(method);
            _output.WriteLine(",");
        }

        _output.Indent--;
        _output.Write("}");
    }

    private void GenerateDelegateCreation(MethodInfo/*!*/ method) {
        ParameterInfo[] ps = method.GetParameters();
        Type[] paramTypes = Array.ConvertAll<ParameterInfo, Type>(ps, delegate(ParameterInfo p) { return p.ParameterType; });

        string delegateType;
        if (method.ReturnType != typeof(void)) {
            delegateType = TypeFunction;
            paramTypes = ArrayUtils.Append(paramTypes, method.ReturnType);
        } else if (paramTypes.Length == 0) {
            delegateType = TypeAction0;
        } else if (paramTypes.Length == 1) {
            delegateType = TypeAction1;
        } else {
            delegateType = TypeActionN;
        }

        _output.Write("new {0}{1}({2}.{3})",
            delegateType,
            ReflectionUtils.FormatTypeArgs(new StringBuilder(), paramTypes),
            TypeName(method.DeclaringType),
            method.Name
        );
    }
    
    #endregion

    #region Helpers

    private static string/*!*/ TypeName(Type/*!*/ type) {
        return ReflectionUtils.FormatTypeName(new StringBuilder(), type).ToString();
    }

    private static string/*!*/ GenericTypeName(Type/*!*/ type) {
        if (type.IsGenericTypeDefinition) {
            return String.Concat(type.Namespace, ".", type.Name.Substring(0, type.Name.IndexOf('`')));
        } else {
            return type.Name;
        }
    }

    private class TypeComparer : IComparer<Type> {
        public int Compare(Type x, Type y) {
            return x.FullName.CompareTo(y.FullName);
        }
    }

    #endregion

    static string _namespace;
    static string _initializerTypeName;

    static void Main(string[]/*!*/ args) {

        try {
            Assembly assembly;
            if (args.Length >= 1) {
                assembly = Assembly.LoadFrom(args[0]);
                _namespace = args[1];
                _initializerTypeName = args[2];
            } else {
                assembly = typeof(RubyEngine).Assembly;
                _namespace = "Ruby.Builtins";
                _initializerTypeName = "BuiltinsInitializer";
            }

            new Generator(Console.Out).Generate(assembly);
        } catch (Exception e) {
            Console.Error.WriteLine(e.Message);
            Environment.ExitCode = 1;
        }
    }
}
