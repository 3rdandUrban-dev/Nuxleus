import clr
clr.AddReference("Microsoft.Scripting")

from System.IO import File, Directory, Path
from System import Console, String

def all_files(root):
    for x in Directory.GetFiles(root):
        yield Path.Combine(root, x)
        
    dirs = Directory.GetDirectories(root)
    for d in dirs:
        for x in all_files(d):
            yield x

from Microsoft.Scripting.Hosting import ErrorSink
class LoggingErrorSink(ErrorSink):
    def __init__(self):
        self.error = ""
        
    def Add(self, sourceUnit, message, span, errorCode, severity):
        super(LoggingErrorSink, self).Add(sourceUnit, message, span, errorCode, severity)
        self.error += String.Format("{0}({1}:{2}): {3}: RB{4}: {5}", sourceUnit.Id, span.Start.Line, span.Start.Column, severity, errorCode, message)

import clr,sys
clr.AddReference("ruby")
from Ruby.Compiler import RubyCompilerOptions, Parser

from Microsoft.Scripting import CompilerContext, ScriptDomainManager
from Microsoft.Scripting.Hosting import SourceUnit
rb = ScriptDomainManager.CurrentManager.GetLanguageProvider("rb").GetEngine()

import re
def extract_expected(content):
    lines = content.split("\n")
    pattern = re.compile(r"^#(.+):(.+)")
    rules = {}
    for l in lines:
        mo = pattern.match(l)
        if mo:
            rules[mo.group(1).strip().lower()] = mo.group(2).strip()
    if rules.has_key("parseonly"):
        return rules["parseonly"]
    return rules["default"]

failures = 0
skips = 0

for f in all_files(sys.argv[1]):
    log = LoggingErrorSink()
    content = File.ReadAllText(f)
    
    if "merlin_bug" in content:
        sys.stdout.write("\ns( %s )" % f)
        skips += 1
        continue 
    
    unit = SourceUnit.CreateSnippet(rb, content)
    cc = CompilerContext(unit, RubyCompilerOptions(), log)
    parser = Parser()
    try:
        parser.Parse(cc)
    except:
        failures += 1
        sys.stdout.write("\nC( %s )" % f)
    else:
        actual = log.error
        expected = extract_expected(content)
        
        if expected == "pass":
            if actual == "":
                sys.stdout.write("+")
            else:
                failures += 1
                sys.stdout.write("\nX( %s )" % f)
                sys.stdout.write("\n>> %s | %s" % (expected, actual ))
        else:
            if expected in actual: 
                sys.stdout.write("-")
            else: 
                failures += 1
                sys.stdout.write("\n/( %s )" % f)
                sys.stdout.write("\n>> %s | %s" % (expected, actual ))

print "\n\nfailures: %s, skips: %s \n" % (failures, skips)
sys.exit(failures)


