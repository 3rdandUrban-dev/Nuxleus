
class myclass
end 
# Scenario: all lowercased
# Default: class/module name must be CONSTANT
# ParseOnly: Class/module name must be a constant
