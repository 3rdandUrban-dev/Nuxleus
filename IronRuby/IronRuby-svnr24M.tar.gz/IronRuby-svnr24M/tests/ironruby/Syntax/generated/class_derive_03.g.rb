
class C()
end 
# Scenario: use () again
# Default: syntax error
