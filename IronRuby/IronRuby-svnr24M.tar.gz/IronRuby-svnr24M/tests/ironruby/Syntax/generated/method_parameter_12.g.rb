
def method a, b, a
	1
end	
# Scenario: same name again
# Default: duplicate argument name
# ParseOnly: merlin_bug#248256
