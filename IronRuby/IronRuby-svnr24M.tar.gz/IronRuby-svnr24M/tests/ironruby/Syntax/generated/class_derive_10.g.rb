
class C < 
	> Object
end 
# Scenario: unknown
# Default: syntax error
