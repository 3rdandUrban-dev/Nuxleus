
def _method
  1
end 
_method

def me_thod
  1
end
me_thod
# Scenario: method name begins with _, or _ in
# Default: pass
