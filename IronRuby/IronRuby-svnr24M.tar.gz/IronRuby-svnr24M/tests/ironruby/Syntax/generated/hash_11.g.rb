
{"a"=> 10, 'b'}
# Scenario: odd number
# Default: syntax error
