class << "string"
end 

class 
	<< "string"
end 

class
	<<
	"string"
end 

x = "string"
class << x
end 

class <<
	x
end 
# Scenario: normal
# Default: pass
