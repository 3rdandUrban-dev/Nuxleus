
def method(a==3)
end 
# Scenario: with parentheis, with ==
# Default: syntax error
