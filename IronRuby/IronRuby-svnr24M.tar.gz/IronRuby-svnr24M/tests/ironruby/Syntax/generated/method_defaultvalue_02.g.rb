
def method a=
	puts "hello"
end 
method
# Scenario: without parenthesis, without default value
# Default: syntax error
