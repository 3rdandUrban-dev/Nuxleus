
def method a = 3
end 
method
method(10)
# Scenario: without parenthesis (but space)
# Default: pass
