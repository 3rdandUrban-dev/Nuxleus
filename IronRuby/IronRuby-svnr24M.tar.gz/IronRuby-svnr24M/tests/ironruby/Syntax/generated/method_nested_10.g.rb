
def method
	a = 1
	def 
		nested
	end
	nested
end 
method
# Scenario: unknown
# Default: pass
