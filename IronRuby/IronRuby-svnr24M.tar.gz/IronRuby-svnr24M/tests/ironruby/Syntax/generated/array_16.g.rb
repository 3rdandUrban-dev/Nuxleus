
a = %W

# Scenario: unknown
# Default: unterminated
# ParseOnly: merlin_bug#248301
