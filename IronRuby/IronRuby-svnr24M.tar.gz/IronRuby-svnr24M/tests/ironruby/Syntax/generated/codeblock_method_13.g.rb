
def method a, &b
	1
end
method(1), {2}  # odd number list for Hash
# Scenario: No comma between arg and block
# Default: syntax error
