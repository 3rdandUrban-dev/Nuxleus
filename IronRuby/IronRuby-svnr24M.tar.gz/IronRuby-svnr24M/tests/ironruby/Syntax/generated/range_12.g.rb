
10..20.30
# Scenario: valid
# Default: pass
