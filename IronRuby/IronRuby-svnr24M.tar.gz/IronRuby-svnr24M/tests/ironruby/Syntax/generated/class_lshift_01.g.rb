
class < < "string"
end 
# Scenario: space between < <
# Default: syntax error
