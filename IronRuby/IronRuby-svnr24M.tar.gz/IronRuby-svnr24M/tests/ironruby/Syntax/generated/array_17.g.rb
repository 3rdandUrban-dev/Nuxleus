
a = %w  (a) 
# Scenario: space (unterminated string meets end of file)
# Default: unterminated
# ParseOnly: merlin_bug#248301
