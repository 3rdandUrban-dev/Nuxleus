
class << "string"
end 
# Scenario: singleton
# Default: pass
