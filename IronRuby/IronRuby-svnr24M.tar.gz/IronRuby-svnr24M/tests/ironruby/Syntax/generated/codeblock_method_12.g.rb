
def method a, &b
	1
end 
method 1 {2} 
# Scenario: without parenthesis
# Default: syntax error
