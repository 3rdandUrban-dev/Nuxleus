
def method(a,)
end 
# Scenario: extra comma, with parenthesis
# Default: syntax error
