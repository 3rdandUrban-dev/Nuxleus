
def meth<od
end 
# Scenario: method name has "<"
# Default: syntax error
