
a = [()]
a = [{}]
a = [1, ] #  trialing comma
# Scenario: empty array 
# Default: pass
