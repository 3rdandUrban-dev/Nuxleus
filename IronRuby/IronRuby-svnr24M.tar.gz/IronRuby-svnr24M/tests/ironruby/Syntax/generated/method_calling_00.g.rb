
def method(a, b)
end 
method((1,2))
# Scenario: double parenthesis around args
# Default: syntax error
