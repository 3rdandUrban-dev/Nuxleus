def method a=
end 
# Scenario: without parenthesis, without default value
# Default: syntax error
