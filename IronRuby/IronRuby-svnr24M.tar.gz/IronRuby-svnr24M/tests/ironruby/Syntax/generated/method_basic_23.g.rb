
def method?
  1
end
method?
# Scenario: method name ends with "?"
# Default: pass
