
class C < C
end 
# Scenario: superclass mismatch for class C
# Default: NameError
# ParseOnly: pass
