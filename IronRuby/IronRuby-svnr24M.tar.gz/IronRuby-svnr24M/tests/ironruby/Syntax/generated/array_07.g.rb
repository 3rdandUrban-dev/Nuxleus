
a = [1, []]
a = [2, "4", ]
a = ["]", 3, ]
a = [4, "[]]", ]
## two element

# Scenario: unknown
# Default: pass
