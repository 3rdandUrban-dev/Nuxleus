
h = { , }
# Scenario: trialling comma
# Default: syntax error
