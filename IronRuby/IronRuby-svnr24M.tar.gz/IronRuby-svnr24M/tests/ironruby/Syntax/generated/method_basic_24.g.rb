
def <
  1
end 
# Scenario: method name "<"
# Default: pass
