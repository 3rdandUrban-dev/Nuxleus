
10. .20
# Scenario: space inside
# Default: syntax error
