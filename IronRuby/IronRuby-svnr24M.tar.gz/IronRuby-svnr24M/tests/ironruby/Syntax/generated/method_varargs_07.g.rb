
def method(*a, b=2)
end 
# Scenario: two parameters, vararg first, then default value
# Default: syntax error
