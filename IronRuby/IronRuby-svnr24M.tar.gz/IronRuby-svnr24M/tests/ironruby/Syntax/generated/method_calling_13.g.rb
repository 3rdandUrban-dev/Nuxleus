
def method(a, b)
	return a, b
end
method('language' => 'ruby', 34)
# Scenario: two args: hash arg must be the last
# Default: syntax error
