
def method a, b
	a + b
end
method(1,2)

def method a 
	a * 2
end 
method(2)
# Scenario: normal without parentheses
# Default: pass
