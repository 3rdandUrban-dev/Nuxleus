
h = { "str", 100 }
h = { "str", 100, }
h = { "str" => 100 }
h = { "str" => 200, }
# Scenario: one pair
# Default: pass
