
def method() end
method
# Scenario: "end" in the "def" line, parameters specified by parenthesis, no body
# Default: pass
