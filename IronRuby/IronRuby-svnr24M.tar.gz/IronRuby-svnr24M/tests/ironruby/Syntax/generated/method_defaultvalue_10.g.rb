
def method(a=3)
  a
end 
method
method(10)
# Scenario: with parenthesis
# Default: pass
