
def method(c=d, d=4)
	c+d
end 
method(3)
method(6, 7)
# Scenario: ok to define: parameter order
# Default: pass
