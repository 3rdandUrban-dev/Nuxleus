
def method(*a)
	a
end 
method
method(1)
method(2, 3)
method([])
method(*[])
method([4,5])
method(*[6,7])
method([8], 9)
# method(*[10, 11], 12) ??
# Scenario: only one parameter, which is vararg
# Default: pass
