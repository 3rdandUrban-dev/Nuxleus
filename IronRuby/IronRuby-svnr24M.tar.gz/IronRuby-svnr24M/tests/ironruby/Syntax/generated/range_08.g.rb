
10 ... 
-30
# Scenario: newline
# Default: pass
