
def method(a)
	return a
end 

method { 'language' => 'ruby',	'framework' => '.net' }	
# Scenario: one arg: without parenthesis, use hash, same line
# Default: syntax error
