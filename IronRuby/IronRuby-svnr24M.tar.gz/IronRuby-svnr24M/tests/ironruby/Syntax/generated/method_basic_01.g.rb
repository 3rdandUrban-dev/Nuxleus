
def 
  method end
# Scenario: "def " in different line as method name
# Default: syntax error
