
$a = 10
def 
  method 
    $a
  end 
method
# Scenario: "a" as method body here
# Default: pass
