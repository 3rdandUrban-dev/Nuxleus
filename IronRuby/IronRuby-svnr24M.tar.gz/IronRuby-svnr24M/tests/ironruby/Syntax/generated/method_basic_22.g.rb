
def me?thod
end
me?thod
# Scenario: method name with "?" inside, and call it
# Default: NameError
# ParseOnly: pass
