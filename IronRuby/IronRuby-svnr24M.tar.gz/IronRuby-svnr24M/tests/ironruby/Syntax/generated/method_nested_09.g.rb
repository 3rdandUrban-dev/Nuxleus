

def method 
	def 
	nested 
end 
end
end 
method 
# Scenario: extra end
# Default: syntax error
