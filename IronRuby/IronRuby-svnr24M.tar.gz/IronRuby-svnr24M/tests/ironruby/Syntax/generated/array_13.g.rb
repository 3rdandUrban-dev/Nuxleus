
a 
= [7]
# Scenario: 
# Default: syntax error
