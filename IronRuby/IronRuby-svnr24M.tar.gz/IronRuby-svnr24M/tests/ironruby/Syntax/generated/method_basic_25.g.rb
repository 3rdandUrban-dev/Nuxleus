
def <
end
<
# Scenario: method name "<", and call it
# Default: syntax error
