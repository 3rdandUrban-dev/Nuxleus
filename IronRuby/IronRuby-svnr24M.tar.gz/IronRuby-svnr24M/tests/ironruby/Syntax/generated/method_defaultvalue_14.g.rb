
def method a=3, b
end 
# Scenario: without parenthesis, default value before
# Default: syntax error
