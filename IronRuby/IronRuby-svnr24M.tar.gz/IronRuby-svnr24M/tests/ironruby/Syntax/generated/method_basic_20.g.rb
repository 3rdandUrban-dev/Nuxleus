
me = "hello"
def me.thod
  1
end 
me.thod
# Scenario: method name with . inside (works)
# Default: pass
