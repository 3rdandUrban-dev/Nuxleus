
def method(a, b=-4)
	a + b
end 
method(b = 2)  # returns 2+(-4) = -2
# Scenario: the second one has default value (negative 2 ??)
# Default: pass
