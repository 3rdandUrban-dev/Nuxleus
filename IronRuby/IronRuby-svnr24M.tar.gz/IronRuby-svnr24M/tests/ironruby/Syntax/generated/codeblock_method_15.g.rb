
def method c
end 

method(1)
method(1) do 
    1
end 
method(1) { 1 } 
method 1 do
    2
end
# Scenario: paraenthesis or do-end, related to arguments
# Default: pass
