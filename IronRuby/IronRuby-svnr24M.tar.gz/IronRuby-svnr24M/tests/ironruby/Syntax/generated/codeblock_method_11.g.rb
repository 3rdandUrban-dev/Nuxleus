
def method a, &b
	1
end 
method 1
method(2)
method(3) {4}  # parenthesis is needed for normal args
# Scenario: two args
# Default: pass
