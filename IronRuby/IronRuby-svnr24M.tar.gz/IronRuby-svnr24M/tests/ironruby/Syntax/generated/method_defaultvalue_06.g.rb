
def method a=
	3
	1
end 
method
method(10)
# Scenario: without parenthesis, default value in different line
# Default: pass
