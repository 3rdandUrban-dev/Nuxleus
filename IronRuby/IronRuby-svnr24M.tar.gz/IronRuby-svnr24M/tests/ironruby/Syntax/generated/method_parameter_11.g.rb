
#* samename

def method a, a
	1
end 
# Scenario: same name
# Default: duplicate argument name
# ParseOnly: merlin_bug#248256
