
{'a', 10}
# Scenario: seperator ","
# Default: pass
