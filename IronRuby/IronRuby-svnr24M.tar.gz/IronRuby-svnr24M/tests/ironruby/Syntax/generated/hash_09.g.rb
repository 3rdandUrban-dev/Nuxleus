
h = { 200,
	"str" } 
h = { 100 => 
	"str"}
# Scenario: new line
# Default: pass
