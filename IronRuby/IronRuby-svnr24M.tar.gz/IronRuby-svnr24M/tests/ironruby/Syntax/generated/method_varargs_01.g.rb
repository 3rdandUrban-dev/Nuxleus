
def method(*
	a)
end 
method
# Scenario: parameter name in different line with * (w/ parenthesis)
# Default: pass
