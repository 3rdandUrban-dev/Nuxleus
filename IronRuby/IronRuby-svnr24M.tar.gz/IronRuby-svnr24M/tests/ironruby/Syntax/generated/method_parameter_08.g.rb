
def method(a, b)
	a + b
end 
method (1, 2) # warning
# Scenario: warning expected
# Default: don't put space before argument parentheses
