
def method!_
	"!_"
end 
method!_
# Scenario: undefined local variable or method `_' for main:Object, _
# Default: NameError
# ParseOnly: pass
