
a = % W(ghij)

# Scenario: space
# Default: syntax error
# ParseOnly: merlin_bug#248301
