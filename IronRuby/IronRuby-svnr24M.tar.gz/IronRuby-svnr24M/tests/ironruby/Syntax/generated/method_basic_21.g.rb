
def me?thod
end
me? 1
# Scenario: method name with "?" inside
# Default: pass
