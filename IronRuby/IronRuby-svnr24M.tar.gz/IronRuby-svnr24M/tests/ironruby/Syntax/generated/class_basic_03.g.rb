
class C
end 

class # name in different line 
	C
end 

class D
	
	end 

class E;	#semi-comma
end 
# Scenario: unknown
# Default: pass
