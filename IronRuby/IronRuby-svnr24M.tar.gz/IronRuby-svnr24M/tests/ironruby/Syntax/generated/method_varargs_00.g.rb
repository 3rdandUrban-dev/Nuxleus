#* syntax

def method *
	a
end 	
method
# Scenario: parameter name in different line with * (w/o parenthesis)
# Default: pass
