#* syntax

#normal
def method a
end
method 1

def method a, b
end 
method 1, 2

def method a,
  b
end
method 1, 2

def method (a, 
  b)
  a+b
end
method 1, 2

def method (
  a, 
  b)
  a+ b
end 
method(1, 2)
# Scenario: parameter position:
# Default: pass
