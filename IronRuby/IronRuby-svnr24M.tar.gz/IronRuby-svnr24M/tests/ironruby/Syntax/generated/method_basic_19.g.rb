
def me.thod
end
# Scenario: method name with . inside: undefined local variable or method `me' for main:Object (NameError)
# Default: NameError
# ParseOnly: pass
