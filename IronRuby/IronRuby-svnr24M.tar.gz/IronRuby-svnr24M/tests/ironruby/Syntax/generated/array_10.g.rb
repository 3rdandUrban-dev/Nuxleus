
a = [

]
a = [1
]
a = [
2]
a = [
3
]
a = [
4,
5
]
a = 
[6]
# Scenario: unknown
# Default: pass
