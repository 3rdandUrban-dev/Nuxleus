
def method &block
	1
end 
method
method { 3 }
# Scenario: ok to have no block passed in : block is optional
# Default: pass
