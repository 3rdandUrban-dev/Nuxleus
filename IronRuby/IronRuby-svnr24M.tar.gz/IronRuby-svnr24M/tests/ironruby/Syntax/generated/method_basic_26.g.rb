
# Scenario: method name "<<"
# Default: pass
