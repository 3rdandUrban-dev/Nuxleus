
def method(a, b, c, d, e)
end 
method(1, *[2, 3], *[4, 5])
# Scenario: two expanding
# Default: syntax error
