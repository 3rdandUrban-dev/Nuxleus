
def method (a=3, b)
end 
# Scenario: with parenthesis, default value before
# Default: syntax error
