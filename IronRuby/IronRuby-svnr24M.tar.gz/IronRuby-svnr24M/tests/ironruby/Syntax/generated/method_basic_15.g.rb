
def me1thod
end
me1thod
# Scenario: method name embeded with digit
# Default: pass
