
class C end
# Scenario: same line
# Default: syntax error
