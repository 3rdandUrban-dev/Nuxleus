
class < "string"
end 
# Scenario: "<"
# Default: syntax error
