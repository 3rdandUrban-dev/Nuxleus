
h = { 
	100 
	=> 
	"str" 
	}
# Scenario: newline
# Default: syntax error
