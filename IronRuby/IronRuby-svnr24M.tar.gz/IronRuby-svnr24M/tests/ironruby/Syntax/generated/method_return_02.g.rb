
def m
  1, 2
end 

# Scenario: return a python-like tuple
# Default: syntax error
