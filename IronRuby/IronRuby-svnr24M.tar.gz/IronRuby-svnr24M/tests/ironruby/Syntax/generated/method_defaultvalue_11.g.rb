
def method(a
	=3)
  a
end 
# Scenario: with parenthesis, = in different line
# Default: syntax error
