module TestPath
    def TestPath.get_environment_variable(x)
        ENV[x.upcase] or ENV[x.downcase]
    end 
    
    def TestPath.get_directory_name(dir)
        File.basename dir
    end 
    
    def TestPath.get_directory(dir)
        File.dirname dir
    end 
    
    def TestPath.probe_cruby_exe()
            [ 
            MERLIN_ROOT + "/../External/Languages/Ruby/ruby-1.8.6/bin/ruby.exe",
            "D:/ruby/bin/ruby.exe", 
            "C:/ruby/bin/ruby.exe",
        ].each do |f|
            return f if File.exist? f
        end
    end
    
    MERLIN_ROOT     = get_environment_variable('MERLIN_ROOT')
    TEST_DIR        = MERLIN_ROOT + "/Languages/Ruby/Tests"
    CORECLR_ROOT    = MERLIN_ROOT + "/Utilities/Silverlight/x86ret"
    ROWAN_BIN       = get_environment_variable('ROWAN_BIN')
    
    if ROWAN_BIN
        # assume we are running inside snap
        IRUBY_EXE       = ROWAN_BIN + "/rbx.exe"
        IPYTHON_EXE     = ROWAN_BIN + "/ipy.exe"
        CRUBY_EXE       = MERLIN_ROOT + "/../External/Languages/Ruby/ruby-1.8.6/bin/ruby.exe"
    else
        IRUBY_EXE       = MERLIN_ROOT + "/bin/debug/rbx.exe"
        IPYTHON_EXE     = MERLIN_ROOT + "/bin/debug/ipy.exe"
        CRUBY_EXE       = probe_cruby_exe()
    end
    
    TEST_TOOL_DIR   = MERLIN_ROOT + "/languages/ruby/Tests/Tools"
    PARSEONLY_EXE   = IPYTHON_EXE + " " + TEST_TOOL_DIR + "/parseonly.py " 
    
    # generate logs to TestResults directory, so they will be copied to the snap server
    RESULT_DIR      = TEST_DIR
    if get_environment_variable("INSTALLROOT") != nil
        RESULT_DIR  = File.join(get_environment_variable("INSTALLROOT"), "TestResults")
    end 
end 

module Test
    class Logger
        attr_reader :log_name
        
        def initialize(prefix)
            current = Time.now.strftime("%m%d%H%M")
            @log_name = File.join(TestPath::RESULT_DIR, "#{prefix}_#{current}.log")
        end 
        
        def append(line)
            open(@log_name, "a+") { |f| f << line << "\n" }
        end 
        
        def to_s
            @log_name
        end 
    end 
    
    
    class BaseDriver
        attr_reader :name, :logger, :redirect_error, :append_to_log
        
        def initialize(name, redirect_error=true, append_to_log=true)
            @name = name.downcase
            @logger = Logger.new(name)
            
            @redirect_error = redirect_error
            @append_to_log = append_to_log
            @cmd_line = nil 
        end 
        
        def change_dir_to_file(f)
            saved = Dir.pwd
            d = File.dirname(File.expand_path(f))
            Dir.chdir(d)
            saved
        end 
        
        def run(f, log_file)
            begin 
                saved = change_dir_to_file(f)
                cmd_line = get_command_line(f) + " #{@append_to_log ? ">>" : ">"} #{log_file} #{@redirect_error ? "2>&1" : ""}"
                @logger.append("cd /d #{saved}")
                @logger.append(cmd_line)
                system(cmd_line)
                return $?.exitstatus
            ensure 
                Dir.chdir(saved)
            end
        end 
    end 
    
    class CRubyDriver < BaseDriver
        def initialize(redirect_error=true, append_to_log=true)
            super("cruby", redirect_error, append_to_log)
        end 
        
        def get_command_line(f)
            "#{TestPath::CRUBY_EXE} #{File.basename(f)}"
        end 
    end 
    
    class IronRubyDriver < BaseDriver
        attr_reader :mode
        
        @@mode_mapping = {
            1 => "-D -X:SaveAssemblies -X:StaticMethods",
            3 => "-D -X:Interpret",
            2 => "-D",
        }
        def initialize(mode, name, redirect_error=true, append_to_log=true)
            @mode_string = @@mode_mapping[mode]
            super(name, redirect_error, append_to_log)
        end 

        def get_command_line(f)
            "#{TestPath::IRUBY_EXE} #{@mode_string} #{File.basename(f)}"
        end 

        def to_s
            "IronRubyDriver ( rbx.exe #{@mode_string} )"
        end 
    end 
    
    class CoreClrDriver < BaseDriver
        def initialize(redirect_error=true, append_to_log=true)
            super("coreclr", redirect_error, append_to_log)
        end 
        
        def run(f, logfile)
            begin 
                f = File.expand_path(f)
                saved = Dir.pwd
                Dir.chdir(TestPath::CORECLR_ROOT)
                cmd_line = "fxprun.exe thost.exe -fxprun_byname /nologo /lang:rb /run:#{f} /paths:#{File.dirname(f)} #{@append_to_log ? ">>" : ">"} #{logfile} #{@redirect_error ? "2>&1" : ""}"
                @logger.append("cd /d #{TestPath::CORECLR_ROOT}")
                @logger.append(cmd_line)
                system(cmd_line)
                return $?.exitstatus
            ensure
                Dir.chdir(saved)
            end 
        end
    end
    
    # const
    CRuby = CRubyDriver.new
    Iron_m1 = IronRubyDriver.new(1, 'ironm1')
    Iron_m2 = IronRubyDriver.new(2, 'ironm2')
    Iron_m3 = IronRubyDriver.new(3, 'ironm3')
    Iron_cc = CoreClrDriver.new
end 
