from compat_common import *

# exception_stmt = 
#   "begin"
#       statement 
#   rescue_block
#   else_block
#   ensure_block
#   "end"

# rescue_block = 
#       <empty> 
#   |   "rescue" 
#           statement 
#   |   "rescue (1+'1')" 
#           statement

# else_block = 
#       <empty> 
#   |   "else" 
#           statement

# ensure = <empty> 
#   |   "ensure" 
#           statement

# statement = 
#       <empty>  
#   |   "print B" 
#   |   raise "B" 
#   |   1/0 
#   |   "retry" 
#   |   "next" 
#   |   "return" 
#   |   puts $!.class 
#   |   exception_stmt 

max_depth = 4

def exception_stmt_generator(depth):
    if depth > max_depth: 
        return 

    for rescue_b in rescue_block_generator(depth):
        for else_b in else_block_generator(depth):
            # warning: else without rescue is useless
            if rescue_b.lstrip().startswith("#empty") and not else_b.lstrip().startswith("#empty"): 
                continue

            for ensure_b in ensure_block_generator(depth):
                for body_b in statement_generator(depth+1):
                    s = space(depth) + "print B, $!.class\n"
                    s += space(depth) + "begin\n"
                    s += body_b 
                    s += rescue_b 
                    s += else_b
                    s += ensure_b
                    s += space(depth) + "end\n"
                    s += space(depth) + "print B, $!.class\n"
                    yield s

def rescue_block_generator(depth):
    if depth > max_depth: return
        
    yield space(depth) + "#empty_rescue\n"
    
    for stmt_b in statement_generator(depth+1):
        s = space(depth) + "rescue\n"
        s += stmt_b
        yield s

    for stmt_b in statement_generator(depth+1):
        s = space(depth) + "rescue (1+\"1\")\n"
        s += stmt_b
        yield s

def else_block_generator(depth):
    if depth > max_depth: return
        
    yield space(depth) + "#empty_else\n"
    for stmt_b in statement_generator(depth+1):
        s = space(depth) + "else\n" 
        s += stmt_b
        yield s

def ensure_block_generator(depth):
    if depth > max_depth: return
    
    yield space(depth) + "#empty_ensure\n"
    for stmt_b in statement_generator(depth+1):
        s = space(depth) + "ensure\n" 
        s += stmt_b
        yield s

def statement_generator(depth):
    if depth > max_depth: return
    
    for x in [
            "#empty_stmt",
            #"raise \"B\"",
            #"1/0",
            #"print B, $!.class",
            #"return B",
            #"if true; print B; raise \"B\"; end",
            #"if false; print B; raise \"B\"; end",
            #"while true; print B; raise \"B\";end",
            #"$g += 1; if $g < 20; print B; retry; end;"
             ]:
        yield space(depth) + x + "\n"
    
    for x in exception_stmt_generator(depth+1):
        yield x


fc = FileCreator("test_exception", 1000)
count = 0

for x in exception_stmt_generator(1):
    line1 = "def f_%s\n" % count + replace_B(x) + "end\n"
    line2 = "$g = 0; begin; print(f_%s); rescue; print $!.class; end; puts \" : f_%s\"\n" % (count, count)
    count += 1
    
    fc.save_block(line1, line2)

fc.close()
fc.print_file_list()    
    
