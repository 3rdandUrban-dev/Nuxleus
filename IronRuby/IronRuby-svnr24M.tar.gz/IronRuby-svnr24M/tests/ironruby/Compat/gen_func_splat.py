from compat_common import *

callee = """
A
*A
A,A
A,*A
A,A,A
A,A,*A
""".split()

caller = """
nil
*nil
*[nil]
nil,nil
nil,nil,nil
nil,*[nil]
B,nil
[]
B
B,B
B,B,B
B,[]
B,[B]
B,[B,B]
[[]]
[B]
[B,B]
[B,B,B]
[B,B,*[B]]
*[]
*B
B,*B
B,B,*B
B,*[]
B,*[B]
B,*[B,B]
*[[]]
*[B]
*[B,B]
*[B,B,B]
*[B,[B,B]]
*[B,*[B,B]]
nil,*B
""".split()

print '''
def p *a
  a.each { |x| print x.inspect, '; ' }
  puts
end
'''

count = 0
for x in callee:
    parameters, vars_num = replace_A(x)
    vars_text = concat_char(vars_num)
    
    print "def test_%s" % count
    count += 1
    
    print "    def f(%s)" % parameters
    print "        return %s" % vars_text
    print "    end"
    
    for y in caller:
        arguments = replace_B(y)
        print "    begin; puts \"repro:%s\"; p f(%s); rescue ArgumentError; puts('except'); end;" % ("f(%s)" % arguments, arguments);
    
    print "end\n"

for x in range(count):
    print "test_%s" % x
