from compat_common import *

left_side = '''
A
A,A
*A
A,*A
(A,)
(A,A)
(A,*A)
(*A)
(A,A),A
'''.split()

right_side = '''
nil
[]
[nil]
B
B,B
B,B,B
[B]
[B,B]
[B,B,B]
*B
*nil
*[]
*[nil]
*[B]
*[B,B]
B,*[B,B]
*[[]]
B,*[]
[B,B],B
nil,B
'''.split()

lines = []
fc = 0

print '''
def p *a
  a.each { |x| print x.inspect, '; ' }
  puts
end
'''

for x in left_side:
    left, vars_num = replace_A(x)
    vars_text = concat_char(vars_num)
        
    print "def f%s()" % fc        
    for y in right_side:
        right = replace_B(y)
        
        print "    %s = 0; puts 'repro: %s = %s'; %s = %s; p %s" % (vars_text, left, right, left, right, vars_text)

    print "end"        
    fc += 1

for x in range(fc):
    print "f%s()" % x

