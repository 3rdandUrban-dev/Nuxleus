require "../../util/simple_test.rb"

describe "range creation" do

  it "creates an inclusive range object from integer literals" do
    a = 0..1
    a.class.name.should == "Range"
    a.begin.should == 0
    a.end.should == 1
    a.exclude_end?.should == false
  end

  it "creates an inclusive range object from integer expressions" do
    x = 0
    y = 1
    a = x..y + 1
    a.class.name.should == "Range"
    a.begin.should == 0
    a.end.should == 2
    a.exclude_end?.should == false
  end

  it "creates an exclusive range object from integer literals" do
    a = 0...2
    a.class.name.should == "Range"
    a.begin.should == 0
    a.end.should == 2
    a.exclude_end?.should == true
  end

  it "creates an exclusive range object from integer expressions" do
    x = 0
    y = 1
    a = x...y + 1
    a.class.name.should == "Range"
    a.begin.should == 0
    a.end.should == 2
    a.exclude_end?.should == true
  end
end

describe "inspecting range objects" do
  it "tests for range equality in inclusive and exclusive ranges" do
    (0..1).should == (0..1)
    (0..1).should == (0..1)
    (0...1).should == (0...1)
    (0..1).should_not == (0...1)
    (0..1).should_not == (0..2)
    (-1..1).should_not == (0..1)
  end
end
