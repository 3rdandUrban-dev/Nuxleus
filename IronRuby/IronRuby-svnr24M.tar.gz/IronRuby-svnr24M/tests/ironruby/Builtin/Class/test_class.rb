require "../../util/simple_test.rb"

describe "inspecting class attributes" do
  it "reads the name of a class" do
    "bob".class.name.should == "String"
    "bob".class.to_s.should == "String"
    "bob".class.class.name.should == "Class"
    String.name.should == "String"
    String.class.name.should == "Class"
  end
end

finished
