require '../../util/assert.rb'

def test_begin_ensure_and_nothing_in_the_body
    x = begin 
        # nothing here        
    ensure; 10; end 
    assert_equal(x, nil)
end 

def test_begin_ensure_and_number_in_the_body
    x = begin 
        20
    ensure; 30; end 
    
    assert_equal(x, 20)
end 

def test_begin_ensure_and_return_in_the_body
    x = begin 
        return 40
        50
    ensure; 60; end 
    assert_equal(x, 40)
end 

def test_begin_ensure_and_return_in_the_ensure
    x = begin; 70; ensure; return 80; 90; end 
    assert_equal(x, 80)
end 

def test_begin_ensure_and_return_in_both
    x = begin; return 100; ensure; return 110; 120; end 
    assert_equal(x, 110)
end 

def test_begin_rescue_not_throw
    x = begin; 10; rescue; 20; end 
    assert_equal(x, 10)
end 

def test_begin_rescue_throw_but_return_nothing_in_rescue
    x = begin; divide_by_zero; 30; rescue; end 
    assert_equal(x, nil)
end 

def test_begin_rescue_throw
    x = begin; divide_by_zero; 30; rescue; 40; end 
    assert_equal(x, 40)
end 

# !!!
def test_begin_rescue_else
    x = begin; 10; rescue; 20; else; 30; end 
    assert_equal(x, 30)
end 

def test_begin_rescue_else_and_return_in_both
    x = begin; return 40; rescue; 50; else; return 60; end 
    assert_equal(x, 60)
end 

def test_throw
    begin
        x = begin; divide_by_zero; ensure; 20; end 
    rescue 
    end 
    assert_equal(x, nil)
end 

def test_throw_with_return_inside_ensure
    begin
        x = begin; divide_by_zero; ensure; return 20; end 
    rescue 
    end 
    assert_equal(x, nil)
end 

#runtest(self)

test_begin_ensure_and_nothing_in_the_body
test_begin_ensure_and_number_in_the_body
test_begin_ensure_and_return_in_the_body
test_begin_ensure_and_return_in_the_ensure
test_begin_ensure_and_return_in_both
test_begin_rescue_not_throw
test_begin_rescue_throw_but_return_nothing_in_rescue
test_begin_rescue_throw
test_begin_rescue_else
test_begin_rescue_else_and_return_in_both
# bug: 269526
#test_throw
#test_throw_with_return_inside_ensure
