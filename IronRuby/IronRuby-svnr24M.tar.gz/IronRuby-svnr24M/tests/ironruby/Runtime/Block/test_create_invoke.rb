require '../../util/assert.rb'
require 'block_common.rb'

def test_0_arg
    b = lambda { 1 }
    assert_equal(b.call, 1)
    assert_equal(b.call(1, 2, 4), 1)
#    assert_raise(ArgumentError) { b.call(1) }
    
    b = lambda { divide_by_zero }
    assert_raise(ZeroDivisionError) { b.call }
end    

def test_1_arg
    b = lambda { |x| x }
    assert_equal(b.call(9), 9)
    b.call(3, 4)  # warning
end 

test_0_arg
test_1_arg