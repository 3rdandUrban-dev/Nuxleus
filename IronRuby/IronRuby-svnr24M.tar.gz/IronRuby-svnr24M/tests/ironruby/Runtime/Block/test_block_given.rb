require '../../util/assert.rb'

# also what could we pass to the block argument? it is necessary
# the rule is: 
#    - &arg is optional, either specify it or skip it.
#    - proc is not taken as block argument, &proc works


def method
    block_given?
end 

empty = lambda {}

assert_equal(method, false)
assert_equal(method {}, true)
assert_equal(method(&empty), true)
assert_raise(ArgumentError) { method(empty) }


def method_with_1_arg arg
    block_given?
end 

assert_equal(method_with_1_arg(1), false)
assert_equal(method_with_1_arg(1) {}, true)
assert_equal(method_with_1_arg(1, &empty), true)

assert_raise(ArgumentError) { method_with_1_arg(1, empty) }
assert_equal(method_with_1_arg(empty), false)

def method_with_explict_block &p
    l = 1
    if p == nil
        l += 10
    else
        l += 100
    end 
    if block_given?
        l += 1000
    else
        l += 10000
    end
    l
end 

assert_equal(method_with_explict_block, 10011)
assert_raise(ArgumentError) { method_with_explict_block(1) }
assert_equal(method_with_explict_block {}, 1101)
assert_equal(method_with_explict_block(&empty), 1101)
assert_raise(ArgumentError) { method_with_explict_block(empty) }

