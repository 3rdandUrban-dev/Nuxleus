require '../../util/assert.rb'

# basic usage of methods in class

class My_methods
    def My_methods.sm; 10; end
    def im; 20; end
end   

x = My_methods.new

assert_equal(x.im, 20)
assert_equal(x::im, 20)
assert_equal(My_methods.sm, 10)
assert_equal(My_methods::sm, 10)

assert_raise(NoMethodError) { x.sm }
assert_raise(NoMethodError) { My_methods.im }

class My_methods_with_same_name
    def My_methods_with_same_name.m; 10; end
    def m; 20; end
end

x = My_methods_with_same_name.new
assert_equal(My_methods_with_same_name.m, 10)
assert_equal(x.m, 20)

