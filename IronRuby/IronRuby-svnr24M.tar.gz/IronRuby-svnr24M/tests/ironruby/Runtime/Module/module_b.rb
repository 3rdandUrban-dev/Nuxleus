module Pacific
    SIZE2 = 300
    
    def Pacific.listen2
        301
    end
     
    class Ocean
        FLAG2 = 302
    end  
    
    module Hawaii
        KIND2 = 303
    end 
end 


TOP_SIZE2 = 400

def top_method2
    401
end 

class Top_Class2
    FLAG = 402
end  

var2 = 402