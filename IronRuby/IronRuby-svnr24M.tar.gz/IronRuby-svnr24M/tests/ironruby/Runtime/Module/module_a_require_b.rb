module A
  X = 100
end 

require "module_b_require_a"

module A 
  Z = B::Y + 100
end 