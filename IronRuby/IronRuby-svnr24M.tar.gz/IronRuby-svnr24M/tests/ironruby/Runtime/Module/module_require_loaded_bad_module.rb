CONST_U = 83

require "module_with_divide_by_zero2" 

CONST_V = 94