module Pacific
    SIZE = 500
    
    def Pacific.listen
        501
    end
     
    class Ocean
        FLAG = 502
    end  
    
    module Hawaii
        KIND = 503
    end 
end 

TOP_SIZE = 600

def top_method
    601
end 

class Top_Class
    FLAG = 602
end  

var = 603