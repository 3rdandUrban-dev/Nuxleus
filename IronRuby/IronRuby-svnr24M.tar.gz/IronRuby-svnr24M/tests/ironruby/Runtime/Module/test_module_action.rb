require '../../util/assert.rb'

module Target
    
end 

assert_raise(NoMethodError) { Target.new }  # undefined method `new' for Target:Module
assert_raise(NoMethodError) { Target() }    # undefined method `Target' for main:Object