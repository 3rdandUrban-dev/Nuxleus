variable_in_module_with_syntax_error_one = 1
variable_in_module_with_syntax_error_two = (1, 2)  # syntax error