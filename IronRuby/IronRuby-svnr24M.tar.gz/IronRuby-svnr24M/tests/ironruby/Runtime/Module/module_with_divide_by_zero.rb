module Module_With_Divide_By_Zero
    CONST_ONE = 1
    CONST_TWO = 2 / 0
end     