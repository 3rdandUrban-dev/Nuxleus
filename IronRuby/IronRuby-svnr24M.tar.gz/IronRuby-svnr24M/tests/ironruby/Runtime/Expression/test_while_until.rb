# page 344

require '../../util/assert.rb'

# executes body zero or more times as long as bool-expression is true (for while), false (for until)

def test_zero_times
    $g = 1
    while false
      $g += 10
    end
    assert_equal($g, 1)
    
    until true 
      $g += 100
    end 
    assert_equal($g, 1)
end 

def test_more_times
    x = true
    $g = 0
    while x
        $g += 1
        if $g > 2
            x = false
        end
    end 
    assert_equal($g, 3)

    x = false
    $g = 0
    until x
        $g += 1
        if $g > 5
            x = true
        end
    end 
    assert_equal($g, 6)
end

# while and until modifier
def test_modifer
    # bad thing won't happen
    divide_by_zero while false
    divide_by_zero until true

    #
    x = 0 
    x += 1 while x > 5
    assert_equal(x, 0)
    x = 0
    x += 1 while x < 5
    assert_equal(x, 5)

    x = 0
    x += 1 until x > 5
    assert_equal(x, 6)
    x = 0
    x += 1 until x < 5
    assert_equal(x, 0)
end

def test_evaluate_condition
    $g = $c = 1 
    x = true
    while ($g+=10; x)
        $c += 1
        x = $c < 3
    end
    assert_equal($g, 31)
    
    $g = $c = 1 
    x = false
    until ($g+=10; x)
        $c += 1
        x = $c > 3
    end
    assert_equal($g, 41)    
end 

test_zero_times
test_more_times
test_modifer
test_evaluate_condition
