
require '../../util/assert.rb'

assert_raise(ArgumentError) { true..false }
assert_raise(ArgumentError) { false..false }

