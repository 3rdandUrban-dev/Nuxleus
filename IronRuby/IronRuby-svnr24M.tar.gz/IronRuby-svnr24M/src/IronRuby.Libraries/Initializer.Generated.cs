[assembly: Ruby.RubyLibraryAttribute(typeof(Ruby.Libraries.LibrariesInitializer))]
namespace Ruby.Libraries {
    public sealed partial class LibrariesInitializer : Ruby.Builtins.LibraryInitializer {
        protected override void LoadModules() {
            
            
            RegisterModule("Sample", typeof(Ruby.Libraries.Sample), new System.Action<Ruby.Builtins.RubyModule>(LoadSample), Ruby.Builtins.RubyModule.EmptyArray);
        }
        
        private void LoadSample(Ruby.Builtins.RubyModule/*!*/ module) {
            module.DefineClassMethod("hello", Ruby.Runtime.RubyMethodVisibility.Public, new System.Delegate[] {
                new System.Action<System.Object>(Ruby.Libraries.Sample.Hello),
            });
            
        }
        
    }
}
