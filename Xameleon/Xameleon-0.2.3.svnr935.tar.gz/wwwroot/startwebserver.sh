mono bin/xsp2.exe --port 9999 --applications /:.
