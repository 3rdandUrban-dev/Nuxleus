function hello(){
  alert('It seems you are running IE. Your code base has been optimized accordingly.');
};
