function hello(){
  alert('It seems you are running Opera. Your code base has been optimized accordingly.');
};
