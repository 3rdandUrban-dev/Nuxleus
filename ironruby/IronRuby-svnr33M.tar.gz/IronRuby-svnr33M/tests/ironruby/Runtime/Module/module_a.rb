module Pacific
    SIZE = 100
    
    def Pacific.listen
        101
    end
    
    class Ocean
        FLAG = 102
    end   
    
    module Hawaii
        KIND = 103
    end  
end 

TOP_SIZE = 200

def top_method
    201
end 

class Top_Class
    FLAG = 202
end

var = 203