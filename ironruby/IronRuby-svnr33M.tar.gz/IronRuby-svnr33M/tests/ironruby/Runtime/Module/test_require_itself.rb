
if defined? $global_var
    $global_var += 10
else
    $global_var = 1
end

$global_var += 100

puts $global_var

require "test_require_itself.rb"

$global_var += 1000

puts $global_var

require "./test_require_itselF.rb"

$global_var += 10000

puts $global_var

