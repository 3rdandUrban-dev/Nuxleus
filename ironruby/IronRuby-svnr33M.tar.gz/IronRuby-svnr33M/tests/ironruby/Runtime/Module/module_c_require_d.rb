require "module_d_require_c"

module C 
  X = D::Y
end 