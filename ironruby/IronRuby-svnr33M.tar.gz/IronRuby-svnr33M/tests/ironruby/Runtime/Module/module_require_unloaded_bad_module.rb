CONST_X = 77

require "module_with_divide_by_zero2"

CONST_Y = 99