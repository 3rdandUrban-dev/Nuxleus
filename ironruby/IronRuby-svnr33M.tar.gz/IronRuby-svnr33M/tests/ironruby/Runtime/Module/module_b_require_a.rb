require "module_b_require_a"

module B
  Y = A::X + 100
end 