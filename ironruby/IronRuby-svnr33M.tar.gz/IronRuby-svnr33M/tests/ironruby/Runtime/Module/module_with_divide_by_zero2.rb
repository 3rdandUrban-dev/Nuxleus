module Module_With_Divide_By_Zero
    CONST_THREE = 3
    CONST_FOUR = 4 / 0
end