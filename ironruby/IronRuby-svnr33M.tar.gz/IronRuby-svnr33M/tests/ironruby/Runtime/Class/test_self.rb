require '../../util/assert.rb'

assert_equal(self.to_s, "main")
assert_equal(self.class, Object)

module Simple
    assert_equal(self.to_s, "Simple")
    assert_equal(self.class, Module)
    
    class My
        assert_equal(self.to_s, "Simple::My")
        assert_equal(self.class, Class)
        
        def My.check
            assert_equal(self.to_s, "Simple::My")
            assert_equal(self.class, Class)
        end 
        
        def check
            assert_true { self.to_s.include? "#<Simple::My" }
            assert_equal(self.class, My)
        end 
    end
end 


Simple::My.check

x = Simple::My.new
x.check

class << x
    assert_true { self.to_s.include? "#<Class:#<Simple::My:" }
    assert_equal(self.class, Class)
end    

def x.method
    assert_true { self.to_s.include? "#<Simple::My:" }  # object x
    assert_equal(self.class, Simple::My)
end 
x.method