
require '../../util/assert.rb'

# left side of assignment may contain a parenthesized list of terms.
# it extracts the corresponding rvalue, assigning it to the parenthesized terms, before continuing
# with higher-level assignment.

# (a) = 3: syntax error

