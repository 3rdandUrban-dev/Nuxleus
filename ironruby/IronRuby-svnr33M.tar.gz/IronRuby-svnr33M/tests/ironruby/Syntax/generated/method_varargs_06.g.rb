
def method(a, *b)
	b
end 
method(1)
method(1, 2)
method(1, 3, 4)
method(1, [5, 6])
method(1, [7], 8)
# Scenario: two parameters, vararg last
# Default: pass
