
def .method
  1
end 
# Scenario: method name begins with .
# Default: syntax error
