def method end
# Scenario: "end" in the same line as "def"
# Default: syntax error
