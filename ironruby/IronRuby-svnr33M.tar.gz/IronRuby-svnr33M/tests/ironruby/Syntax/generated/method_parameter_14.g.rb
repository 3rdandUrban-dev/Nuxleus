
def method a, b, c, *b
	1
end 
# Scenario: with varargs (??)
# Default: pass
# ParseOnly: merlin_bug#248256
## COMPAT: duplicate rest argument name
