
def method a=3 end
# Scenario: without parenthesis, "end" in the same line as "def"
# Default: syntax error
