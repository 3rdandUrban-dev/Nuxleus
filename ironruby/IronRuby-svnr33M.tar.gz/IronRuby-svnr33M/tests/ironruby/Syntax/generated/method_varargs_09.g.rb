
def method(a=2, b, *c)
	return a, b, c
end 
# Scenario: three parameters: b have been first?
# Default: syntax error
