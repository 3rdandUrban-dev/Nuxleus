
def method(a, b)
	return a, b
end 	

method({ 
	'language' => 'ruby',
	'framework' => '.net'
	}, 8)

method(9, { 
	'language' => 'ruby',
	'framework' => '.net'
	})

method(12, 'framework' => '.net')
method(34, 'language' => 'ruby', 'framework' => '.net')
# Scenario: two args (postive)
# Default: pass
