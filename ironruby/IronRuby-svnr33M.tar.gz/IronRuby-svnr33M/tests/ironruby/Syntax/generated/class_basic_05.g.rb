
class MyClass	
end 

class CLASS	# all uppercase
end

class My_Class # underscore
end 
# Scenario: allowed:
# Default: pass
