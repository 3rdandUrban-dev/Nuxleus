
def method a, *b, &block
	1
end
method(1)
method(1,2) 
method(1, 2, 3)
method(1, 2, 3, 4) {5}
# Scenario: without parenthesis, 3 args
# Default: pass
