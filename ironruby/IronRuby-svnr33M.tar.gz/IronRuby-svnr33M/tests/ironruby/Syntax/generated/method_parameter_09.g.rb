

def method(a, b)
	a + b
end 
method(1,2)
# Scenario: normal with parentheses
# Default: pass
