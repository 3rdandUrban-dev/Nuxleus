
class C(Object)
end 
# Scenario: use ()
# Default: syntax error
