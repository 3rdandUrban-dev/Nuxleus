
a = %w

# Scenario: (unterminated string meets end of file)
# Default: unterminated
# ParseOnly: merlin_bug#248301
