
a = [ , ]
# Scenario: trialing comma after empty 
# Default: syntax error
