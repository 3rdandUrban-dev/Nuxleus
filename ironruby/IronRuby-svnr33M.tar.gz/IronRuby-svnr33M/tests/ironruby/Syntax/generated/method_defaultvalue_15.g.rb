
def method a=3,
	b
end 
# Scenario: without parenthesis, parameters in different lines
# Default: syntax error
