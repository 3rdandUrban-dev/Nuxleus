
a = []
a = [    ]
# Scenario: empty array 
# Default: pass
