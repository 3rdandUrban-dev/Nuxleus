
h 
= {}
# Scenario: 
# Default: syntax error
