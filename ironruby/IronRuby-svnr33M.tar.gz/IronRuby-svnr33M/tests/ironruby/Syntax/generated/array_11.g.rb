
a = [
4
,
5
]
# Scenario: comma position
# Default: syntax error
