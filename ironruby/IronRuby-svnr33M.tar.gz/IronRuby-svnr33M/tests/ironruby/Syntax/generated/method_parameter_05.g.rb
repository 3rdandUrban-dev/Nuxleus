
#* paramname
def method("abc")
end 
# Scenario: string literal as param name
# Default: syntax error
