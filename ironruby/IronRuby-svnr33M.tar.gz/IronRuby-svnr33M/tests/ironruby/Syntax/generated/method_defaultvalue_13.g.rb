
## TWO+ PARAMETERS
def method a,
	b = 2
end 
method(1)
method(2, 3)
method(a=4)
method(a=4, b=a * 2)
# Scenario: without parenthesis, parameters in different lines
# Default: pass
