
{10:20}
# Scenario: seperator ":"
# Default: syntax error
