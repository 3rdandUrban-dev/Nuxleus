
def method 1 end 
# Scenario: body/"end" in the "def" line
# Default: syntax error
