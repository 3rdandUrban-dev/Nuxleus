class C < Object
end 

class D < C
end 
# Scenario: normal
# Default: pass
