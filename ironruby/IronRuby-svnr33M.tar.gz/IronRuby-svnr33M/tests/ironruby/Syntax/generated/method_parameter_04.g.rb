
b = 10
def method a b
end 
# Scenario: missing comma, but the next one is valid symbol
# Default: syntax error
