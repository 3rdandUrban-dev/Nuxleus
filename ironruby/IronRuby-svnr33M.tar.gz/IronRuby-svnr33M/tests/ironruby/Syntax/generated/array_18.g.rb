
a = %W   (bc)

# Scenario: space
# Default: unterminated
# ParseOnly: merlin_bug#248301
