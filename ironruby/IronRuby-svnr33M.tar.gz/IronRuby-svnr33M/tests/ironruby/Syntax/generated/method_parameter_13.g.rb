
def method a, b, a=10
	1
end
# Scenario: with default value
# Default: duplicate optional argument name
# ParseOnly: merlin_bug#248256
