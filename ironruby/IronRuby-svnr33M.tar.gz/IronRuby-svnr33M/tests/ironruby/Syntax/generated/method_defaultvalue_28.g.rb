
def method(c=-1, d=c+5)
	c + d
end 
method
method(1)
method(2, 3)
method(c=4)
method(d=5)
method(c=6, d=7)
method(d=8, c=9)
# Scenario: default value is expression with another parameter
# Default: pass
