
def method a,
end 
# Scenario: extra comma, without parenthesis
# Default: syntax error
