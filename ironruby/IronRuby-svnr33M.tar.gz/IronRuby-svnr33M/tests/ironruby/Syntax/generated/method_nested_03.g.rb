
def method def nested
end 
end
# Scenario: 
# Default: syntax error
