 
def method def 
nested end 
end
# Scenario: unknown
# Default: syntax error
