
10
..15
# Scenario: line starts with ..
# Default: syntax error
