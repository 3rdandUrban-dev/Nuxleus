
a = %w{ a }
a = %W{ a }  
a = %W{ #a }  
a = %W{ #{a} }

a= %w[ %w{} ]
a= %W{ %w{} }

# Scenario: one element
# Default: pass
