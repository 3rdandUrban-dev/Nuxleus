
a = [1, ,]
# Scenario: 
# Default: syntax error
