
def method(*a, b)
end 
# Scenario: two parameters, vararg first
# Default: syntax error
