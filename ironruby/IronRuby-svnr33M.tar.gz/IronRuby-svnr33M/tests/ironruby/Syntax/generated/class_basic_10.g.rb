
class "string"
end 
# Scenario: string as name
# Default: syntax error
