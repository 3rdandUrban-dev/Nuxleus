
def method a=3,
end 
# Scenario: without parenthesis, with extra comma
# Default: syntax error
