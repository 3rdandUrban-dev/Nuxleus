
def method a, &block, 
	
end 
# Scenario: without parenthesis, comma as last
# Default: syntax error
