
$a = 10
def method(c=-1, d=$a)
	puts c, d
	c + d
end 
method
method(1)
method(2, 3)
method(c=4)
method(d=5)
method(c=6, d=7)
method(d=8, c=9)
# what is "a" now?
# Scenario: default value is another variable
# Default: pass
