
class C,
end 
# Scenario: comma after name
# Default: syntax error
