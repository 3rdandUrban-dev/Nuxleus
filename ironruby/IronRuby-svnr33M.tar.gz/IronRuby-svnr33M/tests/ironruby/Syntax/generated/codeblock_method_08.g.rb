
#* calling

def method
	1
end 
method
method { 2 }
# Scenario: can pass block no matter what
# Default: pass
