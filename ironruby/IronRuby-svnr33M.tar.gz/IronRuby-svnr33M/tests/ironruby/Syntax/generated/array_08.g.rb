
a = [[]]
a = [[], ]
a = [[], []]
# Scenario: unknown
# Default: pass
