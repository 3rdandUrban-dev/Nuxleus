
def method(a, b, c)
	return a, b, c
end 
method(*[1, 2, 3])
method(4, *[5, 6])
method(7, 8, *[9])
method(10, 11, 12, *[])
# Scenario: where can it be put?
# Default: pass
