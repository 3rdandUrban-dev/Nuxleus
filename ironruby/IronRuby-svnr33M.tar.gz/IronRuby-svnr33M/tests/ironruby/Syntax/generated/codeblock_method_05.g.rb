
def method a, &block, *c
	1
end 
# Scenario: without parenthesis, 3 args
# Default: syntax error
