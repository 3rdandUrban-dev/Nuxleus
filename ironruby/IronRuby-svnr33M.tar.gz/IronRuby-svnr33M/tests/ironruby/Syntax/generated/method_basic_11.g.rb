
def []
  1
end 
# Scenario: empty array (operator) after def
# Default: pass
