
10..
20
10 ..
20
# Scenario: new line
# Default: pass
