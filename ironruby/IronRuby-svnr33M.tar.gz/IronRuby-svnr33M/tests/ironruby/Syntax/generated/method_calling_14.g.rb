
def method(a, b)
	return a, b
end
method('language' => 'ruby', 2, 'framework' => '.net')
# Scenario: two args
# Default: syntax error
