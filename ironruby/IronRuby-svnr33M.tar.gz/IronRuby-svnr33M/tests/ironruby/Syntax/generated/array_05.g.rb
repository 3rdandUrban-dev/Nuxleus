
a = [2.]
# Scenario: 
# Default: syntax error
