
def method(1)
end 
# Scenario: digit as param name
# Default: syntax error
