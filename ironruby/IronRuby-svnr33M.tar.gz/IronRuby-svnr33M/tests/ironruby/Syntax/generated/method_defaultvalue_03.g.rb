
def method a=3
	1
end 
method
method(10)
# Scenario: without parenthesis
# Default: pass
