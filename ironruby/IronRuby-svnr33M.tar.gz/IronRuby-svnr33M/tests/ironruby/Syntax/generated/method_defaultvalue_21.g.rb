
#* calling
def method(a=-3, b=-4)
	a + b
end 

method
method(-2)
method(-1, 0)
method(a = 1)
method(b = 2)
method(a = 3, b = 4)
method(b = 5, a = 6)

method(7, a = 8)
method(a = 9, 10)
method(11, b = 12)
method(b=13, 14)
# Scenario: both have default values
# Default: pass
