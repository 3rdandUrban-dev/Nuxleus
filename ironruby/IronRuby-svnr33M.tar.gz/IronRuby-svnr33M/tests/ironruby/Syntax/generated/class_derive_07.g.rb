
class 
	C	< # indicator for superclass
	Object
end	
# Scenario: unknown
# Default: pass
