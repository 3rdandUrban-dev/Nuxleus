
class << 1
end 
# Scenario: no virtual class for Fixnum
# Default: TypeError
# ParseOnly: pass
