
a = [.] 
# Scenario: dot
# Default: syntax error
