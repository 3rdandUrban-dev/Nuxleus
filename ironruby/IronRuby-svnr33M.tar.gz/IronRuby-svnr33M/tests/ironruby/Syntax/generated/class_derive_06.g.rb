
class D < Fixnum
end 
# Scenario: Fixnum directly
# Default: pass
