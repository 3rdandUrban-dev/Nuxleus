
#a 
#= 
#[7]
## Scenario: unknown
## Default: syntax error

a = %w{  }
a = %W{ }
a = %w()
a = %W( )
# Scenario: empty
# Default: pass
