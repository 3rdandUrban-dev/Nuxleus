
def method a, &block
	1
end 
method(1)
method(2) { 2 }
# Scenario: without parenthsis, two args
# Default: pass
