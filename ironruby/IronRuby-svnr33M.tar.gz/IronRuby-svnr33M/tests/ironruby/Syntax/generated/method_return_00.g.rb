
def m
    1, 
end 

# Scenario: comma at the end 
# Default: syntax error
