
def method(*a=10)
end 
# Scenario: with default value
# Default: syntax error
