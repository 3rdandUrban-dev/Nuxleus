
def 
  method 
    a
  end 
method 1  
# Scenario: "a" as method body here
# Default: ArgumentError
# ParseOnly: pass
