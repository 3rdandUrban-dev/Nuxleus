
def method(**a)
end 
# Scenario: with double star
# Default: syntax error
