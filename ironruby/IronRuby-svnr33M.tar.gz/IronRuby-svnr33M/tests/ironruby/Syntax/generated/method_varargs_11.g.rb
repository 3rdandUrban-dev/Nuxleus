
def method(a, b=-2, *c)
	return a, b, c
end 
method(1)
method(2, 3)
method(4, 5, 6)
method(c=[8, 9], a=1)
method(1, 2, c=[10])
# Scenario: three parameters (positive)
# Default: pass
