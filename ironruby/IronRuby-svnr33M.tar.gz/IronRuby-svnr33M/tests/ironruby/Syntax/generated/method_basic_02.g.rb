
def 
  method
end
method
# Scenario: method name in the different line as "def"
# Default: pass
