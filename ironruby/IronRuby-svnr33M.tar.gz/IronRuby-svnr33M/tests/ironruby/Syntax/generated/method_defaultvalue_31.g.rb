
def method(c=d, d=4)
	c+d
end 
method
# Scenario: undefined local variable or method `d' for main:Object
# Default: NameError
# ParseOnly: pass
