
10..20..30
# Scenario: invalid
# Default: syntax error
