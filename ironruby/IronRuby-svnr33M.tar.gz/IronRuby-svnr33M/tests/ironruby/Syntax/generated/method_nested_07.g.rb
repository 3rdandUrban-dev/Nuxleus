
def method 
	def 
	nested 
end 
end
method 
# Scenario: unknown
# Default: pass
