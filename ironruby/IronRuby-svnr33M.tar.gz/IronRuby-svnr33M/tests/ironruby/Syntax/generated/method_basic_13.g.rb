
def [i, j]
  1
end 
# Scenario: non-empty array after def
# Default: syntax error
