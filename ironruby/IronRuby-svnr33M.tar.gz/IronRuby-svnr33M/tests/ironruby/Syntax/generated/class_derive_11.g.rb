
class A 
end 
class B
end 

class C(A, B)
end 
# Scenario: multiple inheritance
# Default: syntax error
