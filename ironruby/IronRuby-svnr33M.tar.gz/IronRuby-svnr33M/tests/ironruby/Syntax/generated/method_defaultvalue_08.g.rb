
def method(a=)
end 
# Scenario: with parentheis, without default value
# Default: syntax error
