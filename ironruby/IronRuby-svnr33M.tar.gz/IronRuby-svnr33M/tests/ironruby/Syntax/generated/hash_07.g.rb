	
h = { 
	200
	, 
	"str" 
	}
# Scenario: newline
# Default: syntax error
