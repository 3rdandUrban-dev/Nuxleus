
class _Myclass
end 
# Scenario: starting with underscore
# Default: class/module name must be CONSTANT
# ParseOnly: Class/module name must be a constant
