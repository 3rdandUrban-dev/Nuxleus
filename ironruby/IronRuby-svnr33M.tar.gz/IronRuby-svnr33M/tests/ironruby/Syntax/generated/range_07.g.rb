
10
...20
# Scenario: newline
# Default: syntax error
