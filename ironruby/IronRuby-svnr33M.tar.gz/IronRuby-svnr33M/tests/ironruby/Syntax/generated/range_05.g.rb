
x = []
x..10
# Scenario: array as range start
# Default: ArgumentError
# ParseOnly: pass
