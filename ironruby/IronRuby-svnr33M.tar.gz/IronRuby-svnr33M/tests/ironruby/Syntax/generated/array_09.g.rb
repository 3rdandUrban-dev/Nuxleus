
a = [[] []]
# Scenario: `[]': wrong number of arguments (0 for 1) (ArgumentError)
# Default: ArgumentError
# ParseOnly: pass
