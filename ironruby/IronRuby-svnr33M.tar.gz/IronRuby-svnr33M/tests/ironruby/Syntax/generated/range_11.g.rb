
10 ... 20
10... 30
10 ...40
# Scenario: space
# Default: pass
