## inclusive range

10..30
10.1..20
10..20.5
-10..30
10..-40
-40..-50
-60..-10

'a'..'z'
'Z'..'A'

x = 9
x..x
x..-x
# Scenario: valid
# Default: pass
