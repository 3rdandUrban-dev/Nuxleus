class end
# Scenario: no name
# Default: syntax error
