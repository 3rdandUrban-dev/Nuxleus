
def method() 1 end
method

def method ( ) 1 end # space between the name and the parenthesis
method

def method(a)  1 end
method 1

def method(a)  1
end 
method 1
# Scenario: body/"end" in the "def" line, parameters specified by parenthesis
# Default: pass
