
THIS_DIRECTORY = File.expand_path(File.dirname(__FILE__)).downcase
CURR_DIRECTORY = Dir.pwd.downcase

require File.join(THIS_DIRECTORY, 'common')

$failures = 0

class TestListFile
    def TestListFile.load
        test_lst_file = File.join(THIS_DIRECTORY, "test.lst")
        
        # filter empty line and comment line
        lines = open(test_lst_file, 'r').readlines.find_all { |l| l.chop.strip != "" and l.index("#") != 0  } 
        
        # remove \r\n, space 
        lines.collect! { |l| l.chop.strip }
        
        lines.collect do |l|
            parts = l.split
            raise "unexpected test entry: #{l}" if parts.length > 2
            TestListFile.new(*parts) 
        end 
    end 
    
    def initialize(file_name, driver_list='all')
        @file_name = file_name
        @driver_list = driver_list 
    end 
    
    def should_run_with?(driver)
        return true if @driver_list == "all"
        return false if @driver_list == "none"
        if @driver_list.include? '-'
            # you do not have to specify "wanted"
            @driver_list.include?(driver.name + "-") == false
        else 
            @driver_list.include? driver.name
        end
    end 
    
    def run_by(driver)
        if not should_run_with? driver
            printf "s"
        else 
            if driver.run(@file_name, driver.logger.log_name) == 0
                printf "."
            else
                $failures += 1
                printf "x(%s)", File.basename(@file_name)
            end 
        end
    end
    
    def run_skipped_by(driver)
        if not should_run_with? driver
            if driver.run(@file_name, driver.logger.log_name) == 0
                printf "p(%s)", File.basename(@file_name)
            else
                printf "f"
            end 
        end
    end 
end 

# drivers
applicable_drivers = [ Test::CRuby, Test::Iron_m1, Test::Iron_m2, Test::Iron_cc, ]
applicable_drivers = [ Test::Iron_cc ]  if ARGV.include? "-coreclr"
applicable_drivers = [ Test::CRuby, Test::Iron_m1, Test::Iron_m2, ]   if ARGV.include? "-desktop"
applicable_drivers = [ Test::Iron_m1, Test::Iron_cc, ]  if ARGV.include? "-fast"

test_files = TestListFile::load 

applicable_drivers.each do |driver|
    puts ">>> Running under #{driver}  \n"
    puts "    log @ #{driver.logger} \n"
    if ARGV.include? "-neg"
        test_files.each { |tf| tf.run_skipped_by(driver) }
    else
        test_files.each { |tf| tf.run_by(driver) }
    end
    puts "\n\n"
end

if ARGV.include? "-desktop"
    [
        'syntax',
        'compat',
    ].each do |s|
        puts ">>> Running #{s} test \n"
        ret = Test::CRuby.run(File.join(TestPath::TEST_DIR, "#{s}/run_#{s}.rb -snap "), Test::CRuby.logger.log_name)
        if ret == 0
            puts "pass"
        else
            $failures += ret
            puts "fail"
        end
        puts "\n"
    end
end 

puts "\nSummary: #{$failures}\n"

exit($failures)