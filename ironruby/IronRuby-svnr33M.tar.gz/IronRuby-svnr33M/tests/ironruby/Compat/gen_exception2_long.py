# rescue_clause = empty | rescue_default | rescue_E | rescue_which_raise_E
# else_clause = empty | "else"
# ensure_clause = empty | "ensure"
# body = not_raise | raise_E

class RescueInfo:
    def __init__(self, present, except_type, raise_in_param):
        self.present = present
        self.except_type = except_type
        self.raise_in_param = raise_in_param
    
    def get_code(self):
        if self.present:
            if self.raise_in_param: 
                s = "rescue (puts B, $!.class; raise IOError)"
            else: 
                s = "rescue "
                if self.except_type: 
                    s += self.except_type 
            for x in possible_bodies:
                yield s + "; \n" + x
        else:
            yield "#empty_rescue"
                
class ElseInfo:
    def __init__(self, present):
        self.present = present
    def get_code(self):
        if self.present:
            for x in possible_bodies:
                yield "else; \n" + x
        else:
            yield "#empty_else"

class EnsureInfo:        
    def __init__(self, present):
        self.present = present
    def get_code(self):
        if self.present:
            for x in possible_bodies:
                yield "ensure; \n" + x
        else:
            yield "#empty_ensure"
        
class EH:
    def __init__(self, rescue_info, else_info, ensure_info):
        self.rescue_info = rescue_info
        self.else_info = else_info
        self.ensure_info = ensure_info
        
    def get_code(self):
        for x in possible_bodies:
            for ri in self.rescue_info.get_code():
                for eli in self.else_info.get_code():
                    for eni in self.ensure_info.get_code():
                        s = "begin\n"
                        s += x + "\n"
                        s += ri + "\n"
                        s += eli + "\n"
                        s += eni + "\n"
                        s += "end\n"
                        yield s
            
def rescueinfo_generator():
    for x in [True, False]:
        for y in [None, "ZeroDivisionError", "IOError"]:
            for z in [True, False]:
                yield RescueInfo(x, y, z)

def elseinfo_generator():
    for x in [True, False]:
        yield ElseInfo(x)

def ensureinfo_generator():
    for x in [True, False]:
        yield EnsureInfo(x)

possible_bodies = map(lambda x : "     puts B, $!.class;" + x, ["", 
        "1/0", 
        "raise TypeError", 
        "raise SyntaxError.new", 
        "return 3", 
        "break",
        "begin; puts B, $!.class; raise ArgumentError; rescue TypeError; end", 
        "begin; puts B, $!.class; ensure; puts B, $!.class; raise TypeError; end",
        "$! = IOError.new", 
        "$! = TypeError.new", 
        #"if $g==0 then; $g = 1; retry; end",
        ])

# another body set
# possible_bodies = 

from compat_common import *
       
fc = FileCreator("test_exception2", 200)
count = 0

for x in rescueinfo_generator():
    for y in elseinfo_generator():
        for z in ensureinfo_generator():
            for w in EH(x, y, z).get_code():
                line1 = "def f_%s\n" % count + w + "puts B, $!.class\nend\n"
                line1 += "$g = 0; begin; print(f_%s); rescue Exception; puts B, $!.class; end; puts \" : f_%s\"\n" % (count, count)
                count += 1
                
                fc.save_block(replace_B(line1))

fc.close()
fc.print_file_list()    
