from compat_common import *
   
f = open("template_block_ctrl_flow.rb")
line = "".join(f.readlines())
f.close()

import sys

if sys.argv[1] == "main":
    mapping = {
            'puts "A"' : "normal", 
            'raise IOError' : "raise", 
            'return' : "return", 
            'break' : "break",
            'next' : "next",
            '$g += 1; retry if $g < 4;' : "retry",
            '$g += 1; redo if $g < 4;' : "redo",
    }        
    
    for (x, y) in mapping.iteritems():
        f = file("test_block_ctrl_flow_%s.rb" % y, "w")
        new_line = replace_B(line.replace("ctrl_flow", x))
        f.writelines(new_line)
        f.close()
else: 
    extras = [
            'return 41',
            'break 42',

            'if 2 == 1; return "B"; end',
            'if 4 == 4; return "C"; end',
            
            'eval("next")',
            'eval("break")',
            'eval("return")',
            'eval("$g += 1; retry if $g < 4;")',
            'eval("$g += 1; redo if $g < 4;")',
            'eval("if 1==2; return; end")', 
            
            'myeval("break")', 
    ]

    fc = FileCreator("test_block_ctrl_flow", 1)

    for x in extras:
        new_line = replace_B(line.replace("ctrl_flow", x))
        fc.save_block(new_line)

    fc.close()   
    fc.print_file_list()
