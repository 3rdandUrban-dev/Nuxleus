
# at 
#         top level code
#       | method call
#       | eval call (TODO)
#       | block
#       | proc
#       | lambda 
#       | loop

# use the 
#         block 
#       | lambda 
#       | Proc 
# and check the return value

# which is 
#         locally created 
#       | locally returned from a method call 
#       | passed as argument 

# return inside body and ensure 

# helper
def myeval(line); puts 1; eval(line); puts 2; end

# producer

def get_block(&p);    p;                end 
def get_lambda(&p);   lambda(&p);       end 
def get_proc(&p);     Proc.new(&p);     end 

def get_local_block;        get_block { puts 3; return; puts 4 };    end 
def get_local_lambda;       lambda { puts 5; return; puts 6 };       end 
def get_local_proc;         Proc.new { puts 7; return; puts 8 };     end 

# consumer 

# taking arguments
def iterator_via_yield;                     puts 9; x = yield; puts x; puts 10;     end 
def iterator_via_call(&p);                  puts 11; puts(p.call); puts 12;   end 

def method_call_iterator_via_yield(&p);     puts 13; iterator_via_yield(&p); puts 14;     end
def method_call_iterator_via_call(&p);      puts 15; iterator_via_call(&p); puts 16;      end 

def method_use_lambda_and_yield;            puts 17; x = lambda { puts 18; yield; puts 19 }; puts x.call; puts 20; end 
def method_use_proc_and_yield;              puts 21; x = Proc.new { puts 22; yield; puts 23 }; puts x.call; puts 24; end 
def method_use_lambda_and_call(&p);         puts 25; x = lambda { puts 26; p.call; puts 27 }; puts x.call; puts 28; end 
def method_use_proc_and_call(&p);           puts 29; x = Proc.new { puts 30; p.call; puts 31 }; puts x.call; puts 32; end 

def method_yield_in_loop;                   puts 33; for i in [1, 2]; puts 34; yield; puts 35; end; puts 36; end 
def method_call_in_loop(&p);                puts 37; for i in [3, 4]; puts 38; p.call; puts 39; end; puts 40; end 


# created in-place
$g = 0; begin; puts 41; iterator_via_yield { puts 42; return; puts 43}; puts 44; rescue; puts 45; puts $!.class; end
$g = 0; def m_1; puts 46; $g = 0; begin; puts 47; iterator_via_yield { puts 48; return; puts 49}; puts 50; rescue; puts 51; puts $!.class; end; puts 52; end; m_1 
$g = 0; begin; puts 53; iterator_via_call { puts 54; return; puts 55}; puts 56; rescue; puts 57; puts $!.class; end
$g = 0; def m_2; puts 58; $g = 0; begin; puts 59; iterator_via_call { puts 60; return; puts 61}; puts 62; rescue; puts 63; puts $!.class; end; puts 64; end; m_2 
$g = 0; begin; puts 65; method_call_iterator_via_yield { puts 66; return; puts 67}; puts 68; rescue; puts 69; puts $!.class; end
$g = 0; def m_3; puts 70; $g = 0; begin; puts 71; method_call_iterator_via_yield { puts 72; return; puts 73}; puts 74; rescue; puts 75; puts $!.class; end; puts 76; end; m_3 
$g = 0; begin; puts 77; method_call_iterator_via_call { puts 78; return; puts 79}; puts 80; rescue; puts 81; puts $!.class; end
$g = 0; def m_4; puts 82; $g = 0; begin; puts 83; method_call_iterator_via_call { puts 84; return; puts 85}; puts 86; rescue; puts 87; puts $!.class; end; puts 88; end; m_4 
$g = 0; begin; puts 89; method_use_lambda_and_yield { puts 90; return; puts 91}; puts 92; rescue; puts 93; puts $!.class; end
$g = 0; def m_5; puts 94; $g = 0; begin; puts 95; method_use_lambda_and_yield { puts 96; return; puts 97}; puts 98; rescue; puts 99; puts $!.class; end; puts 100; end; m_5 
$g = 0; begin; puts 101; method_use_proc_and_yield { puts 102; return; puts 103}; puts 104; rescue; puts 105; puts $!.class; end
$g = 0; def m_6; puts 106; $g = 0; begin; puts 107; method_use_proc_and_yield { puts 108; return; puts 109}; puts 110; rescue; puts 111; puts $!.class; end; puts 112; end; m_6 
$g = 0; begin; puts 113; method_use_lambda_and_call { puts 114; return; puts 115}; puts 116; rescue; puts 117; puts $!.class; end
$g = 0; def m_7; puts 118; $g = 0; begin; puts 119; method_use_lambda_and_call { puts 120; return; puts 121}; puts 122; rescue; puts 123; puts $!.class; end; puts 124; end; m_7 
$g = 0; begin; puts 125; method_use_proc_and_call { puts 126; return; puts 127}; puts 128; rescue; puts 129; puts $!.class; end
$g = 0; def m_8; puts 130; $g = 0; begin; puts 131; method_use_proc_and_call { puts 132; return; puts 133}; puts 134; rescue; puts 135; puts $!.class; end; puts 136; end; m_8 
$g = 0; begin; puts 137; method_yield_in_loop { puts 138; return; puts 139}; puts 140; rescue; puts 141; puts $!.class; end
$g = 0; def m_9; puts 142; $g = 0; begin; puts 143; method_yield_in_loop { puts 144; return; puts 145}; puts 146; rescue; puts 147; puts $!.class; end; puts 148; end; m_9 
$g = 0; begin; puts 149; method_call_in_loop { puts 150; return; puts 151}; puts 152; rescue; puts 153; puts $!.class; end
$g = 0; def m_10; puts 154; $g = 0; begin; puts 155; method_call_in_loop { puts 156; return; puts 157}; puts 158; rescue; puts 159; puts $!.class; end; puts 160; end; m_10 

# created locally or from method
$g = 0; begin; p = lambda{ puts 161; return; puts 162}; puts 163; iterator_via_yield(&p); puts 164; rescue; puts 165; puts $!.class; end
$g = 0; def m_11; p = lambda{ puts 166; return; puts 167}; puts 168; iterator_via_yield(&p); puts 169; end; 
begin; puts 170; m_11; puts 171; rescue; puts 172; puts $!.class; end
$g = 0; begin; p = lambda{ puts 173; return; puts 174}; puts 175; iterator_via_call(&p); puts 176; rescue; puts 177; puts $!.class; end
$g = 0; def m_12; p = lambda{ puts 178; return; puts 179}; puts 180; iterator_via_call(&p); puts 181; end; 
begin; puts 182; m_12; puts 183; rescue; puts 184; puts $!.class; end
$g = 0; begin; p = lambda{ puts 185; return; puts 186}; puts 187; method_call_iterator_via_yield(&p); puts 188; rescue; puts 189; puts $!.class; end
$g = 0; def m_13; p = lambda{ puts 190; return; puts 191}; puts 192; method_call_iterator_via_yield(&p); puts 193; end; 
begin; puts 194; m_13; puts 195; rescue; puts 196; puts $!.class; end
$g = 0; begin; p = lambda{ puts 197; return; puts 198}; puts 199; method_call_iterator_via_call(&p); puts 200; rescue; puts 201; puts $!.class; end
$g = 0; def m_14; p = lambda{ puts 202; return; puts 203}; puts 204; method_call_iterator_via_call(&p); puts 205; end; 
begin; puts 206; m_14; puts 207; rescue; puts 208; puts $!.class; end
$g = 0; begin; p = lambda{ puts 209; return; puts 210}; puts 211; method_use_lambda_and_yield(&p); puts 212; rescue; puts 213; puts $!.class; end
$g = 0; def m_15; p = lambda{ puts 214; return; puts 215}; puts 216; method_use_lambda_and_yield(&p); puts 217; end; 
begin; puts 218; m_15; puts 219; rescue; puts 220; puts $!.class; end
$g = 0; begin; p = lambda{ puts 221; return; puts 222}; puts 223; method_use_proc_and_yield(&p); puts 224; rescue; puts 225; puts $!.class; end
$g = 0; def m_16; p = lambda{ puts 226; return; puts 227}; puts 228; method_use_proc_and_yield(&p); puts 229; end; 
begin; puts 230; m_16; puts 231; rescue; puts 232; puts $!.class; end
$g = 0; begin; p = lambda{ puts 233; return; puts 234}; puts 235; method_use_lambda_and_call(&p); puts 236; rescue; puts 237; puts $!.class; end
$g = 0; def m_17; p = lambda{ puts 238; return; puts 239}; puts 240; method_use_lambda_and_call(&p); puts 241; end; 
begin; puts 242; m_17; puts 243; rescue; puts 244; puts $!.class; end
$g = 0; begin; p = lambda{ puts 245; return; puts 246}; puts 247; method_use_proc_and_call(&p); puts 248; rescue; puts 249; puts $!.class; end
$g = 0; def m_18; p = lambda{ puts 250; return; puts 251}; puts 252; method_use_proc_and_call(&p); puts 253; end; 
begin; puts 254; m_18; puts 255; rescue; puts 256; puts $!.class; end
$g = 0; begin; p = lambda{ puts 257; return; puts 258}; puts 259; method_yield_in_loop(&p); puts 260; rescue; puts 261; puts $!.class; end
$g = 0; def m_19; p = lambda{ puts 262; return; puts 263}; puts 264; method_yield_in_loop(&p); puts 265; end; 
begin; puts 266; m_19; puts 267; rescue; puts 268; puts $!.class; end
$g = 0; begin; p = lambda{ puts 269; return; puts 270}; puts 271; method_call_in_loop(&p); puts 272; rescue; puts 273; puts $!.class; end
$g = 0; def m_20; p = lambda{ puts 274; return; puts 275}; puts 276; method_call_in_loop(&p); puts 277; end; 
begin; puts 278; m_20; puts 279; rescue; puts 280; puts $!.class; end

$g = 0; begin; p = Proc.new{ puts 281; return; puts 282}; puts 283; iterator_via_yield(&p); puts 284; rescue; puts 285; puts $!.class; end
$g = 0; def m_21; p = Proc.new{ puts 286; return; puts 287}; puts 288; iterator_via_yield(&p); puts 289; end; 
begin; puts 290; m_21; puts 291; rescue; puts 292; puts $!.class; end
$g = 0; begin; p = Proc.new{ puts 293; return; puts 294}; puts 295; iterator_via_call(&p); puts 296; rescue; puts 297; puts $!.class; end
$g = 0; def m_22; p = Proc.new{ puts 298; return; puts 299}; puts 300; iterator_via_call(&p); puts 301; end; 
begin; puts 302; m_22; puts 303; rescue; puts 304; puts $!.class; end
$g = 0; begin; p = Proc.new{ puts 305; return; puts 306}; puts 307; method_call_iterator_via_yield(&p); puts 308; rescue; puts 309; puts $!.class; end
$g = 0; def m_23; p = Proc.new{ puts 310; return; puts 311}; puts 312; method_call_iterator_via_yield(&p); puts 313; end; 
begin; puts 314; m_23; puts 315; rescue; puts 316; puts $!.class; end
$g = 0; begin; p = Proc.new{ puts 317; return; puts 318}; puts 319; method_call_iterator_via_call(&p); puts 320; rescue; puts 321; puts $!.class; end
$g = 0; def m_24; p = Proc.new{ puts 322; return; puts 323}; puts 324; method_call_iterator_via_call(&p); puts 325; end; 
begin; puts 326; m_24; puts 327; rescue; puts 328; puts $!.class; end
$g = 0; begin; p = Proc.new{ puts 329; return; puts 330}; puts 331; method_use_lambda_and_yield(&p); puts 332; rescue; puts 333; puts $!.class; end
$g = 0; def m_25; p = Proc.new{ puts 334; return; puts 335}; puts 336; method_use_lambda_and_yield(&p); puts 337; end; 
begin; puts 338; m_25; puts 339; rescue; puts 340; puts $!.class; end
$g = 0; begin; p = Proc.new{ puts 341; return; puts 342}; puts 343; method_use_proc_and_yield(&p); puts 344; rescue; puts 345; puts $!.class; end
$g = 0; def m_26; p = Proc.new{ puts 346; return; puts 347}; puts 348; method_use_proc_and_yield(&p); puts 349; end; 
begin; puts 350; m_26; puts 351; rescue; puts 352; puts $!.class; end
$g = 0; begin; p = Proc.new{ puts 353; return; puts 354}; puts 355; method_use_lambda_and_call(&p); puts 356; rescue; puts 357; puts $!.class; end
$g = 0; def m_27; p = Proc.new{ puts 358; return; puts 359}; puts 360; method_use_lambda_and_call(&p); puts 361; end; 
begin; puts 362; m_27; puts 363; rescue; puts 364; puts $!.class; end
$g = 0; begin; p = Proc.new{ puts 365; return; puts 366}; puts 367; method_use_proc_and_call(&p); puts 368; rescue; puts 369; puts $!.class; end
$g = 0; def m_28; p = Proc.new{ puts 370; return; puts 371}; puts 372; method_use_proc_and_call(&p); puts 373; end; 
begin; puts 374; m_28; puts 375; rescue; puts 376; puts $!.class; end
$g = 0; begin; p = Proc.new{ puts 377; return; puts 378}; puts 379; method_yield_in_loop(&p); puts 380; rescue; puts 381; puts $!.class; end
$g = 0; def m_29; p = Proc.new{ puts 382; return; puts 383}; puts 384; method_yield_in_loop(&p); puts 385; end; 
begin; puts 386; m_29; puts 387; rescue; puts 388; puts $!.class; end
$g = 0; begin; p = Proc.new{ puts 389; return; puts 390}; puts 391; method_call_in_loop(&p); puts 392; rescue; puts 393; puts $!.class; end
$g = 0; def m_30; p = Proc.new{ puts 394; return; puts 395}; puts 396; method_call_in_loop(&p); puts 397; end; 
begin; puts 398; m_30; puts 399; rescue; puts 400; puts $!.class; end

$g = 0; begin; p = get_block{ puts 401; return; puts 402}; puts 403; iterator_via_yield(&p); puts 404; rescue; puts 405; puts $!.class; end
$g = 0; def m_31; p = get_block{ puts 406; return; puts 407}; puts 408; iterator_via_yield(&p); puts 409; end; 
begin; puts 410; m_31; puts 411; rescue; puts 412; puts $!.class; end
$g = 0; begin; p = get_block{ puts 413; return; puts 414}; puts 415; iterator_via_call(&p); puts 416; rescue; puts 417; puts $!.class; end
$g = 0; def m_32; p = get_block{ puts 418; return; puts 419}; puts 420; iterator_via_call(&p); puts 421; end; 
begin; puts 422; m_32; puts 423; rescue; puts 424; puts $!.class; end
$g = 0; begin; p = get_block{ puts 425; return; puts 426}; puts 427; method_call_iterator_via_yield(&p); puts 428; rescue; puts 429; puts $!.class; end
$g = 0; def m_33; p = get_block{ puts 430; return; puts 431}; puts 432; method_call_iterator_via_yield(&p); puts 433; end; 
begin; puts 434; m_33; puts 435; rescue; puts 436; puts $!.class; end
$g = 0; begin; p = get_block{ puts 437; return; puts 438}; puts 439; method_call_iterator_via_call(&p); puts 440; rescue; puts 441; puts $!.class; end
$g = 0; def m_34; p = get_block{ puts 442; return; puts 443}; puts 444; method_call_iterator_via_call(&p); puts 445; end; 
begin; puts 446; m_34; puts 447; rescue; puts 448; puts $!.class; end
$g = 0; begin; p = get_block{ puts 449; return; puts 450}; puts 451; method_use_lambda_and_yield(&p); puts 452; rescue; puts 453; puts $!.class; end
$g = 0; def m_35; p = get_block{ puts 454; return; puts 455}; puts 456; method_use_lambda_and_yield(&p); puts 457; end; 
begin; puts 458; m_35; puts 459; rescue; puts 460; puts $!.class; end
$g = 0; begin; p = get_block{ puts 461; return; puts 462}; puts 463; method_use_proc_and_yield(&p); puts 464; rescue; puts 465; puts $!.class; end
$g = 0; def m_36; p = get_block{ puts 466; return; puts 467}; puts 468; method_use_proc_and_yield(&p); puts 469; end; 
begin; puts 470; m_36; puts 471; rescue; puts 472; puts $!.class; end
$g = 0; begin; p = get_block{ puts 473; return; puts 474}; puts 475; method_use_lambda_and_call(&p); puts 476; rescue; puts 477; puts $!.class; end
$g = 0; def m_37; p = get_block{ puts 478; return; puts 479}; puts 480; method_use_lambda_and_call(&p); puts 481; end; 
begin; puts 482; m_37; puts 483; rescue; puts 484; puts $!.class; end
$g = 0; begin; p = get_block{ puts 485; return; puts 486}; puts 487; method_use_proc_and_call(&p); puts 488; rescue; puts 489; puts $!.class; end
$g = 0; def m_38; p = get_block{ puts 490; return; puts 491}; puts 492; method_use_proc_and_call(&p); puts 493; end; 
begin; puts 494; m_38; puts 495; rescue; puts 496; puts $!.class; end
$g = 0; begin; p = get_block{ puts 497; return; puts 498}; puts 499; method_yield_in_loop(&p); puts 500; rescue; puts 501; puts $!.class; end
$g = 0; def m_39; p = get_block{ puts 502; return; puts 503}; puts 504; method_yield_in_loop(&p); puts 505; end; 
begin; puts 506; m_39; puts 507; rescue; puts 508; puts $!.class; end
$g = 0; begin; p = get_block{ puts 509; return; puts 510}; puts 511; method_call_in_loop(&p); puts 512; rescue; puts 513; puts $!.class; end
$g = 0; def m_40; p = get_block{ puts 514; return; puts 515}; puts 516; method_call_in_loop(&p); puts 517; end; 
begin; puts 518; m_40; puts 519; rescue; puts 520; puts $!.class; end

$g = 0; begin; p = get_lambda{ puts 521; return; puts 522}; puts 523; iterator_via_yield(&p); puts 524; rescue; puts 525; puts $!.class; end
$g = 0; def m_41; p = get_lambda{ puts 526; return; puts 527}; puts 528; iterator_via_yield(&p); puts 529; end; 
begin; puts 530; m_41; puts 531; rescue; puts 532; puts $!.class; end
$g = 0; begin; p = get_lambda{ puts 533; return; puts 534}; puts 535; iterator_via_call(&p); puts 536; rescue; puts 537; puts $!.class; end
$g = 0; def m_42; p = get_lambda{ puts 538; return; puts 539}; puts 540; iterator_via_call(&p); puts 541; end; 
begin; puts 542; m_42; puts 543; rescue; puts 544; puts $!.class; end
$g = 0; begin; p = get_lambda{ puts 545; return; puts 546}; puts 547; method_call_iterator_via_yield(&p); puts 548; rescue; puts 549; puts $!.class; end
$g = 0; def m_43; p = get_lambda{ puts 550; return; puts 551}; puts 552; method_call_iterator_via_yield(&p); puts 553; end; 
begin; puts 554; m_43; puts 555; rescue; puts 556; puts $!.class; end
$g = 0; begin; p = get_lambda{ puts 557; return; puts 558}; puts 559; method_call_iterator_via_call(&p); puts 560; rescue; puts 561; puts $!.class; end
$g = 0; def m_44; p = get_lambda{ puts 562; return; puts 563}; puts 564; method_call_iterator_via_call(&p); puts 565; end; 
begin; puts 566; m_44; puts 567; rescue; puts 568; puts $!.class; end
$g = 0; begin; p = get_lambda{ puts 569; return; puts 570}; puts 571; method_use_lambda_and_yield(&p); puts 572; rescue; puts 573; puts $!.class; end
$g = 0; def m_45; p = get_lambda{ puts 574; return; puts 575}; puts 576; method_use_lambda_and_yield(&p); puts 577; end; 
begin; puts 578; m_45; puts 579; rescue; puts 580; puts $!.class; end
$g = 0; begin; p = get_lambda{ puts 581; return; puts 582}; puts 583; method_use_proc_and_yield(&p); puts 584; rescue; puts 585; puts $!.class; end
$g = 0; def m_46; p = get_lambda{ puts 586; return; puts 587}; puts 588; method_use_proc_and_yield(&p); puts 589; end; 
begin; puts 590; m_46; puts 591; rescue; puts 592; puts $!.class; end
$g = 0; begin; p = get_lambda{ puts 593; return; puts 594}; puts 595; method_use_lambda_and_call(&p); puts 596; rescue; puts 597; puts $!.class; end
$g = 0; def m_47; p = get_lambda{ puts 598; return; puts 599}; puts 600; method_use_lambda_and_call(&p); puts 601; end; 
begin; puts 602; m_47; puts 603; rescue; puts 604; puts $!.class; end
$g = 0; begin; p = get_lambda{ puts 605; return; puts 606}; puts 607; method_use_proc_and_call(&p); puts 608; rescue; puts 609; puts $!.class; end
$g = 0; def m_48; p = get_lambda{ puts 610; return; puts 611}; puts 612; method_use_proc_and_call(&p); puts 613; end; 
begin; puts 614; m_48; puts 615; rescue; puts 616; puts $!.class; end
$g = 0; begin; p = get_lambda{ puts 617; return; puts 618}; puts 619; method_yield_in_loop(&p); puts 620; rescue; puts 621; puts $!.class; end
$g = 0; def m_49; p = get_lambda{ puts 622; return; puts 623}; puts 624; method_yield_in_loop(&p); puts 625; end; 
begin; puts 626; m_49; puts 627; rescue; puts 628; puts $!.class; end
$g = 0; begin; p = get_lambda{ puts 629; return; puts 630}; puts 631; method_call_in_loop(&p); puts 632; rescue; puts 633; puts $!.class; end
$g = 0; def m_50; p = get_lambda{ puts 634; return; puts 635}; puts 636; method_call_in_loop(&p); puts 637; end; 
begin; puts 638; m_50; puts 639; rescue; puts 640; puts $!.class; end

$g = 0; begin; p = get_proc{ puts 641; return; puts 642}; puts 643; iterator_via_yield(&p); puts 644; rescue; puts 645; puts $!.class; end
$g = 0; def m_51; p = get_proc{ puts 646; return; puts 647}; puts 648; iterator_via_yield(&p); puts 649; end; 
begin; puts 650; m_51; puts 651; rescue; puts 652; puts $!.class; end
$g = 0; begin; p = get_proc{ puts 653; return; puts 654}; puts 655; iterator_via_call(&p); puts 656; rescue; puts 657; puts $!.class; end
$g = 0; def m_52; p = get_proc{ puts 658; return; puts 659}; puts 660; iterator_via_call(&p); puts 661; end; 
begin; puts 662; m_52; puts 663; rescue; puts 664; puts $!.class; end
$g = 0; begin; p = get_proc{ puts 665; return; puts 666}; puts 667; method_call_iterator_via_yield(&p); puts 668; rescue; puts 669; puts $!.class; end
$g = 0; def m_53; p = get_proc{ puts 670; return; puts 671}; puts 672; method_call_iterator_via_yield(&p); puts 673; end; 
begin; puts 674; m_53; puts 675; rescue; puts 676; puts $!.class; end
$g = 0; begin; p = get_proc{ puts 677; return; puts 678}; puts 679; method_call_iterator_via_call(&p); puts 680; rescue; puts 681; puts $!.class; end
$g = 0; def m_54; p = get_proc{ puts 682; return; puts 683}; puts 684; method_call_iterator_via_call(&p); puts 685; end; 
begin; puts 686; m_54; puts 687; rescue; puts 688; puts $!.class; end
$g = 0; begin; p = get_proc{ puts 689; return; puts 690}; puts 691; method_use_lambda_and_yield(&p); puts 692; rescue; puts 693; puts $!.class; end
$g = 0; def m_55; p = get_proc{ puts 694; return; puts 695}; puts 696; method_use_lambda_and_yield(&p); puts 697; end; 
begin; puts 698; m_55; puts 699; rescue; puts 700; puts $!.class; end
$g = 0; begin; p = get_proc{ puts 701; return; puts 702}; puts 703; method_use_proc_and_yield(&p); puts 704; rescue; puts 705; puts $!.class; end
$g = 0; def m_56; p = get_proc{ puts 706; return; puts 707}; puts 708; method_use_proc_and_yield(&p); puts 709; end; 
begin; puts 710; m_56; puts 711; rescue; puts 712; puts $!.class; end
$g = 0; begin; p = get_proc{ puts 713; return; puts 714}; puts 715; method_use_lambda_and_call(&p); puts 716; rescue; puts 717; puts $!.class; end
$g = 0; def m_57; p = get_proc{ puts 718; return; puts 719}; puts 720; method_use_lambda_and_call(&p); puts 721; end; 
begin; puts 722; m_57; puts 723; rescue; puts 724; puts $!.class; end
$g = 0; begin; p = get_proc{ puts 725; return; puts 726}; puts 727; method_use_proc_and_call(&p); puts 728; rescue; puts 729; puts $!.class; end
$g = 0; def m_58; p = get_proc{ puts 730; return; puts 731}; puts 732; method_use_proc_and_call(&p); puts 733; end; 
begin; puts 734; m_58; puts 735; rescue; puts 736; puts $!.class; end
$g = 0; begin; p = get_proc{ puts 737; return; puts 738}; puts 739; method_yield_in_loop(&p); puts 740; rescue; puts 741; puts $!.class; end
$g = 0; def m_59; p = get_proc{ puts 742; return; puts 743}; puts 744; method_yield_in_loop(&p); puts 745; end; 
begin; puts 746; m_59; puts 747; rescue; puts 748; puts $!.class; end
$g = 0; begin; p = get_proc{ puts 749; return; puts 750}; puts 751; method_call_in_loop(&p); puts 752; rescue; puts 753; puts $!.class; end
$g = 0; def m_60; p = get_proc{ puts 754; return; puts 755}; puts 756; method_call_in_loop(&p); puts 757; end; 
begin; puts 758; m_60; puts 759; rescue; puts 760; puts $!.class; end

$g = 0; begin; p = get_local_block; puts 761; iterator_via_yield(&p); puts 762; rescue; puts 763; puts $!.class; end
$g = 0; def m_61; p = get_local_block; puts 764; iterator_via_yield(&p); puts 765; end; 
begin; puts 766; m_61; puts 767; rescue; puts 768; puts $!.class; end
$g = 0; begin; p = get_local_block; puts 769; iterator_via_call(&p); puts 770; rescue; puts 771; puts $!.class; end
$g = 0; def m_62; p = get_local_block; puts 772; iterator_via_call(&p); puts 773; end; 
begin; puts 774; m_62; puts 775; rescue; puts 776; puts $!.class; end
$g = 0; begin; p = get_local_block; puts 777; method_call_iterator_via_yield(&p); puts 778; rescue; puts 779; puts $!.class; end
$g = 0; def m_63; p = get_local_block; puts 780; method_call_iterator_via_yield(&p); puts 781; end; 
begin; puts 782; m_63; puts 783; rescue; puts 784; puts $!.class; end
$g = 0; begin; p = get_local_block; puts 785; method_call_iterator_via_call(&p); puts 786; rescue; puts 787; puts $!.class; end
$g = 0; def m_64; p = get_local_block; puts 788; method_call_iterator_via_call(&p); puts 789; end; 
begin; puts 790; m_64; puts 791; rescue; puts 792; puts $!.class; end
$g = 0; begin; p = get_local_block; puts 793; method_use_lambda_and_yield(&p); puts 794; rescue; puts 795; puts $!.class; end
$g = 0; def m_65; p = get_local_block; puts 796; method_use_lambda_and_yield(&p); puts 797; end; 
begin; puts 798; m_65; puts 799; rescue; puts 800; puts $!.class; end
$g = 0; begin; p = get_local_block; puts 801; method_use_proc_and_yield(&p); puts 802; rescue; puts 803; puts $!.class; end
$g = 0; def m_66; p = get_local_block; puts 804; method_use_proc_and_yield(&p); puts 805; end; 
begin; puts 806; m_66; puts 807; rescue; puts 808; puts $!.class; end
$g = 0; begin; p = get_local_block; puts 809; method_use_lambda_and_call(&p); puts 810; rescue; puts 811; puts $!.class; end
$g = 0; def m_67; p = get_local_block; puts 812; method_use_lambda_and_call(&p); puts 813; end; 
begin; puts 814; m_67; puts 815; rescue; puts 816; puts $!.class; end
$g = 0; begin; p = get_local_block; puts 817; method_use_proc_and_call(&p); puts 818; rescue; puts 819; puts $!.class; end
$g = 0; def m_68; p = get_local_block; puts 820; method_use_proc_and_call(&p); puts 821; end; 
begin; puts 822; m_68; puts 823; rescue; puts 824; puts $!.class; end
$g = 0; begin; p = get_local_block; puts 825; method_yield_in_loop(&p); puts 826; rescue; puts 827; puts $!.class; end
$g = 0; def m_69; p = get_local_block; puts 828; method_yield_in_loop(&p); puts 829; end; 
begin; puts 830; m_69; puts 831; rescue; puts 832; puts $!.class; end
$g = 0; begin; p = get_local_block; puts 833; method_call_in_loop(&p); puts 834; rescue; puts 835; puts $!.class; end
$g = 0; def m_70; p = get_local_block; puts 836; method_call_in_loop(&p); puts 837; end; 
begin; puts 838; m_70; puts 839; rescue; puts 840; puts $!.class; end

$g = 0; begin; p = get_local_lambda; puts 841; iterator_via_yield(&p); puts 842; rescue; puts 843; puts $!.class; end
$g = 0; def m_71; p = get_local_lambda; puts 844; iterator_via_yield(&p); puts 845; end; 
begin; puts 846; m_71; puts 847; rescue; puts 848; puts $!.class; end
$g = 0; begin; p = get_local_lambda; puts 849; iterator_via_call(&p); puts 850; rescue; puts 851; puts $!.class; end
$g = 0; def m_72; p = get_local_lambda; puts 852; iterator_via_call(&p); puts 853; end; 
begin; puts 854; m_72; puts 855; rescue; puts 856; puts $!.class; end
$g = 0; begin; p = get_local_lambda; puts 857; method_call_iterator_via_yield(&p); puts 858; rescue; puts 859; puts $!.class; end
$g = 0; def m_73; p = get_local_lambda; puts 860; method_call_iterator_via_yield(&p); puts 861; end; 
begin; puts 862; m_73; puts 863; rescue; puts 864; puts $!.class; end
$g = 0; begin; p = get_local_lambda; puts 865; method_call_iterator_via_call(&p); puts 866; rescue; puts 867; puts $!.class; end
$g = 0; def m_74; p = get_local_lambda; puts 868; method_call_iterator_via_call(&p); puts 869; end; 
begin; puts 870; m_74; puts 871; rescue; puts 872; puts $!.class; end
$g = 0; begin; p = get_local_lambda; puts 873; method_use_lambda_and_yield(&p); puts 874; rescue; puts 875; puts $!.class; end
$g = 0; def m_75; p = get_local_lambda; puts 876; method_use_lambda_and_yield(&p); puts 877; end; 
begin; puts 878; m_75; puts 879; rescue; puts 880; puts $!.class; end
$g = 0; begin; p = get_local_lambda; puts 881; method_use_proc_and_yield(&p); puts 882; rescue; puts 883; puts $!.class; end
$g = 0; def m_76; p = get_local_lambda; puts 884; method_use_proc_and_yield(&p); puts 885; end; 
begin; puts 886; m_76; puts 887; rescue; puts 888; puts $!.class; end
$g = 0; begin; p = get_local_lambda; puts 889; method_use_lambda_and_call(&p); puts 890; rescue; puts 891; puts $!.class; end
$g = 0; def m_77; p = get_local_lambda; puts 892; method_use_lambda_and_call(&p); puts 893; end; 
begin; puts 894; m_77; puts 895; rescue; puts 896; puts $!.class; end
$g = 0; begin; p = get_local_lambda; puts 897; method_use_proc_and_call(&p); puts 898; rescue; puts 899; puts $!.class; end
$g = 0; def m_78; p = get_local_lambda; puts 900; method_use_proc_and_call(&p); puts 901; end; 
begin; puts 902; m_78; puts 903; rescue; puts 904; puts $!.class; end
$g = 0; begin; p = get_local_lambda; puts 905; method_yield_in_loop(&p); puts 906; rescue; puts 907; puts $!.class; end
$g = 0; def m_79; p = get_local_lambda; puts 908; method_yield_in_loop(&p); puts 909; end; 
begin; puts 910; m_79; puts 911; rescue; puts 912; puts $!.class; end
$g = 0; begin; p = get_local_lambda; puts 913; method_call_in_loop(&p); puts 914; rescue; puts 915; puts $!.class; end
$g = 0; def m_80; p = get_local_lambda; puts 916; method_call_in_loop(&p); puts 917; end; 
begin; puts 918; m_80; puts 919; rescue; puts 920; puts $!.class; end

$g = 0; begin; p = get_local_proc; puts 921; iterator_via_yield(&p); puts 922; rescue; puts 923; puts $!.class; end
$g = 0; def m_81; p = get_local_proc; puts 924; iterator_via_yield(&p); puts 925; end; 
begin; puts 926; m_81; puts 927; rescue; puts 928; puts $!.class; end
$g = 0; begin; p = get_local_proc; puts 929; iterator_via_call(&p); puts 930; rescue; puts 931; puts $!.class; end
$g = 0; def m_82; p = get_local_proc; puts 932; iterator_via_call(&p); puts 933; end; 
begin; puts 934; m_82; puts 935; rescue; puts 936; puts $!.class; end
$g = 0; begin; p = get_local_proc; puts 937; method_call_iterator_via_yield(&p); puts 938; rescue; puts 939; puts $!.class; end
$g = 0; def m_83; p = get_local_proc; puts 940; method_call_iterator_via_yield(&p); puts 941; end; 
begin; puts 942; m_83; puts 943; rescue; puts 944; puts $!.class; end
$g = 0; begin; p = get_local_proc; puts 945; method_call_iterator_via_call(&p); puts 946; rescue; puts 947; puts $!.class; end
$g = 0; def m_84; p = get_local_proc; puts 948; method_call_iterator_via_call(&p); puts 949; end; 
begin; puts 950; m_84; puts 951; rescue; puts 952; puts $!.class; end
$g = 0; begin; p = get_local_proc; puts 953; method_use_lambda_and_yield(&p); puts 954; rescue; puts 955; puts $!.class; end
$g = 0; def m_85; p = get_local_proc; puts 956; method_use_lambda_and_yield(&p); puts 957; end; 
begin; puts 958; m_85; puts 959; rescue; puts 960; puts $!.class; end
$g = 0; begin; p = get_local_proc; puts 961; method_use_proc_and_yield(&p); puts 962; rescue; puts 963; puts $!.class; end
$g = 0; def m_86; p = get_local_proc; puts 964; method_use_proc_and_yield(&p); puts 965; end; 
begin; puts 966; m_86; puts 967; rescue; puts 968; puts $!.class; end
$g = 0; begin; p = get_local_proc; puts 969; method_use_lambda_and_call(&p); puts 970; rescue; puts 971; puts $!.class; end
$g = 0; def m_87; p = get_local_proc; puts 972; method_use_lambda_and_call(&p); puts 973; end; 
begin; puts 974; m_87; puts 975; rescue; puts 976; puts $!.class; end
$g = 0; begin; p = get_local_proc; puts 977; method_use_proc_and_call(&p); puts 978; rescue; puts 979; puts $!.class; end
$g = 0; def m_88; p = get_local_proc; puts 980; method_use_proc_and_call(&p); puts 981; end; 
begin; puts 982; m_88; puts 983; rescue; puts 984; puts $!.class; end
$g = 0; begin; p = get_local_proc; puts 985; method_yield_in_loop(&p); puts 986; rescue; puts 987; puts $!.class; end
$g = 0; def m_89; p = get_local_proc; puts 988; method_yield_in_loop(&p); puts 989; end; 
begin; puts 990; m_89; puts 991; rescue; puts 992; puts $!.class; end
$g = 0; begin; p = get_local_proc; puts 993; method_call_in_loop(&p); puts 994; rescue; puts 995; puts $!.class; end
$g = 0; def m_90; p = get_local_proc; puts 996; method_call_in_loop(&p); puts 997; end; 
begin; puts 998; m_90; puts 999; rescue; puts 1000; puts $!.class; end


$g = 0; begin; puts 1001; p = lambda{ puts 1002; return; puts 1003}; puts(p.call); puts 1004; rescue; puts 1005; puts $!.class; end
$g = 0; def m_91; puts 1006; p = lambda{ puts 1007; return; puts 1008}; puts(p.call); puts 1009; end; 
begin; puts 1010; m_91; puts 1011; rescue; puts 1012; puts $!.class; end
$g = 0; begin; puts 1013; puts m_91; puts 1014; rescue; puts 1015; puts $!.class; end
$g = 0; def m_92; puts 1016; puts m_91; puts 1017; end; 
begin; puts 1018; m_92; puts 1019; rescue; puts 1020; puts $!.class; end
$g = 0; begin; puts 1021; p = Proc.new{ puts 1022; return; puts 1023}; puts(p.call); puts 1024; rescue; puts 1025; puts $!.class; end
$g = 0; def m_93; puts 1026; p = Proc.new{ puts 1027; return; puts 1028}; puts(p.call); puts 1029; end; 
begin; puts 1030; m_93; puts 1031; rescue; puts 1032; puts $!.class; end
$g = 0; begin; puts 1033; puts m_93; puts 1034; rescue; puts 1035; puts $!.class; end
$g = 0; def m_94; puts 1036; puts m_93; puts 1037; end; 
begin; puts 1038; m_94; puts 1039; rescue; puts 1040; puts $!.class; end
$g = 0; begin; puts 1041; p = get_block{ puts 1042; return; puts 1043}; puts(p.call); puts 1044; rescue; puts 1045; puts $!.class; end
$g = 0; def m_95; puts 1046; p = get_block{ puts 1047; return; puts 1048}; puts(p.call); puts 1049; end; 
begin; puts 1050; m_95; puts 1051; rescue; puts 1052; puts $!.class; end
$g = 0; begin; puts 1053; puts m_95; puts 1054; rescue; puts 1055; puts $!.class; end
$g = 0; def m_96; puts 1056; puts m_95; puts 1057; end; 
begin; puts 1058; m_96; puts 1059; rescue; puts 1060; puts $!.class; end
$g = 0; begin; puts 1061; p = get_lambda{ puts 1062; return; puts 1063}; puts(p.call); puts 1064; rescue; puts 1065; puts $!.class; end
$g = 0; def m_97; puts 1066; p = get_lambda{ puts 1067; return; puts 1068}; puts(p.call); puts 1069; end; 
begin; puts 1070; m_97; puts 1071; rescue; puts 1072; puts $!.class; end
$g = 0; begin; puts 1073; puts m_97; puts 1074; rescue; puts 1075; puts $!.class; end
$g = 0; def m_98; puts 1076; puts m_97; puts 1077; end; 
begin; puts 1078; m_98; puts 1079; rescue; puts 1080; puts $!.class; end
$g = 0; begin; puts 1081; p = get_proc{ puts 1082; return; puts 1083}; puts(p.call); puts 1084; rescue; puts 1085; puts $!.class; end
$g = 0; def m_99; puts 1086; p = get_proc{ puts 1087; return; puts 1088}; puts(p.call); puts 1089; end; 
begin; puts 1090; m_99; puts 1091; rescue; puts 1092; puts $!.class; end
$g = 0; begin; puts 1093; puts m_99; puts 1094; rescue; puts 1095; puts $!.class; end
$g = 0; def m_100; puts 1096; puts m_99; puts 1097; end; 
begin; puts 1098; m_100; puts 1099; rescue; puts 1100; puts $!.class; end
$g = 0; begin; puts 1101; p = get_local_block; puts(p.call); puts 1102; rescue; puts 1103; puts $!.class; end
$g = 0; def m_101; puts 1104; p = get_local_block; puts(p.call); puts 1105; end; 
begin; puts 1106; m_101; puts 1107; rescue; puts 1108; puts $!.class; end
$g = 0; begin; puts 1109; puts m_101; puts 1110; rescue; puts 1111; puts $!.class; end
$g = 0; def m_102; puts 1112; puts m_101; puts 1113; end; 
begin; puts 1114; m_102; puts 1115; rescue; puts 1116; puts $!.class; end
$g = 0; begin; puts 1117; p = get_local_lambda; puts(p.call); puts 1118; rescue; puts 1119; puts $!.class; end
$g = 0; def m_103; puts 1120; p = get_local_lambda; puts(p.call); puts 1121; end; 
begin; puts 1122; m_103; puts 1123; rescue; puts 1124; puts $!.class; end
$g = 0; begin; puts 1125; puts m_103; puts 1126; rescue; puts 1127; puts $!.class; end
$g = 0; def m_104; puts 1128; puts m_103; puts 1129; end; 
begin; puts 1130; m_104; puts 1131; rescue; puts 1132; puts $!.class; end
$g = 0; begin; puts 1133; p = get_local_proc; puts(p.call); puts 1134; rescue; puts 1135; puts $!.class; end
$g = 0; def m_105; puts 1136; p = get_local_proc; puts(p.call); puts 1137; end; 
begin; puts 1138; m_105; puts 1139; rescue; puts 1140; puts $!.class; end
$g = 0; begin; puts 1141; puts m_105; puts 1142; rescue; puts 1143; puts $!.class; end
$g = 0; def m_106; puts 1144; puts m_105; puts 1145; end; 
begin; puts 1146; m_106; puts 1147; rescue; puts 1148; puts $!.class; end
$g = 0; begin; puts 1149; x = lambda { puts 1150; p = lambda{ puts 1151; return; puts 1152}; puts p.call; puts 1153}; puts x.call; puts 1154; rescue; puts 1155; puts $!.class; end
$g = 0; def m_107; puts 1156; x = lambda { puts 1157; p = lambda{ puts 1158; return; puts 1159}; puts p.call; puts 1160}; puts x.call; puts 1161; end; 
begin; puts 1162; m_107; puts 1163; rescue; puts 1164; puts $!.class; end
$g = 0; begin; puts 1165; x = lambda { puts 1166; p = Proc.new{ puts 1167; return; puts 1168}; puts p.call; puts 1169}; puts x.call; puts 1170; rescue; puts 1171; puts $!.class; end
$g = 0; def m_108; puts 1172; x = lambda { puts 1173; p = Proc.new{ puts 1174; return; puts 1175}; puts p.call; puts 1176}; puts x.call; puts 1177; end; 
begin; puts 1178; m_108; puts 1179; rescue; puts 1180; puts $!.class; end
$g = 0; begin; puts 1181; x = lambda { puts 1182; p = get_block{ puts 1183; return; puts 1184}; puts p.call; puts 1185}; puts x.call; puts 1186; rescue; puts 1187; puts $!.class; end
$g = 0; def m_109; puts 1188; x = lambda { puts 1189; p = get_block{ puts 1190; return; puts 1191}; puts p.call; puts 1192}; puts x.call; puts 1193; end; 
begin; puts 1194; m_109; puts 1195; rescue; puts 1196; puts $!.class; end
$g = 0; begin; puts 1197; x = lambda { puts 1198; p = get_lambda{ puts 1199; return; puts 1200}; puts p.call; puts 1201}; puts x.call; puts 1202; rescue; puts 1203; puts $!.class; end
$g = 0; def m_110; puts 1204; x = lambda { puts 1205; p = get_lambda{ puts 1206; return; puts 1207}; puts p.call; puts 1208}; puts x.call; puts 1209; end; 
begin; puts 1210; m_110; puts 1211; rescue; puts 1212; puts $!.class; end
$g = 0; begin; puts 1213; x = lambda { puts 1214; p = get_proc{ puts 1215; return; puts 1216}; puts p.call; puts 1217}; puts x.call; puts 1218; rescue; puts 1219; puts $!.class; end
$g = 0; def m_111; puts 1220; x = lambda { puts 1221; p = get_proc{ puts 1222; return; puts 1223}; puts p.call; puts 1224}; puts x.call; puts 1225; end; 
begin; puts 1226; m_111; puts 1227; rescue; puts 1228; puts $!.class; end
$g = 0; begin; puts 1229; x = lambda { puts 1230; p = get_local_block; puts p.call; puts 1231}; puts x.call; puts 1232; rescue; puts 1233; puts $!.class; end
$g = 0; def m_112; puts 1234; x = lambda { puts 1235; p = get_local_block; puts p.call; puts 1236}; puts x.call; puts 1237; end; 
begin; puts 1238; m_112; puts 1239; rescue; puts 1240; puts $!.class; end
$g = 0; begin; puts 1241; x = lambda { puts 1242; p = get_local_lambda; puts p.call; puts 1243}; puts x.call; puts 1244; rescue; puts 1245; puts $!.class; end
$g = 0; def m_113; puts 1246; x = lambda { puts 1247; p = get_local_lambda; puts p.call; puts 1248}; puts x.call; puts 1249; end; 
begin; puts 1250; m_113; puts 1251; rescue; puts 1252; puts $!.class; end
$g = 0; begin; puts 1253; x = lambda { puts 1254; p = get_local_proc; puts p.call; puts 1255}; puts x.call; puts 1256; rescue; puts 1257; puts $!.class; end
$g = 0; def m_114; puts 1258; x = lambda { puts 1259; p = get_local_proc; puts p.call; puts 1260}; puts x.call; puts 1261; end; 
begin; puts 1262; m_114; puts 1263; rescue; puts 1264; puts $!.class; end

$g = 0; begin; puts 1265; x = Proc.new { puts 1266; p = lambda{ puts 1267; return; puts 1268}; puts p.call; puts 1269}; puts x.call; puts 1270; rescue; puts 1271; puts $!.class; end
$g = 0; def m_115; puts 1272; x = Proc.new { puts 1273; p = lambda{ puts 1274; return; puts 1275}; puts p.call; puts 1276}; puts x.call; puts 1277; end; 
begin; puts 1278; m_115; puts 1279; rescue; puts 1280; puts $!.class; end
$g = 0; begin; puts 1281; x = Proc.new { puts 1282; p = Proc.new{ puts 1283; return; puts 1284}; puts p.call; puts 1285}; puts x.call; puts 1286; rescue; puts 1287; puts $!.class; end
$g = 0; def m_116; puts 1288; x = Proc.new { puts 1289; p = Proc.new{ puts 1290; return; puts 1291}; puts p.call; puts 1292}; puts x.call; puts 1293; end; 
begin; puts 1294; m_116; puts 1295; rescue; puts 1296; puts $!.class; end
$g = 0; begin; puts 1297; x = Proc.new { puts 1298; p = get_block{ puts 1299; return; puts 1300}; puts p.call; puts 1301}; puts x.call; puts 1302; rescue; puts 1303; puts $!.class; end
$g = 0; def m_117; puts 1304; x = Proc.new { puts 1305; p = get_block{ puts 1306; return; puts 1307}; puts p.call; puts 1308}; puts x.call; puts 1309; end; 
begin; puts 1310; m_117; puts 1311; rescue; puts 1312; puts $!.class; end
$g = 0; begin; puts 1313; x = Proc.new { puts 1314; p = get_lambda{ puts 1315; return; puts 1316}; puts p.call; puts 1317}; puts x.call; puts 1318; rescue; puts 1319; puts $!.class; end
$g = 0; def m_118; puts 1320; x = Proc.new { puts 1321; p = get_lambda{ puts 1322; return; puts 1323}; puts p.call; puts 1324}; puts x.call; puts 1325; end; 
begin; puts 1326; m_118; puts 1327; rescue; puts 1328; puts $!.class; end
$g = 0; begin; puts 1329; x = Proc.new { puts 1330; p = get_proc{ puts 1331; return; puts 1332}; puts p.call; puts 1333}; puts x.call; puts 1334; rescue; puts 1335; puts $!.class; end
$g = 0; def m_119; puts 1336; x = Proc.new { puts 1337; p = get_proc{ puts 1338; return; puts 1339}; puts p.call; puts 1340}; puts x.call; puts 1341; end; 
begin; puts 1342; m_119; puts 1343; rescue; puts 1344; puts $!.class; end
$g = 0; begin; puts 1345; x = Proc.new { puts 1346; p = get_local_block; puts p.call; puts 1347}; puts x.call; puts 1348; rescue; puts 1349; puts $!.class; end
$g = 0; def m_120; puts 1350; x = Proc.new { puts 1351; p = get_local_block; puts p.call; puts 1352}; puts x.call; puts 1353; end; 
begin; puts 1354; m_120; puts 1355; rescue; puts 1356; puts $!.class; end
$g = 0; begin; puts 1357; x = Proc.new { puts 1358; p = get_local_lambda; puts p.call; puts 1359}; puts x.call; puts 1360; rescue; puts 1361; puts $!.class; end
$g = 0; def m_121; puts 1362; x = Proc.new { puts 1363; p = get_local_lambda; puts p.call; puts 1364}; puts x.call; puts 1365; end; 
begin; puts 1366; m_121; puts 1367; rescue; puts 1368; puts $!.class; end
$g = 0; begin; puts 1369; x = Proc.new { puts 1370; p = get_local_proc; puts p.call; puts 1371}; puts x.call; puts 1372; rescue; puts 1373; puts $!.class; end
$g = 0; def m_122; puts 1374; x = Proc.new { puts 1375; p = get_local_proc; puts p.call; puts 1376}; puts x.call; puts 1377; end; 
begin; puts 1378; m_122; puts 1379; rescue; puts 1380; puts $!.class; end

$g = 0; begin; puts 1381; x = get_block { puts 1382; p = lambda{ puts 1383; return; puts 1384}; puts p.call; puts 1385}; puts x.call; puts 1386; rescue; puts 1387; puts $!.class; end
$g = 0; def m_123; puts 1388; x = get_block { puts 1389; p = lambda{ puts 1390; return; puts 1391}; puts p.call; puts 1392}; puts x.call; puts 1393; end; 
begin; puts 1394; m_123; puts 1395; rescue; puts 1396; puts $!.class; end
$g = 0; begin; puts 1397; x = get_block { puts 1398; p = Proc.new{ puts 1399; return; puts 1400}; puts p.call; puts 1401}; puts x.call; puts 1402; rescue; puts 1403; puts $!.class; end
$g = 0; def m_124; puts 1404; x = get_block { puts 1405; p = Proc.new{ puts 1406; return; puts 1407}; puts p.call; puts 1408}; puts x.call; puts 1409; end; 
begin; puts 1410; m_124; puts 1411; rescue; puts 1412; puts $!.class; end
$g = 0; begin; puts 1413; x = get_block { puts 1414; p = get_block{ puts 1415; return; puts 1416}; puts p.call; puts 1417}; puts x.call; puts 1418; rescue; puts 1419; puts $!.class; end
$g = 0; def m_125; puts 1420; x = get_block { puts 1421; p = get_block{ puts 1422; return; puts 1423}; puts p.call; puts 1424}; puts x.call; puts 1425; end; 
begin; puts 1426; m_125; puts 1427; rescue; puts 1428; puts $!.class; end
$g = 0; begin; puts 1429; x = get_block { puts 1430; p = get_lambda{ puts 1431; return; puts 1432}; puts p.call; puts 1433}; puts x.call; puts 1434; rescue; puts 1435; puts $!.class; end
$g = 0; def m_126; puts 1436; x = get_block { puts 1437; p = get_lambda{ puts 1438; return; puts 1439}; puts p.call; puts 1440}; puts x.call; puts 1441; end; 
begin; puts 1442; m_126; puts 1443; rescue; puts 1444; puts $!.class; end
$g = 0; begin; puts 1445; x = get_block { puts 1446; p = get_proc{ puts 1447; return; puts 1448}; puts p.call; puts 1449}; puts x.call; puts 1450; rescue; puts 1451; puts $!.class; end
$g = 0; def m_127; puts 1452; x = get_block { puts 1453; p = get_proc{ puts 1454; return; puts 1455}; puts p.call; puts 1456}; puts x.call; puts 1457; end; 
begin; puts 1458; m_127; puts 1459; rescue; puts 1460; puts $!.class; end
$g = 0; begin; puts 1461; x = get_block { puts 1462; p = get_local_block; puts p.call; puts 1463}; puts x.call; puts 1464; rescue; puts 1465; puts $!.class; end
$g = 0; def m_128; puts 1466; x = get_block { puts 1467; p = get_local_block; puts p.call; puts 1468}; puts x.call; puts 1469; end; 
begin; puts 1470; m_128; puts 1471; rescue; puts 1472; puts $!.class; end
$g = 0; begin; puts 1473; x = get_block { puts 1474; p = get_local_lambda; puts p.call; puts 1475}; puts x.call; puts 1476; rescue; puts 1477; puts $!.class; end
$g = 0; def m_129; puts 1478; x = get_block { puts 1479; p = get_local_lambda; puts p.call; puts 1480}; puts x.call; puts 1481; end; 
begin; puts 1482; m_129; puts 1483; rescue; puts 1484; puts $!.class; end
$g = 0; begin; puts 1485; x = get_block { puts 1486; p = get_local_proc; puts p.call; puts 1487}; puts x.call; puts 1488; rescue; puts 1489; puts $!.class; end
$g = 0; def m_130; puts 1490; x = get_block { puts 1491; p = get_local_proc; puts p.call; puts 1492}; puts x.call; puts 1493; end; 
begin; puts 1494; m_130; puts 1495; rescue; puts 1496; puts $!.class; end

$g = 0; begin; puts 1497; x = get_lambda { puts 1498; p = lambda{ puts 1499; return; puts 1500}; puts p.call; puts 1501}; puts x.call; puts 1502; rescue; puts 1503; puts $!.class; end
$g = 0; def m_131; puts 1504; x = get_lambda { puts 1505; p = lambda{ puts 1506; return; puts 1507}; puts p.call; puts 1508}; puts x.call; puts 1509; end; 
begin; puts 1510; m_131; puts 1511; rescue; puts 1512; puts $!.class; end
$g = 0; begin; puts 1513; x = get_lambda { puts 1514; p = Proc.new{ puts 1515; return; puts 1516}; puts p.call; puts 1517}; puts x.call; puts 1518; rescue; puts 1519; puts $!.class; end
$g = 0; def m_132; puts 1520; x = get_lambda { puts 1521; p = Proc.new{ puts 1522; return; puts 1523}; puts p.call; puts 1524}; puts x.call; puts 1525; end; 
begin; puts 1526; m_132; puts 1527; rescue; puts 1528; puts $!.class; end
$g = 0; begin; puts 1529; x = get_lambda { puts 1530; p = get_block{ puts 1531; return; puts 1532}; puts p.call; puts 1533}; puts x.call; puts 1534; rescue; puts 1535; puts $!.class; end
$g = 0; def m_133; puts 1536; x = get_lambda { puts 1537; p = get_block{ puts 1538; return; puts 1539}; puts p.call; puts 1540}; puts x.call; puts 1541; end; 
begin; puts 1542; m_133; puts 1543; rescue; puts 1544; puts $!.class; end
$g = 0; begin; puts 1545; x = get_lambda { puts 1546; p = get_lambda{ puts 1547; return; puts 1548}; puts p.call; puts 1549}; puts x.call; puts 1550; rescue; puts 1551; puts $!.class; end
$g = 0; def m_134; puts 1552; x = get_lambda { puts 1553; p = get_lambda{ puts 1554; return; puts 1555}; puts p.call; puts 1556}; puts x.call; puts 1557; end; 
begin; puts 1558; m_134; puts 1559; rescue; puts 1560; puts $!.class; end
$g = 0; begin; puts 1561; x = get_lambda { puts 1562; p = get_proc{ puts 1563; return; puts 1564}; puts p.call; puts 1565}; puts x.call; puts 1566; rescue; puts 1567; puts $!.class; end
$g = 0; def m_135; puts 1568; x = get_lambda { puts 1569; p = get_proc{ puts 1570; return; puts 1571}; puts p.call; puts 1572}; puts x.call; puts 1573; end; 
begin; puts 1574; m_135; puts 1575; rescue; puts 1576; puts $!.class; end
$g = 0; begin; puts 1577; x = get_lambda { puts 1578; p = get_local_block; puts p.call; puts 1579}; puts x.call; puts 1580; rescue; puts 1581; puts $!.class; end
$g = 0; def m_136; puts 1582; x = get_lambda { puts 1583; p = get_local_block; puts p.call; puts 1584}; puts x.call; puts 1585; end; 
begin; puts 1586; m_136; puts 1587; rescue; puts 1588; puts $!.class; end
$g = 0; begin; puts 1589; x = get_lambda { puts 1590; p = get_local_lambda; puts p.call; puts 1591}; puts x.call; puts 1592; rescue; puts 1593; puts $!.class; end
$g = 0; def m_137; puts 1594; x = get_lambda { puts 1595; p = get_local_lambda; puts p.call; puts 1596}; puts x.call; puts 1597; end; 
begin; puts 1598; m_137; puts 1599; rescue; puts 1600; puts $!.class; end
$g = 0; begin; puts 1601; x = get_lambda { puts 1602; p = get_local_proc; puts p.call; puts 1603}; puts x.call; puts 1604; rescue; puts 1605; puts $!.class; end
$g = 0; def m_138; puts 1606; x = get_lambda { puts 1607; p = get_local_proc; puts p.call; puts 1608}; puts x.call; puts 1609; end; 
begin; puts 1610; m_138; puts 1611; rescue; puts 1612; puts $!.class; end

$g = 0; begin; puts 1613; x = get_proc { puts 1614; p = lambda{ puts 1615; return; puts 1616}; puts p.call; puts 1617}; puts x.call; puts 1618; rescue; puts 1619; puts $!.class; end
$g = 0; def m_139; puts 1620; x = get_proc { puts 1621; p = lambda{ puts 1622; return; puts 1623}; puts p.call; puts 1624}; puts x.call; puts 1625; end; 
begin; puts 1626; m_139; puts 1627; rescue; puts 1628; puts $!.class; end
$g = 0; begin; puts 1629; x = get_proc { puts 1630; p = Proc.new{ puts 1631; return; puts 1632}; puts p.call; puts 1633}; puts x.call; puts 1634; rescue; puts 1635; puts $!.class; end
$g = 0; def m_140; puts 1636; x = get_proc { puts 1637; p = Proc.new{ puts 1638; return; puts 1639}; puts p.call; puts 1640}; puts x.call; puts 1641; end; 
begin; puts 1642; m_140; puts 1643; rescue; puts 1644; puts $!.class; end
$g = 0; begin; puts 1645; x = get_proc { puts 1646; p = get_block{ puts 1647; return; puts 1648}; puts p.call; puts 1649}; puts x.call; puts 1650; rescue; puts 1651; puts $!.class; end
$g = 0; def m_141; puts 1652; x = get_proc { puts 1653; p = get_block{ puts 1654; return; puts 1655}; puts p.call; puts 1656}; puts x.call; puts 1657; end; 
begin; puts 1658; m_141; puts 1659; rescue; puts 1660; puts $!.class; end
$g = 0; begin; puts 1661; x = get_proc { puts 1662; p = get_lambda{ puts 1663; return; puts 1664}; puts p.call; puts 1665}; puts x.call; puts 1666; rescue; puts 1667; puts $!.class; end
$g = 0; def m_142; puts 1668; x = get_proc { puts 1669; p = get_lambda{ puts 1670; return; puts 1671}; puts p.call; puts 1672}; puts x.call; puts 1673; end; 
begin; puts 1674; m_142; puts 1675; rescue; puts 1676; puts $!.class; end
$g = 0; begin; puts 1677; x = get_proc { puts 1678; p = get_proc{ puts 1679; return; puts 1680}; puts p.call; puts 1681}; puts x.call; puts 1682; rescue; puts 1683; puts $!.class; end
$g = 0; def m_143; puts 1684; x = get_proc { puts 1685; p = get_proc{ puts 1686; return; puts 1687}; puts p.call; puts 1688}; puts x.call; puts 1689; end; 
begin; puts 1690; m_143; puts 1691; rescue; puts 1692; puts $!.class; end
$g = 0; begin; puts 1693; x = get_proc { puts 1694; p = get_local_block; puts p.call; puts 1695}; puts x.call; puts 1696; rescue; puts 1697; puts $!.class; end
$g = 0; def m_144; puts 1698; x = get_proc { puts 1699; p = get_local_block; puts p.call; puts 1700}; puts x.call; puts 1701; end; 
begin; puts 1702; m_144; puts 1703; rescue; puts 1704; puts $!.class; end
$g = 0; begin; puts 1705; x = get_proc { puts 1706; p = get_local_lambda; puts p.call; puts 1707}; puts x.call; puts 1708; rescue; puts 1709; puts $!.class; end
$g = 0; def m_145; puts 1710; x = get_proc { puts 1711; p = get_local_lambda; puts p.call; puts 1712}; puts x.call; puts 1713; end; 
begin; puts 1714; m_145; puts 1715; rescue; puts 1716; puts $!.class; end
$g = 0; begin; puts 1717; x = get_proc { puts 1718; p = get_local_proc; puts p.call; puts 1719}; puts x.call; puts 1720; rescue; puts 1721; puts $!.class; end
$g = 0; def m_146; puts 1722; x = get_proc { puts 1723; p = get_local_proc; puts p.call; puts 1724}; puts x.call; puts 1725; end; 
begin; puts 1726; m_146; puts 1727; rescue; puts 1728; puts $!.class; end


$g = 0; begin; puts 1729; for i in [1, 2]; puts 1730; p = lambda{ puts 1731; return; puts 1732}; puts p.call; puts 1733; end; puts 1734; rescue; puts 1735; puts $!.class; end
$g = 0; def m_147; puts 1736; for i in [1, 2]; puts 1737; p = lambda{ puts 1738; return; puts 1739}; puts p.call; puts 1740; end; puts 1741; end;
begin; puts 1742; m_147; puts 1743; rescue; puts 1744; puts $!.class; end
$g = 0; begin; puts 1745; for i in [1, 2]; puts 1746; p = Proc.new{ puts 1747; return; puts 1748}; puts p.call; puts 1749; end; puts 1750; rescue; puts 1751; puts $!.class; end
$g = 0; def m_148; puts 1752; for i in [1, 2]; puts 1753; p = Proc.new{ puts 1754; return; puts 1755}; puts p.call; puts 1756; end; puts 1757; end;
begin; puts 1758; m_148; puts 1759; rescue; puts 1760; puts $!.class; end
$g = 0; begin; puts 1761; for i in [1, 2]; puts 1762; p = get_block{ puts 1763; return; puts 1764}; puts p.call; puts 1765; end; puts 1766; rescue; puts 1767; puts $!.class; end
$g = 0; def m_149; puts 1768; for i in [1, 2]; puts 1769; p = get_block{ puts 1770; return; puts 1771}; puts p.call; puts 1772; end; puts 1773; end;
begin; puts 1774; m_149; puts 1775; rescue; puts 1776; puts $!.class; end
$g = 0; begin; puts 1777; for i in [1, 2]; puts 1778; p = get_lambda{ puts 1779; return; puts 1780}; puts p.call; puts 1781; end; puts 1782; rescue; puts 1783; puts $!.class; end
$g = 0; def m_150; puts 1784; for i in [1, 2]; puts 1785; p = get_lambda{ puts 1786; return; puts 1787}; puts p.call; puts 1788; end; puts 1789; end;
begin; puts 1790; m_150; puts 1791; rescue; puts 1792; puts $!.class; end
$g = 0; begin; puts 1793; for i in [1, 2]; puts 1794; p = get_proc{ puts 1795; return; puts 1796}; puts p.call; puts 1797; end; puts 1798; rescue; puts 1799; puts $!.class; end
$g = 0; def m_151; puts 1800; for i in [1, 2]; puts 1801; p = get_proc{ puts 1802; return; puts 1803}; puts p.call; puts 1804; end; puts 1805; end;
begin; puts 1806; m_151; puts 1807; rescue; puts 1808; puts $!.class; end
$g = 0; begin; puts 1809; for i in [1, 2]; puts 1810; p = get_local_block; puts p.call; puts 1811; end; puts 1812; rescue; puts 1813; puts $!.class; end
$g = 0; def m_152; puts 1814; for i in [1, 2]; puts 1815; p = get_local_block; puts p.call; puts 1816; end; puts 1817; end;
begin; puts 1818; m_152; puts 1819; rescue; puts 1820; puts $!.class; end
$g = 0; begin; puts 1821; for i in [1, 2]; puts 1822; p = get_local_lambda; puts p.call; puts 1823; end; puts 1824; rescue; puts 1825; puts $!.class; end
$g = 0; def m_153; puts 1826; for i in [1, 2]; puts 1827; p = get_local_lambda; puts p.call; puts 1828; end; puts 1829; end;
begin; puts 1830; m_153; puts 1831; rescue; puts 1832; puts $!.class; end
$g = 0; begin; puts 1833; for i in [1, 2]; puts 1834; p = get_local_proc; puts p.call; puts 1835; end; puts 1836; rescue; puts 1837; puts $!.class; end
$g = 0; def m_154; puts 1838; for i in [1, 2]; puts 1839; p = get_local_proc; puts p.call; puts 1840; end; puts 1841; end;
begin; puts 1842; m_154; puts 1843; rescue; puts 1844; puts $!.class; end
