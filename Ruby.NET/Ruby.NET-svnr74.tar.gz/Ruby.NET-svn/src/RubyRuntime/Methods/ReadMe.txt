  
Ruby.NET Runtime Library
  
Originally developed at Queensland University of Technology

----------------------------------------------------------------------

This directory contains .NET class definitions that implement the
Ruby methods belonging to the classes and modules built into the
standard Ruby Language.

The runtime representations of these classes can be found in the
..\Built-in Classes directory.

Authors include:

	Wayne Kelly
	John Gough
	Douglas Stockwell
	Brian Blackwell
	Chien Jon Soon
	Wayne Reid

