using Ruby.Runtime;
using Ruby.Interop;

namespace Ruby
{
    public partial class Errno
    {
    }
}

