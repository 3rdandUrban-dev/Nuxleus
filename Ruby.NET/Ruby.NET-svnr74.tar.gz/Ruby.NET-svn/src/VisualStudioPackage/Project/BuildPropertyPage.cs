using System.Runtime.InteropServices;


namespace Ruby.NET
{
    [ComVisible(true), Guid("28F7FB8F-2CD5-4599-B68A-92B74EBD01E1")]
    public class BuildPropertyPage : Microsoft.VisualStudio.Package.BuildPropertyPage
    {
    }
}