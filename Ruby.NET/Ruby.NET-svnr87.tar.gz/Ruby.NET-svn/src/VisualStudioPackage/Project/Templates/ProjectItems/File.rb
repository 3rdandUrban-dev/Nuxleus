class %className%

end
    
