﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("RubyRuntime")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Queensland University of Technology")]
[assembly: AssemblyProduct("Ruby.NET compiler")]
[assembly: AssemblyCopyright("Copyright © Queensland University of Technology 2006")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]




// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("0.8.2.0")]
