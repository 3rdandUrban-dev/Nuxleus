These tests complement BFTS <http://rubyforge.org/projects/bfts>.  If needed,
they can be easily incorporated into BFTS, though for now they specifically
check for exact compatibility with Ruby 1.8.2.

These tests are meant to be used by any Ruby implementation and must not be
specific to any one of them.
