class RubyMain
{
    public static void Main(string[] args)
    {
        Ruby.Compiler.RubyEntry.Process(args);

    }
}
