public class RubyCompiler
{
    public static void Main(string[] args)
    {
        Ruby.Compiler.Compiler.Process(args);
    }
}
