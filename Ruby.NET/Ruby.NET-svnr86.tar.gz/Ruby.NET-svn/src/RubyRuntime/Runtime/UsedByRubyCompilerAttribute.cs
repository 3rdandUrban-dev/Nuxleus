using System;
using System.Collections.Generic;
using System.Text;

namespace Ruby.Runtime
{
    class UsedByRubyCompilerAttribute: System.Attribute
    {
    }
}
