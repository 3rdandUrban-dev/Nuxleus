/* Copyright (c) 2006 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
*/

using System;
using System.IO;
using System.Collections;
using System.Text;
using System.Xml;
using Google.GData.Client;

namespace Google.GData.Extensions {

    /// <summary>
    /// GData schema extension describing a nested feed link.
    /// </summary>
    public class FeedLink : IExtensionElement
    {

        /// <summary>holds the href property</summary>
        protected string href;
        /// <summary>holds the readOnly property</summary>
        protected bool readOnly;
        /// <summary>holds the feed property</summary>
        protected AtomFeed feed;

        private bool readOnlySet; 
        private int countHint;

        /// <summary>
        /// constructor
        /// </summary>
        public FeedLink() 
        {
            this.countHint = -1; 
            this.readOnly = true; 
            this.readOnlySet = false; 
        }

        /// <summary>
        /// Entry  URI
        /// </summary>
        public string Href
        {
            get { return href;}
            set { href = value;}
        }

        /// <summary>
        /// Read only flag.
        /// </summary>
        public bool ReadOnly
        {
            get { return readOnly;}
            set { this.readOnly = value; this.readOnlySet = true;}
        }

        /// <summary>
        /// Count hint.
        /// </summary>
        public int CountHint
        {
            get { return countHint;}
            set { countHint = value;}
        }

        /// <summary>
        ///  Nested entry (optional).
        /// </summary>
        public AtomFeed Feed
        {
            get { return feed;}
            set { feed = value;}
        }

#region FeedLink Parser
        //////////////////////////////////////////////////////////////////////
        /// <summary>Parses an xml node to create an FeedLink object.</summary> 
        /// <param name="node">feedLink node</param>
        /// <returns> the created FeedLink object</returns>
        //////////////////////////////////////////////////////////////////////
        public static FeedLink ParseFeedLink(XmlNode node)
        {
            Tracing.TraceCall();
            FeedLink link = null;
            Tracing.Assert(node != null, "node should not be null");
            if (node == null)
            {
                throw new ArgumentNullException("node");
            }

            object localname = node.LocalName;
            if (localname.Equals(GDataParserNameTable.XmlFeedLinkElement))
            {
                link = new FeedLink();
                if (node.Attributes != null)
                {
                    if (node.Attributes[GDataParserNameTable.XmlAttributeHref] != null)
                    {
                        link.Href = node.Attributes[GDataParserNameTable.XmlAttributeHref].Value;
                    }

                    if (node.Attributes[GDataParserNameTable.XmlAttributeReadOnly] != null)
                    {
                        link.ReadOnly = node.Attributes[GDataParserNameTable.XmlAttributeReadOnly].Value.Equals("true");
                    }

                    if (node.Attributes[GDataParserNameTable.XmlAttributeCountHint] != null)
                    {
                        try
                        {
                            link.CountHint = Int32.Parse(node.Attributes[GDataParserNameTable.XmlAttributeCountHint].Value);
                        }
                        catch (FormatException fe)
                        {
                            throw new ArgumentException("Invalid g:feedLink/@countHint.", fe);
                        }
                    }
                }

                if (node.HasChildNodes)
                {

                    foreach (XmlNode feedChild in node.ChildNodes)
                    {
                        if (feedChild.LocalName == AtomParserNameTable.XmlFeedElement &&
                            feedChild.NamespaceURI == BaseNameTable.NSAtom)
                        {

                            if (link.Feed == null)
                            {
                                link.Feed = new AtomFeed(null, new Service());
                                Stream feedStream =
                                new MemoryStream(ASCIIEncoding.Default.GetBytes(feedChild.OuterXml));

                                link.Feed.Parse(feedStream, AlternativeFormat.Atom);
                            }
                            else
                            {
                                throw new ArgumentException("Only one feed is allowed inside the g:feedLink");
                            }
                        }
                    }
                }

            }

            return link;
        }

#endregion

#region overloaded for persistence

        //////////////////////////////////////////////////////////////////////
        /// <summary>Returns the constant representing this XML element.</summary> 
        //////////////////////////////////////////////////////////////////////
        public string XmlName
        {
            get { return GDataParserNameTable.XmlFeedLinkElement;}
        }

        /// <summary>
        /// Persistence method for the FeedLink object
        /// </summary>
        /// <param name="writer">the xmlwriter to write into</param>
        public void Save(XmlWriter writer)
        {
            if (Utilities.IsPersistable(this.Href) || this.Feed != null)
            {
                writer.WriteStartElement(BaseNameTable.gDataPrefix, XmlName, BaseNameTable.gNamespace);
    
                if (Utilities.IsPersistable(this.Href))
                {
                    writer.WriteAttributeString(GDataParserNameTable.XmlAttributeHref, this.Href);
                }
                // do not save the default
                if (this.readOnlySet)
                {
                    writer.WriteAttributeString(GDataParserNameTable.XmlAttributeReadOnly, this.ReadOnly.ToString());
                }
                if (countHint > -1)
                {
                    writer.WriteAttributeString(GDataParserNameTable.XmlAttributeCountHint, this.ReadOnly.ToString());
                }
    
                if (Feed != null)
                {
                    Feed.SaveToXml(writer);
                }
    
                writer.WriteEndElement();
            }
        }
#endregion
    }
}
