using System;
using System.Collections.Generic;
using System.Text;

namespace Clarius.Samples.Web.VirtualPathProvider
{
    internal enum VirtualPathType
    {
        Files, Directories, All
    }
}
