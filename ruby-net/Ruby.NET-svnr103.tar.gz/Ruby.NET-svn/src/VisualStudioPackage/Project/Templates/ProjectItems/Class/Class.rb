class $safeitemrootname$

end
    
