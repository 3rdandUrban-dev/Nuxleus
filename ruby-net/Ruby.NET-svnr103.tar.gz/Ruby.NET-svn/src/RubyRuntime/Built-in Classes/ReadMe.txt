  
Ruby.NET Runtime Library
  
Originally developed at Queensland University of Technology

----------------------------------------------------------------------

This directory contains .NET class definitions for the runtime 
representation of Ruby objects of the standard classes built 
into the Ruby language.

The Ruby methods belonging to those classes are implemented in the 
..\Methods directory.

Authors include:

	Wayne Kelly
	John Gough
	Douglas Stockwell
	Brian Blackwell
	Chien Jon Soon
	Wayne Reid

