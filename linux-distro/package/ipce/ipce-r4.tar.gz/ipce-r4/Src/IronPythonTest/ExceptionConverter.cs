/* **********************************************************************************
 *
 * Copyright (c) Microsoft Corporation. All rights reserved.
 *
 * This source code is subject to terms and conditions of the Shared Source License
 * for IronPython. A copy of the license can be found in the License.html file
 * at the root of this distribution. If you can not locate the Shared Source License
 * for IronPython, please send an email to ironpy@microsoft.com.
 * By using this source code in any fashion, you are agreeing to be bound by
 * the terms of the Shared Source License for IronPython.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * **********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace IronPythonTest {
    public class CLRException1 : Exception {
        public CLRException1() : base() { }
        public CLRException1(string msg) : base(msg) { }
    }
    public class CLRException2 : Exception {
        public CLRException2() : base() { }
        public CLRException2(string msg) : base(msg) { }
    }
    public class CLRException3 : Exception {
        public CLRException3() : base() { }
        public CLRException3(string msg) : base(msg) { }
    }
    public class CLRException4 : Exception {
        public CLRException4() : base() { }
        public CLRException4(string msg) : base(msg) { }
    }
}
