
10 .. 30
10.. 40
10 ..50
# Scenario: space
# Default: pass
