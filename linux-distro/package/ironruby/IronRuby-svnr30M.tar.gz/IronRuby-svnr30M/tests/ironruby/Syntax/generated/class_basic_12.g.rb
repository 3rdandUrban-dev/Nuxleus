
class My
	def m
	end 
end 

class My.m
end 
# Scenario: "." in the name
# Default: syntax error
