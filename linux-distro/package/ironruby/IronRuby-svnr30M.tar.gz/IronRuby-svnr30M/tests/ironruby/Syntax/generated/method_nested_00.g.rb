# nested method definition

#* syntax

def method def	nested end end 
# Scenario: same line
# Default: syntax error
