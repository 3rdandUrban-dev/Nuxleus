#* define

def method & block 
	1
end 
method
method { 1 }
# Scenario: space between & and parameter name
# Default: pass
