
{ "a", 10, "b" => 20}
# Scenario: mixed seperator
# Default: syntax error
