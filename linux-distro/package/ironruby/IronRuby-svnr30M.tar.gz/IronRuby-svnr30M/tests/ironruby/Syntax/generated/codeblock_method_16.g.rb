
def method c
end 
method 1  { 2 } 
# Scenario: paraenthesis or do-end, related to arguments
# Default: syntax error
