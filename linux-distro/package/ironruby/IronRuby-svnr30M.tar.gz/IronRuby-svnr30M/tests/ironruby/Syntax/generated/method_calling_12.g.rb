
def method(a, b)
	return a, b
end
method('language' => 'ruby', 'framework' => '.net')
# Scenario: two args: wrong number of arguments (1 for 2)
# Default: ArgumentError
# ParseOnly: pass
