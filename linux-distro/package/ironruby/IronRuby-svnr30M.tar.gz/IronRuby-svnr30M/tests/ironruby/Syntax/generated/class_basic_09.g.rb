
class Class 	
end 
# Scenario: special class "Class"
# Default: pass
