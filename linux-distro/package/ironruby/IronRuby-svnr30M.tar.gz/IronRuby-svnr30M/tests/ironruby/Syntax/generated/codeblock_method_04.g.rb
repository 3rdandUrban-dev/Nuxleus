
def method &block, a
	1
end 
# Scenario: without parenthsis, two args, & not last
# Default: syntax error
