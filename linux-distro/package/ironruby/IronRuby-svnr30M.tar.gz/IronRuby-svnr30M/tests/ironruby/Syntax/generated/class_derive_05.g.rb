
class D < 1
end 
# Scenario: superclass must be a Class (Fixnum given)
# Default: TypeError
# ParseOnly: pass
