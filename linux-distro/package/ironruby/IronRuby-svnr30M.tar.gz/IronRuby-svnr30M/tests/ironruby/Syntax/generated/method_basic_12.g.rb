
def [1, 2]
  1
end 
# Scenario: non-empty array after def
# Default: syntax error
