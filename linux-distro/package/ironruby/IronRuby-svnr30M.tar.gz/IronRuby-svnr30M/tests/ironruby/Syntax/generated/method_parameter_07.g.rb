
#* parentheses
def method         (a, b)
	a+b
end 
# Scenario: space is ok between method name and (
# Default: pass
