
def "method"
  1
end 
# Scenario: "string" after def
# Default: syntax error
