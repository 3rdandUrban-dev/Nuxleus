
def method &a, &b
	1
end 
# Scenario: what about two block params
# Default: syntax error
