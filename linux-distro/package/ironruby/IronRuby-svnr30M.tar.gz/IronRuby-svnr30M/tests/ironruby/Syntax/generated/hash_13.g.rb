
{ 1, 2, 3 }
# Scenario: odd number
# Default: odd number list for Hash
