
def method(method)
	1
end
# Scenario: same as method name (??)
# Default: pass
