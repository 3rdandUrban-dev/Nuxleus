

def method(a)
	return a
end 

method :language => 'ruby', :framework => '.net'
# Scenario: one arg: without parenthesis, use Symbol
# Default: pass
