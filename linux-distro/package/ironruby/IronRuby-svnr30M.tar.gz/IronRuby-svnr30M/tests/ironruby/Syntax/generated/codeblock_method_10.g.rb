
def method &block
	1
end	
method({1}) 
# Scenario: can i add parenthesis around the block
# Default: odd number list for Hash
