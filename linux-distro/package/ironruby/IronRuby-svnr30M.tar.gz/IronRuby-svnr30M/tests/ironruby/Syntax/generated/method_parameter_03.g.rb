
def method a  b
end
# Scenario: missing comma
# Default: syntax error
