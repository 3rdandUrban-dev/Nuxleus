
a = %w
(opqrst)

# Scenario: space
# Default: unterminated
# ParseOnly: merlin_bug#248301
