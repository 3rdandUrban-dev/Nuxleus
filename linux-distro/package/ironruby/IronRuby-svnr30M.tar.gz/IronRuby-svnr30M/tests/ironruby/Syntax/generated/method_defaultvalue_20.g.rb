
def method (a=3, b=4)
end 
method
method(1)
method(1,2)
# Scenario: without parenthesis, two default values
# Default: pass
