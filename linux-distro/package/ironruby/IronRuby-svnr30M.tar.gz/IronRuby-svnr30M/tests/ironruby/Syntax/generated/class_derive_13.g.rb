
class A 
end 
class B
end 

class C < A < B
end 
# Scenario: superclass must be a Class (NilClass given)
# Default: TypeError
# ParseOnly: pass
