
#* hashargs

def method(a)
	return a
end 

method({ 
	'language' => 'ruby',
	'framework' => '.net'
	})

method( 
	'language' => 'ruby',
	'framework' => '.net'
	)

method({ 
	:language => 'ruby',
	:framework => '.net'
	})

method( 
	:language => 'ruby',
	:framework => '.net'
	)
# Scenario: one arg
# Default: pass
