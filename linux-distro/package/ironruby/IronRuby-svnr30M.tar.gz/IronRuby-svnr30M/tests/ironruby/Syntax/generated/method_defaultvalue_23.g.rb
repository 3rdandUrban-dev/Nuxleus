
def method(a, b=-4)
	a + b
end 
method
# Scenario: the second one has default value (negative 1): in `method': wrong number of arguments (0 for 1)
# Default: ArgumentError
# ParseOnly: pass
