
def method a, &b
	1
end 
method {2} 

# Scenario: no normal args passed in: wrong number of arguments (0 for 1)
# Default: ArgumentError
# ParseOnly: pass
