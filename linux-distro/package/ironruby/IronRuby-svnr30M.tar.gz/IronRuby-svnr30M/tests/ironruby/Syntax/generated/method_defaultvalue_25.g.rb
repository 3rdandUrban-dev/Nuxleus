
#* value
# value can be any expression?

def method(c="string", d = 1.to_s()) 
	c + d
end 
method
method(1, 2)
# Scenario: valid: string, expression
# Default: pass
