

def method
end 
p = lambda {}
method &p, 1
# Scenario: pass proc as without ()
# Default: syntax error
