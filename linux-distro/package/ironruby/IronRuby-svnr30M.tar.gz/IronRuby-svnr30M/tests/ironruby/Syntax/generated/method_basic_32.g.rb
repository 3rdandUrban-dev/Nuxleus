
def method!_
	"!_"
end 
# Scenario: unknown
# Default: pass
