
class myClass
end 
# Scenario: starting with lowercase
# Default: class/module name must be CONSTANT
# ParseOnly: Class/module name must be a constant
