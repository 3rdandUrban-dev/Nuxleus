
def m
    (1, )
end 

# Scenario: parenthesis around; simply (1) is ok
# Default: syntax error
