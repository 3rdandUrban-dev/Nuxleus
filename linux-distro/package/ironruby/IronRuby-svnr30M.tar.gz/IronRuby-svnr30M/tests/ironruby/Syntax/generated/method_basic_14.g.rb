
def 9method
end 
# Scenario: method name starting with digit
# Default: syntax error
