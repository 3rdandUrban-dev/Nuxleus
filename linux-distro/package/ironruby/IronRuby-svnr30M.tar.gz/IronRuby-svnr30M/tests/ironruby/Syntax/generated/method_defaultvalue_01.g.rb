
def method a=
	puts 
end 
method
# Scenario: without parenthesis, without default value (valid??)
# Default: pass
