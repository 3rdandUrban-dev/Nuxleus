
def 
  method 
    a
  end 
method
# Scenario: "a" as method body here
# Default: NameError
# ParseOnly: pass
