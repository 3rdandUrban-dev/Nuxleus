
def method 
	def 
	nested 
end 
method
# Scenario: missing end
# Default: syntax error
