
def method(a, b, c)
	return a, b, c
end 
method(*[1,2], 3)
# Scenario: must be the last one: first
# Default: syntax error
