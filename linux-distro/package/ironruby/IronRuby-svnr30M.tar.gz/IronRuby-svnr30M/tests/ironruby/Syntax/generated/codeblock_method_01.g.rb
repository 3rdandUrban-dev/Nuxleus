
def method &block 
	1
end
method 
method { 1 }
# Scenario: without parenthesis, only arg
# Default: pass
