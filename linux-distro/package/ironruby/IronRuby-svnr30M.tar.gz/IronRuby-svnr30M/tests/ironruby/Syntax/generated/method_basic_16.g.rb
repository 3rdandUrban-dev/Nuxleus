
def Method 
  1
end 
Method

# uppercase in the middle of the method name
def mEthod
  1
end 
mEthod

def mETHOD
  1
end 
mETHOD
# Scenario: method name begins with Uppercase
# Default: pass
