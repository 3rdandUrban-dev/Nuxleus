
def method a, b, c, d, &c
	1
end 	
# Scenario: with block
# Default: duplicate block argument name
# ParseOnly: merlin_bug#248256
