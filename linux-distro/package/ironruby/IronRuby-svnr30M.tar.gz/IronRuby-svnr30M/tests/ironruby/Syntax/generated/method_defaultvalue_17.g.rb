
def method (a,
	b = 2)
end 
method(1)
method(1, 10)
# Scenario: with parenthesis, parameters in different lines
# Default: pass
