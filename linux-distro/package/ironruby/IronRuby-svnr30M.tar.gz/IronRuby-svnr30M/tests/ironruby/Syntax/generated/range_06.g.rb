
## exclusive range

10...20
20...10
10.20...-433.03
# Scenario: valid
# Default: pass
