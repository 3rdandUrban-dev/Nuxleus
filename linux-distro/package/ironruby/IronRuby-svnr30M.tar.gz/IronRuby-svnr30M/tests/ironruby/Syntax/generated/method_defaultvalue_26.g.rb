
def method(c=c)
end 
method(10)
# Scenario: value is itself
# Default: pass
