
def method!?
end 
# Scenario: method name ends with "!?"
# Default: syntax error
