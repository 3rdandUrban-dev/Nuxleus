
def method(a, b=-2, *c)
end 
method 
# Scenario: three parameters: in `method': wrong number of arguments (0 for 1)
# Default: ArgumentError
# ParseOnly: pass
