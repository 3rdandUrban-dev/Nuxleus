
def method a 1
end
# Scenario: body/parameter in the "def" line
# Default: syntax error
