
{"a"=> 10, 'b', "c" => 10}
# Scenario: odd number
# Default: syntax error
