def var
  800
end 