require '../../util/assert.rb'

# test const

TOP_LEVEL_CONST = 2

assert_equal(TOP_LEVEL_CONST, 2)
assert_equal(Object::TOP_LEVEL_CONST, 2)

def check
    assert_equal(TOP_LEVEL_CONST, 2)
end 

check

class My_const
    CONST = 1
    def check
        assert_equal(TOP_LEVEL_CONST, 2)
        assert_equal(Object::TOP_LEVEL_CONST, 2)
        
        assert_equal(CONST, 1)
        assert_equal(My_const::CONST, 1)
    end
end 

x = My_const.new

assert_equal(My_const::CONST, 1)
assert_raise(NoMethodError) { x.CONST }  # undefined method `CONST' for #<My:0x764e9a0> (NoMethodError)
assert_raise(TypeError) { x::CONST }  # #<My:0x75cf2b8> is not a class/module (TypeError)

x.check