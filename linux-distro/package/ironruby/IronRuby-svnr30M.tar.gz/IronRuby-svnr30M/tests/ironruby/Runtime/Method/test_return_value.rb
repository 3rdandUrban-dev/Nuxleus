require '../../util/assert.rb'

def m x
    if x > 2
      10
    end
end 

assert_return(10) { m 3 }
assert_return(nil) { m 1 }

def m
    return 1, 2
end 

assert_return([1,2]) { m }

def m
    return [2, 3]
end 

assert_return([2,3]) { m }

