require "module_c_require_d"

module D
  Y = C::X
end 