require "../../util/simple_test.rb"

describe "inspect object attributes" do
  it "asserts object identity for built-in types" do
    3.object_id.should == 3.object_id
    3.object_id.should_not == 4.object_id

    a, b = [], []
    a.object_id.should_not == b.object_id
  end

  it "tests for well-known object_id values" do
    nil.object_id.should == 4
    true.object_id.should == 2
    false.object_id.should == 0
    0.object_id.should == 1
    1.object_id.should == 3
    2.object_id.should == 5
    -1.object_id.should == -1
    -2.object_id.should == -3
  end

  it "tests for nil objects" do
    3.nil?.should == false
    nil.nil?.should == true
    [].nil?.should == false
  end

  it "converts well-known object to strings" do
    true.to_s.should == "true"
    false.to_s.should == "false"
    nil.to_s.should == ""
  end
end

# TODO: must implement is_a?
#test "kind_of? and is_a? tests on well-known types" do
#  assert 3.is_a? Fixnum
#  assert 3.is_a? Integer
#  assert 3.is_a? Numeric
#  assert 3.is_a? Object
#end

describe "Object#dup" do
  it "dup should copy instance variables" do
    class TestVars
      def x= v; @x=v; end
      def x; @x; end
      def y= v; @y=v; end
      def y; @y; end
      def z= v; @z=v; end
      def z; @z; end      
    end
    a = TestVars.new
    a.x = "a.x"
    a.y = "a.y"
    b = a.dup
    [a.x, a.y, a.z].should == ["a.x", "a.y", nil]
    [b.x, b.y, b.z].should == ["a.x", "a.y", nil]
    a.x << "-test"
    b.z = "b.z"
    [a.x, a.y, a.z].should == ["a.x-test", "a.y", nil]
    [b.x, b.y, b.z].should == ["a.x-test", "a.y", "b.z"]    
  end
  
  it "dup should copy tainted state" do
    x = Object.new
    x.tainted?.should == false
    x.taint
    x.tainted?.should == true
    y = x.dup
    y.tainted?.should == true
    y.untaint
    y.tainted?.should == false
    x.tainted?.should == true
  end 
  
  it "dup should not copy frozen state" do
    x = Object.new
    x.frozen?.should == false
    x.freeze
    x.frozen?.should == true
    x.dup.frozen?.should == false
    x.frozen?.should == true
  end

  it "dup on builtin class (reference type)" do
    x = "test"
    foo = "foo"
    x.instance_variable_set(:@foo, foo)
    x.instance_variable_set(:@bar, "bar")
    y = x.dup
    y.should == x
    y.should == "test"
    y.instance_variable_get(:@foo).should == "foo"
    y.instance_variable_get(:@bar).should == "bar"
    foo << "bar"
    y.instance_variable_get(:@foo).should == "foobar"
    x.instance_variable_get(:@foo).should == "foobar"
    y.instance_variables.sort.should == ["@bar", "@foo"]
  end
  
  it "dup on builtin value type raises an error" do
    should_raise(TypeError, "can't dup NilClass") { nil.dup }
    should_raise(TypeError, "can't dup Fixnum") { 123.dup }
    should_raise(TypeError, "can't dup Symbol") { :abc.dup }
  end
end

describe "Object#clone" do
  it "clone should copy instance variables" do
    a = TestVars.new
    a.x = "a.x"
    a.y = "a.y"
    b = a.clone
    [a.x, a.y, a.z].should == ["a.x", "a.y", nil]
    [b.x, b.y, b.z].should == ["a.x", "a.y", nil]
    a.x << "-test"
    b.z = "b.z"
    [a.x, a.y, a.z].should == ["a.x-test", "a.y", nil]
    [b.x, b.y, b.z].should == ["a.x-test", "a.y", "b.z"]    
  end
  
  it "clone should copy tainted state" do
    x = Object.new
    x.tainted?.should == false
    x.taint
    x.tainted?.should == true
    y = x.clone
    y.tainted?.should == true
    y.untaint
    y.tainted?.should == false
    x.tainted?.should == true
  end 
  
  it "clone should copy frozen state" do
    x = Object.new
    x.frozen?.should == false
    x.clone.frozen?.should == false
    x.freeze
    x.frozen?.should == true
    x.clone.frozen?.should == true
  end

  it "clone on builtin class (reference type)" do
    x = "test"
    foo = "foo"
    x.instance_variable_set(:@foo, foo)
    x.instance_variable_set(:@bar, "bar")
    y = x.clone
    y.should == x
    y.should == "test"
    y.instance_variable_get(:@foo).should == "foo"
    y.instance_variable_get(:@bar).should == "bar"
    foo << "bar"
    y.instance_variable_get(:@foo).should == "foobar"
    x.instance_variable_get(:@foo).should == "foobar"
    y.instance_variables.sort.should == ["@bar", "@foo"]
  end
  
  it "clone on builtin value type raises an error" do
    should_raise(TypeError, "can't clone NilClass") { nil.clone }
    should_raise(TypeError, "can't clone Fixnum") { 123.clone }
    should_raise(TypeError, "can't clone Symbol") { :abc.clone }
  end
end

finished