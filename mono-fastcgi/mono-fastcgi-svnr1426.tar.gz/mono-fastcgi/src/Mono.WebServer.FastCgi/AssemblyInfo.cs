using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle ("FastCGI ASP.NET Server")]
[assembly: AssemblyDescription ("A FastCGI implementation of the Mono XSP server.")]
[assembly: AssemblyCopyright ("2007 Brian Nickel")]