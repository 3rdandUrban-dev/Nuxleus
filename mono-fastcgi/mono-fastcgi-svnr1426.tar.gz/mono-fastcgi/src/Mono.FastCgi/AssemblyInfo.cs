using System.Reflection;
using System.Runtime.CompilerServices;

[assembly:AssemblyTitle("Mono.FastCgi Library")]
[assembly:AssemblyDescription("A .NET implementation of the FastCGI 1.0 Specification")]
[assembly:AssemblyCopyright("2007 Brian Nickel")]
